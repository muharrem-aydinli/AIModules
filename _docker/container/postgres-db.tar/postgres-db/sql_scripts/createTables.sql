-- Createscript for table SPECIES
DROP TABLE if exists species; 
CREATE TABLE species
(
  "SPECIES_ID" serial NOT NULL, 
  "SPECIES_NAME" character varying NOT NULL, 
  CONSTRAINT "SPECIES_ID" PRIMARY KEY ("SPECIES_ID") 
)
WITH (
  OIDS=FALSE 
); 
ALTER TABLE species
  OWNER TO docker;
  
-- Createscript for table MATRIX_CLASSES
DROP TABLE if exists matrix_classes; 
CREATE TABLE matrix_classes
(
  "CLASS_ID" serial NOT NULL, 
  "CLASS_NAME" character varying NOT NULL, 
  CONSTRAINT "CLASS_ID" PRIMARY KEY ("CLASS_ID") 
)
WITH (
  OIDS=FALSE 
); 
ALTER TABLE matrix_classes
  OWNER TO docker;

-- Createscript for table GENOMES.
DROP TABLE if exists genomes; 
CREATE TABLE genomes
(
  "GENOMES_ID" serial NOT NULL, 
  "GENOME_REFERENCE_CONSORTIUM_ID" character varying NOT NULL, 
  "CHROMOSOME_NAME" character varying NOT NULL, 
  "CHROMOSOME_SORTING" integer NOT NULL, 
  "FK_SPECIES_ID" integer NOT NULL,
  "GENOME_DNA" text NOT NULL, 
  CONSTRAINT "GENOMES_ID" PRIMARY KEY ("GENOMES_ID"),
  CONSTRAINT "FK_SPECIES_ID" FOREIGN KEY ("FK_SPECIES_ID")
    REFERENCES species ("SPECIES_ID") MATCH SIMPLE
    ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE 
); 
ALTER TABLE genomes
  OWNER TO docker;

-- Createscript for table MATRICES.
DROP TABLE if exists matrices; 
CREATE TABLE matrices
(
  "MATRIX_ID" serial NOT NULL, 
  "MATRIX_NAME" character varying NOT NULL, 
  "FK_CLASS_ID" integer NOT NULL,
  "MATRIX_DATA" text NOT NULL, 
  CONSTRAINT "MATRIX_ID" PRIMARY KEY ("MATRIX_ID"),
  CONSTRAINT "FK_CLASS_ID" FOREIGN KEY ("FK_CLASS_ID")
    REFERENCES matrix_classes ("CLASS_ID") MATCH SIMPLE
    ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE 
); 
ALTER TABLE matrices
  OWNER TO docker;
