/**
 * 
 */
package org.moi.jsonObjects;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Muharrem Aydinli
 *
 */
public class DeleteHelper {
	
	private static final Logger LOG = LogManager.getLogger(DeleteHelper.class);
	
	public static void deleteFileFromDisk(String filename)
	{
		//Path deletePath = Paths.get(System.getProperty("user.home"),"tmp", filename);
		Path deletePath = Paths.get("/tmp", filename);
		
		try {
		    Files.delete(deletePath);
		    LOG.debug("File deleted: ", deletePath.toString());
		} catch (NoSuchFileException x) {
		    LOG.error("No such file or directory: ", deletePath);
		} catch (DirectoryNotEmptyException x) {
		    LOG.error("Not empty: ", deletePath);
		} catch (IOException e) {
		    // File permission problems are caught here.
		    LOG.error("Error deleting: ", e.getMessage());
		}
	}
}
