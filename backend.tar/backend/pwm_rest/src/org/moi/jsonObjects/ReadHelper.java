/**
 * 
 */
package org.moi.jsonObjects;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Muharrem Aydinli
 *
 */
public class ReadHelper {
	
	private static final Logger LOG = LogManager.getLogger(ReadHelper.class);
	
	public static List<String> getTessWmsResultFromFile(String outputFileName)
	{
		/*Path resultReadPath = 
				Paths.get(System.getProperty("user.home"),"tmp", outputFileName);*/
		Path resultReadPath = 
				Paths.get("/tmp", outputFileName);
		List<String> resultList = null;
		try {
			resultList =
					Files.readAllLines(resultReadPath, Charset.forName("UTF-8"));
		} catch (IOException e) {
			LOG.error("Could not read File:\n" + resultReadPath.toString(), e.getStackTrace(), e.getMessage());
		}
		return resultList;
	}

}
