/**
 * 
 */
package org.moi.jsonObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;



/**
 * @author Muharrem Aydinli
 *
 */
@JsonAutoDetect
public class JsonObjectForScoring {
	
	@JsonProperty
	private String mainElement = "result";
	

	public String getMainElement() {
		return mainElement;
	}

	public void setMainElement(String mainElement) {
		this.mainElement = mainElement;
	}

	public String getChildElements() {
		return childElements;
	}

	public void setChildElements(String childElements) {
		this.childElements = childElements;
	}

	@JsonProperty
	private String childElements = "";

	public void childElemtsToString(List<String> theChildElements)
	{
		/*for(int i = 0; i < theChildElements.size(); ++i)
			childElements += theChildElements.get(i);*/
		StringBuilder sb = new StringBuilder();
		for (String item : theChildElements)
		{
			sb.append(item);
		}
		
		// Workaround for Tess executable: if sequence.lenght < (matrix.length)/4 no valid json is returned
		Pattern p = Pattern.compile(",[\\s]*}");
		Matcher m = p.matcher(sb);
		
		childElements = m.replaceAll(" }");
	}
}
