/**
 * 
 */
package org.moi.jsonObjects;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.moi.model.Matrices;
import org.moi.constants.AnimalClassConstants;
import org.moi.constants.SpeciesConstants;
import org.moi.model.ConnectionInstance;
import org.moi.model.Genomes;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * @author Muharrem Aydinli
 *
 */
public class WriteHelper {

	/**
	 * 
	 * @param whatFile: matrix or seqeuence
	 * @return name of saved file
	 */
	
	private static final Logger LOG = LogManager.getLogger(WriteHelper.class);
	private static boolean isMatrix = false;
	
	@SuppressWarnings("null")
	public static String writeFileToHDD(String whatFile, JsonNode aJsonNode)
	{
		LOG.debug("<writeFileToHDD>");
		String filename = null;
		String jsonIndexName = null;
		String jsonToWrite = null;
		short jsonIndex = 0;
		switch (whatFile)
		{
			case("species"):
				// This is the selected species from Dropdownmenu.
				filename = "species_" + UUID.randomUUID().toString(); 
				jsonIndexName = "SpeciesSequence";
				jsonIndex = 1;
				isMatrix = false;
			break;
			case("animalClass"):
				// This is the selected animalClass from Dropdownmenu.
				filename = "animalClass_" + UUID.randomUUID().toString(); 
				jsonIndexName = "AnimalClassMatrix";
				jsonIndex = 3;
				isMatrix = true;
			break;
			case("sequence"):
				// This is the typed sequence
				filename = "sequence_" + UUID.randomUUID().toString(); 
				jsonIndexName = "FASTA";
				jsonIndex = 4;
				isMatrix = false;
				break;
			case("matrix"):
				// This is the typed matrix
				filename = "matrix_" + UUID.randomUUID().toString();
				jsonIndexName = "Matrix";
				jsonIndex = 5;
				isMatrix = true;
				break;
			default:
				LOG.error("Case for " + whatFile + " unknown.");
				return null;
		}
		
		Iterator<Map.Entry<String, JsonNode>> fields = aJsonNode.fields();
		while (fields.hasNext()) {
		   Map.Entry<String, JsonNode> entry = fields.next();
		   if(jsonIndex == 4 || jsonIndex == 5)
		   {
			   Iterator<Map.Entry<String,JsonNode>> fastaNodes = entry.getValue().get(jsonIndex).get(jsonIndexName).fields();
			   jsonToWrite = generateJson(fastaNodes);
		   }
		   if(jsonIndex == 1)
		   {
			   String species = entry.getValue().get(jsonIndex).get("SpeciesSequence").asText();
			   SpeciesConstants valid = SpeciesConstants.get(species);
			   int validSpeciesAsInt = valid.ordinal();
			   List<Genomes> genomesList = null;
			   if(validSpeciesAsInt > SpeciesConstants.NONE.ordinal() 
					   && validSpeciesAsInt < SpeciesConstants.ALL.ordinal())
			   {
				   ConnectionInstance.getInstance();
				   Query q = ConnectionInstance.getEntityManager().createNamedQuery("Genomes.getGenomesBySpecies");
				   q.setParameter("speciesID", (long)validSpeciesAsInt);
				   genomesList = q.getResultList();
			   }
			   else if(validSpeciesAsInt == SpeciesConstants.ALL.ordinal())
			   {
				   Query q = ConnectionInstance.getInstance().getEntityManager().createNamedQuery("Genomes.findAll");
				   genomesList = q.getResultList();
			   }
			   jsonToWrite = generateJsonForGenomes(genomesList);
		   }
		   if(jsonIndex == 3)
		   {
			   String animalClass = entry.getValue().get(jsonIndex).get("AnimalClassMatrix").asText();
			   AnimalClassConstants valid = AnimalClassConstants.get(animalClass);
			   int validAnimalClassAsInt = valid.ordinal();
			   List<Matrices> matricesList = null;
			   if(validAnimalClassAsInt > AnimalClassConstants.NONE.ordinal() 
					   && validAnimalClassAsInt < AnimalClassConstants.ALL.ordinal())
			   {
				   ConnectionInstance.getInstance();
				   Query q = ConnectionInstance.getEntityManager().createNamedQuery("Matrices.getMatricesByAnimalClass");
				   q.setParameter("classID", (long)validAnimalClassAsInt);
				   matricesList = q.getResultList();
			   }
			   else if(validAnimalClassAsInt == 7)
			   {
				   Query q = ConnectionInstance.getInstance().getEntityManager().createNamedQuery("Matrices.findAll");
				   matricesList = q.getResultList();
			   }
			   jsonToWrite = generateJsonForMatrices(matricesList);
		   }
		}
		
		if(jsonToWrite == null && jsonToWrite.isEmpty())
		{
			LOG.error("JSON could not be parsed prior to saving.");
		}
		
		//Path sequenceWritePath = Paths.get(System.getProperty("user.home"),"tmp", filename);
		Path sequenceWritePath = Paths.get("/tmp", filename);
		byte[] bytesToWrite = jsonToWrite.getBytes(Charset.forName("UTF-8"));
		try {
			Files.write(sequenceWritePath, bytesToWrite, StandardOpenOption.CREATE_NEW);
		} catch (IOException e) {
			LOG.error("Write failed:\n", e.getStackTrace(), e.getMessage());
		}
		
		return filename;
	}
	
	private static String generateJson(Iterator<Map.Entry<String,JsonNode>> aJsonNodeIter)
	{
		LOG.debug("<generateJson>");
		String jsonString = "";
		
		while (aJsonNodeIter.hasNext()) 
		{
		   Map.Entry<String, JsonNode> entryFasta = aJsonNodeIter.next();
		   jsonString += entryFasta.getKey() + "\n";
		   jsonString += entryFasta.getValue().textValue() + "\n" 
				   			+ (isMatrix == true ? ";\n" : "");
		}
		LOG.debug("</generateJson>");
		return jsonString;
	}
	
	private static String generateJsonForMatrices(List<Matrices> matricesList)
	{
		LOG.debug("</generateJson>");
		String jsonString = "";
		
		for(Matrices m : matricesList)
		{
			jsonString += m.getMATRIX_NAME() + "\n";
			jsonString += m.getMATRIX_DATA() + "\n" 
				   			+ (isMatrix == true ? ";\n" : "");
		}
		LOG.debug("</generateJson>");
		return jsonString;
	}
	
	private static String generateJsonForGenomes(List<Genomes> genomesList)
	{
		LOG.debug("</generateJson>");
		String jsonString = "";
		
		for(Genomes g : genomesList)
		{
			jsonString += g.getCHROMOSOME_NAME() + "\n";
			jsonString += g.getGENOME_DNA() + "\n" 
				   			+ (isMatrix == true ? ";\n" : "");
		}
		LOG.debug("</generateJson>");
		return jsonString;
	}
	
	public static String writeFile(String prefix, String content)
	{
		LOG.debug("<writeFile>");
		String filename = prefix + UUID.randomUUID().toString(); 
		Path sequenceWritePath = Paths.get("/tmp", filename);
		byte[] bytesToWrite = content.getBytes(Charset.forName("UTF-8"));
		try {
			Files.write(sequenceWritePath, bytesToWrite, StandardOpenOption.CREATE_NEW);
		} catch (IOException e) {
			LOG.error("Write failed:\n", e.getStackTrace(), e.getMessage());
		}
		LOG.debug("</writeFile>");
		return filename;
	}
	
	public static String zipFileAndSave(String sourceFilename)
	{
		LOG.debug("<zipFileAndSave>");
		
		String destinationFilename = sourceFilename + ".zip";
		final int BUFFER = 2048;
		try {
			BufferedInputStream origin = null;
	        FileOutputStream dest = new 
	          FileOutputStream(Paths.get("/tmp").toString() + File.separator + destinationFilename);
	        ZipOutputStream out = new ZipOutputStream(new 
	          BufferedOutputStream(dest));
	        out.setMethod(ZipOutputStream.DEFLATED);
	        byte data[] = new byte[BUFFER];

	        //String files[] = {Paths.get("/tmp").toString() + File.separator + sourceFilename};
	
	        //for (int i=0; i<files.length; i++) {
	           FileInputStream fi = new 
	             FileInputStream(Paths.get("/tmp").toString() + File.separator + sourceFilename);
	           origin = new 
	             BufferedInputStream(fi, BUFFER);
	           ZipEntry entry = new ZipEntry(sourceFilename);
	           out.putNextEntry(entry);
	           int count;
	           while((count = origin.read(data, 0, 
	             BUFFER)) != -1) {
	              out.write(data, 0, count);
	           }
	           origin.close();
	        //}
	        out.close();
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
		LOG.debug("</zipFileAndSave>");
		return destinationFilename;
	}	
}
