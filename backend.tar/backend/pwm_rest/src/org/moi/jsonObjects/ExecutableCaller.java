/**
 * 
 */
package org.moi.jsonObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Muharrem Aydinli
 *
 */

public class ExecutableCaller {
	
	private static final Logger LOG = LogManager.getLogger(ExecutableCaller.class);

	public static String CallTessWmsAndSaveOutput(String dnaFileName, String matrixFileName, String executablePath,
			String minThreshold, String maxDeficit)
	{
		LOG.debug("<CallTessWmsAndSaveOutput>");
		String outputFileName = "output_" + UUID.randomUUID().toString();
		
		Path sequenceReadPath = Paths.get("/tmp", dnaFileName);
		Path matrixReadPath = Paths.get("/tmp", matrixFileName);
		Path outputWritePath = Paths.get("/tmp", outputFileName);
		
		List<String> command = new ArrayList<String>();
        command.add(executablePath);
        command.add("-seq");
        command.add(sequenceReadPath.toFile().getAbsolutePath());
        command.add("-mat");
        command.add(matrixReadPath.toFile().getAbsolutePath());
        command.add("-out");
        command.add(outputWritePath.toFile().getAbsolutePath());
        command.add("-fmt");
        command.add("j");
        command.add("-mlo");
        command.add(minThreshold);
        command.add("-mxd");
        command.add(maxDeficit);
        
        ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);
        
        Process process = null;
		try {
			process = builder.start();
			
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String line;

			String result = new String();
			while ((line = br.readLine()) != null) {
				result += line;
				LOG.debug(line);
			}
		} catch (IOException e) {
			LOG.error("Error calling TessWms: ", e.getStackTrace(), e.getMessage());
			LOG.error(e.getMessage());
			return null;
		}
		
		return outputFileName;
	}
}
