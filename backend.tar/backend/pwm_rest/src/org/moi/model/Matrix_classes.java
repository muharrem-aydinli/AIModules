package org.moi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

/**
 * @author Muharrem Aydinli
 *
 */

@Entity
@NamedQuery(

        name = "Matrix_classes.getValidMatrixClasses",
        query = "select DISTINCT mc from Matrix_classes mc JOIN FETCH mc.matrices m " +
        		"where mc = m.matrix_classes ORDER BY mc"
        )
public class Matrix_classes {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="\"CLASS_ID\"", nullable = false, updatable = false)
	private Long CLASS_ID;
	@Column(name="\"CLASS_NAME\"", nullable = false, updatable = false, insertable = false)
	private String CLASS_NAME;
	@OneToOne(fetch=FetchType.LAZY, mappedBy="Matrix_classes", optional=false)
	private Matrices matrices;
	
	public Long getCLASS_ID() {
		return CLASS_ID;
	}
	public void setCLASS_ID(Long cLASS_ID) {
		CLASS_ID = cLASS_ID;
	}
	public String getCLASS_NAME() {
		return CLASS_NAME;
	}
	public void setCLASS_NAME(String cLASS_NAME) {
		CLASS_NAME = cLASS_NAME;
	}
	public Matrices getMatrices() {
		return matrices;
	}
	public void setMatrices(Matrices matrices) {
		this.matrices = matrices;
	}
	
	@Override
	public String toString() {
		return "Matrix_classes [CLASS_ID=" + CLASS_ID + ", CLASS_NAME=" + CLASS_NAME + "]";
	}	
}
