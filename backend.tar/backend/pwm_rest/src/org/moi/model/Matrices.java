package org.moi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

/**
 * @author Muharrem Aydinli
 *
 */

@Entity
@NamedQueries({
    @NamedQuery(name="Matrices.findAll",
                query="SELECT m FROM Matrices m"),
    @NamedQuery(name="Matrices.getMatricesByAnimalClass",
                query="SELECT m FROM Matrices m WHERE m.matrix_classes.CLASS_ID = :classID"),
}) 
public class Matrices {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="\"MATRIX_ID\"", nullable = false, updatable = false)
	private Long MATRIX_ID;
	@Column(name="\"MATRIX_NAME\"", nullable = false, updatable = false, insertable = false)
	private String MATRIX_NAME;
	@OneToOne(fetch=FetchType.LAZY, optional=false)
    @JoinColumn(
      name="\"FK_CLASS_ID\"", unique=true, nullable=false, updatable=false, insertable = false)
    private Matrix_classes matrix_classes;
	@Column(name="\"MATRIX_DATA\"", nullable = false, updatable = false, insertable = false)
	private String MATRIX_DATA;
	
	public Long getMATRIX_ID() {
		return MATRIX_ID;
	}
	public void setMATRIX_ID(Long mATRIX_ID) {
		MATRIX_ID = mATRIX_ID;
	}
	public String getMATRIX_NAME() {
		return MATRIX_NAME;
	}
	public void setMATRIX_NAME(String mATRIX_NAME) {
		MATRIX_NAME = mATRIX_NAME;
	}
	public Matrix_classes getMatrix_classes() {
		return matrix_classes;
	}
	public void setMatrix_classes(Matrix_classes matrix_classes) {
		this.matrix_classes = matrix_classes;
	}
	public String getMATRIX_DATA() {
		return MATRIX_DATA;
	}
	public void setMATRIX_DATA(String mATRIX_DATA) {
		MATRIX_DATA = mATRIX_DATA;
	}
	
	@Override
	public String toString() {
		return "Matrices [MATRIX_ID=" + MATRIX_ID + ", MATRIX_NAME=" + MATRIX_NAME + ", matrix_classes="
				+ matrix_classes + ", MATRIX_DATA=" + MATRIX_DATA + "]";
	}
	
	public String getMatrixNameAndMatrixData() {
		return MATRIX_NAME + "\n" + MATRIX_DATA + "\n";
	}
}