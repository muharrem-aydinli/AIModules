package org.moi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

/**
 * @author Muharrem Aydinli
 *
 */

@Entity
@NamedQuery(

        name = "Species.getValidSpeciesClasses",
        query = "select DISTINCT sp from Species sp JOIN FETCH sp.genomes g " +
        		"where sp = g.species ORDER BY sp"
        )
public class Species {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="\"SPECIES_ID\"", nullable = false, updatable = false)
	private Long SPECIES_ID;
	@Column(name="\"SPECIES_NAME\"", nullable = false, updatable = false, insertable = false)
	private String SPECIES_NAME;
	@OneToOne(fetch=FetchType.LAZY, mappedBy="Species", optional=false)
	private Genomes genomes;
	
	public Long getSPECIES_ID() {
		return SPECIES_ID;
	}
	public void setSPECIES_ID(Long sPECIES_ID) {
		SPECIES_ID = sPECIES_ID;
	}
	public String getSPECIES_NAME() {
		return SPECIES_NAME;
	}
	public void setSPECIES_NAME(String sPECIES_NAME) {
		SPECIES_NAME = sPECIES_NAME;
	}
	public Genomes getGenomes() {
		return genomes;
	}
	public void setGenomes(Genomes genomes) {
		this.genomes = genomes;
	}
	
	@Override
	public String toString() {
		return "Species [SPECIES_ID=" + SPECIES_ID + ", SPECIES_NAME=" + SPECIES_NAME + "]";
	}	
}
