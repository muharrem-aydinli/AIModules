package org.moi.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author Muharrem Aydinli
 *
 */

public class ConnectionInstance {

	private static final String PERSISTENCE_UNIT_NAME = "Genomes";
    private static EntityManagerFactory entitiyManagerFactory = null;
    private static ConnectionInstance instance = null;
    private static EntityManager entityManager = null;
    
    private ConnectionInstance()
    {
    	entitiyManagerFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
    	entityManager = entitiyManagerFactory.createEntityManager();
    }
    
	public static ConnectionInstance getInstance()
	{
		if(instance == null)
			instance = new ConnectionInstance();
		return instance;
	}

	public static EntityManagerFactory getEntitiyManagerFactory() {
		return entitiyManagerFactory;
	}

	public static EntityManager getEntityManager() {
		return entityManager;
	}
}
