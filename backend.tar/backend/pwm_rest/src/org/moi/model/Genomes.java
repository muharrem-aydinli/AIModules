package org.moi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

/**
 * @author Muharrem Aydinli
 *
 */

@Entity
@NamedQueries({
    @NamedQuery(name="Genomes.findAll",
                query="SELECT g FROM Genomes g"),
    @NamedQuery(name="Genomes.getGenomesBySpecies",
                query="SELECT g FROM Genomes g WHERE g.species.SPECIES_ID = :speciesID ORDER BY g"),
}) 
public class Genomes {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="\"GENOMES_ID\"", nullable = false, updatable = false)
	private Long GENOMES_ID;
	@Column(name="\"GENOME_REFERENCE_CONSORTIUM_ID\"", nullable = false, updatable = false, insertable = false)
	private String GENOME_REFERENCE_CONSORTIUM_ID;
	@Column(name="\"CHROMOSOME_NAME\"", nullable = false, updatable = false, insertable = false)
	private String CHROMOSOME_NAME;
	@Column(name="\"CHROMOSOME_SORTING\"", nullable = false, updatable = false, insertable = false)
	private int CHROMOSOME_SORTING;
	@OneToOne(fetch=FetchType.LAZY, optional=false)
    @JoinColumn(
      name="\"FK_SPECIES_ID\"", unique=true, nullable=false, updatable=false, insertable = false)
    private Species species;
	@Column(name="\"GENOME_DNA\"", nullable = false, updatable = false, insertable = false)
	private String GENOME_DNA;
	
	public Long getGENOMES_ID() {
		return GENOMES_ID;
	}
	public void setGENOMES_ID(Long gENOMES_ID) {
		GENOMES_ID = gENOMES_ID;
	}
	public String getGENOME_REFERENCE_CONSORTIUM_ID() {
		return GENOME_REFERENCE_CONSORTIUM_ID;
	}
	public void setGENOME_REFERENCE_CONSORTIUM_ID(String gENOME_REFERENCE_CONSORTIUM_ID) {
		GENOME_REFERENCE_CONSORTIUM_ID = gENOME_REFERENCE_CONSORTIUM_ID;
	}
	public String getCHROMOSOME_NAME() {
		return CHROMOSOME_NAME;
	}
	public void setCHROMOSOME_NAME(String cHROMOSOME_NAME) {
		CHROMOSOME_NAME = cHROMOSOME_NAME;
	}
	public int getCHROMOSOME_SORTING() {
		return CHROMOSOME_SORTING;
	}
	public void setCHROMOSOME_SORTING(int cHROMOSOME_SORTING) {
		CHROMOSOME_SORTING = cHROMOSOME_SORTING;
	}
	public Species getSpecies() {
		return species;
	}
	public void setSpecies(Species species) {
		this.species = species;
	}
	public String getGENOME_DNA() {
		return GENOME_DNA;
	}
	public void setGENOME_DNA(String gENOME_DNA) {
		GENOME_DNA = gENOME_DNA;
	}
	
	@Override
	public String toString() {
		return "Genomes [GENOMES_ID=" + GENOMES_ID + ", GENOME_REFERENCE_CONSORTIUM_ID="
				+ GENOME_REFERENCE_CONSORTIUM_ID + ", CHROMOSOME_NAME=" + CHROMOSOME_NAME + ", CHROMOSOME_SORTING="
				+ CHROMOSOME_SORTING + ", species=" + species + ", GENOME_DNA=" + GENOME_DNA + "]";
	}	
	
	public String getGenomeInfoAndData() {
		//return GENOME_REFERENCE_CONSORTIUM_ID + "\n" + CHROMOSOME_NAME + "\n" + CHROMOSOME_SORTING + "\n" +
			//	GENOME_DNA + "\n";
		return CHROMOSOME_NAME + "\n" + GENOME_DNA + "\n";
	}
}