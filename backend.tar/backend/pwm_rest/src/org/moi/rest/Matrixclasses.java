package org.moi.rest;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.moi.constants.AnimalClassConstants;
import org.moi.model.ConnectionInstance;
import org.moi.model.Matrices;
import org.moi.model.Matrix_classes;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author Muharrem Aydinli
 *
 */

@Path("/matrixclasses")
public class Matrixclasses {

	private static final String PERSISTENCE_UNIT_NAME = "Genomes";
    private static EntityManagerFactory factory;
    
	@GET
	@Produces("application/json")
	public Response getAvailableMatrixClasses() throws JSONException 
	{
		// Set of entries of DB.Matrix_classes that have a matrix in DB.Matrices
		TreeSet<String> validMatrixClasses = (TreeSet<String>)readFromDB();
		JSONObject mainObj = new JSONObject();
		fillJsonObject(mainObj, validMatrixClasses);
		
		
		return Response.status(200).entity(mainObj.toString()).build();
	}
	
	private Set<String> readFromDB()
    {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = factory.createEntityManager();
        Query q = em.createNamedQuery("Matrix_classes.getValidMatrixClasses");
        @SuppressWarnings("unchecked")
		List<Matrix_classes> genomesList = (List<Matrix_classes>)q.getResultList();
        Set<String> validMatrixClasses = new TreeSet<String>();
        if(genomesList.size() > 1)
        	validMatrixClasses.add("ALL");
        for (Matrix_classes mc : genomesList) {
    		try {
    			validMatrixClasses.add(mc.getCLASS_NAME().toUpperCase());
    			
    		} catch (Exception e) {
    			System.out.println(e.getMessage());
    			em.close();
    		}
        }
        em.close();

        return validMatrixClasses;
    }
	
	private void fillJsonObject(JSONObject mainObj, Set<String> validMatrixClasses)
	{
		JSONArray ja = new JSONArray();
		if(validMatrixClasses != null)
		{	
			for(String str : validMatrixClasses)
				ja.put(str);
		}
		mainObj.put("AnimalClasses", ja);
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path( "/{matrixclass}" )
	public Response getMatrixByClass(@PathParam( "matrixclass" ) String matrixclass)
	{
		String matrices = readFromDBMatricesByName(matrixclass);
		
		//Send back plain text.
	    //return Response.ok().entity( text ).build();
		return Response.status(200).entity(matrices).build();
	}
	
	private String readFromDBMatricesByName(String matrixclass)
    {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = factory.createEntityManager();
        
        AnimalClassConstants valid = AnimalClassConstants.get(matrixclass);
		int validAnimalClassAsInt = valid.ordinal();

		Query q = null;
		// matrixclass == "ALL"
		if(validAnimalClassAsInt == AnimalClassConstants.ALL.ordinal())
		{
			ConnectionInstance.getInstance();
			q = ConnectionInstance.getEntityManager().createNamedQuery("Matrices.findAll");
		}
		else
		{
			ConnectionInstance.getInstance();
			q = ConnectionInstance.getEntityManager().createNamedQuery("Matrices.getMatricesByAnimalClass");
			q.setParameter("classID", (long)validAnimalClassAsInt);
		}
		@SuppressWarnings("unchecked")
		List<Matrices> matricesList = (List<Matrices>)q.getResultList();
        
		String matrixNameMatrixData = "";
		for(Matrices m : matricesList)
			matrixNameMatrixData += m.getMatrixNameAndMatrixData();

        em.close();

        return matrixNameMatrixData;
    }
}
