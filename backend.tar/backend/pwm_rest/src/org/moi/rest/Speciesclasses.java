package org.moi.rest;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.moi.constants.SpeciesConstants;
import org.moi.model.ConnectionInstance;
import org.moi.model.Genomes;
import org.moi.model.Species;

/**
 * @author Muharrem Aydinli
 *
 */

@Path("/speciesclasses")
public class Speciesclasses {

	private static final String PERSISTENCE_UNIT_NAME = "Genomes";
    private static EntityManagerFactory factory;
    
	@GET
	@Produces("application/json")
	public Response getAvailableSpecies() throws JSONException 
	{
		/* Will be reimplemented when genome analysis is ready.
		// Set of entries of DB.Species that have a genome in DB.Genomes
		TreeSet<String> validSpecies = (TreeSet<String>)readFromDB();
		JSONObject mainObj = new JSONObject();
		fillJsonObject(mainObj, validSpecies);
		
		
		return Response.status(200).entity(mainObj.toString()).build();
		*/
		return Response.status(200).entity("empty").build();
	}
	
	private Set<String> readFromDB()
    {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = factory.createEntityManager();
        Query q = em.createNamedQuery("Species.getValidSpeciesClasses");
        @SuppressWarnings("unchecked")
		List<Species> genomesList = (List<Species>)q.getResultList();
        Set<String> validSpeciesClasses = new TreeSet<String>();
        if(genomesList.size() > 1)
        	validSpeciesClasses.add("ALL");
        for (Species sp : genomesList) {
    		try {
    			validSpeciesClasses.add(sp.getSPECIES_NAME().toUpperCase());
    			
    		} catch (Exception e) {
    			System.out.println(e.getMessage());
    			em.close();
    		}
        }
        em.close();

        return validSpeciesClasses;
    }
	
	private void fillJsonObject(JSONObject mainObj, Set<String> validSpeciesClasses)
	{
		JSONArray ja = new JSONArray();
		if(validSpeciesClasses != null)
		{	
			for(String str : validSpeciesClasses)
				ja.put(str);
		}
		mainObj.put("Species", ja);
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path( "/{speciesclass}" )
	// Test: http://localhost:8080/api/speciesclasses/HOMO%20SAPIENS
	public Response getMatrixByClass(@PathParam( "speciesclass" ) String speciesclass)
	{
		String species = readFromDBGenomesByName(speciesclass);
		
		
		//Send back plain text.
	    //return Response.ok().entity( text ).build();
		return Response.status(200).entity(species).build();
	}
	
	/**
	 * 
	 * @param speciesclass e.g. "Homo Sapiens"
	 * @return
	 */
	
	private String readFromDBGenomesByName(String speciesclass)
    {
    	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = factory.createEntityManager();
        
        SpeciesConstants valid = SpeciesConstants.get(speciesclass);
		int validSpeciesAsInt = valid.ordinal();

		Query q = null;
		// species == "ALL"
		if(validSpeciesAsInt == SpeciesConstants.ALL.ordinal())
		{
			ConnectionInstance.getInstance();
			q = ConnectionInstance.getEntityManager().createNamedQuery("Genomes.findAll");
		}
		else
		{
			ConnectionInstance.getInstance();
			q = ConnectionInstance.getEntityManager().createNamedQuery("Genomes.getGenomesBySpecies");
			q.setParameter("speciesID", (long)validSpeciesAsInt);
		}
		@SuppressWarnings("unchecked")
		List<Genomes> genomesList = (List<Genomes>)q.getResultList();
        
		String genomeInfoAndData = "";
		for(Genomes g : genomesList)
			genomeInfoAndData += g.getGenomeInfoAndData();

        em.close();

        return genomeInfoAndData;
    }
}
