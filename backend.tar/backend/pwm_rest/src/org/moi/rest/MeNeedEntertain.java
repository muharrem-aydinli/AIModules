package org.moi.rest;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import org.json.JSONException;
 
/**
 * @author Muharrem Aydinli
 *
 */

@Path("/meneedentertain")
public class MeNeedEntertain {
 
	  @GET
	  @Produces("application/json")
	  public Response convertFtoC() throws JSONException {
		  
		  	StringBuilder sb = new StringBuilder();
		  	try {
				// adapted from https://www.mkyong.com/java/how-to-execute-shell-command-from-java/  
				Process p = Runtime.getRuntime().exec("/usr/games/fortune");
				p.waitFor();
		
				BufferedReader reader =
						new BufferedReader(new InputStreamReader(p.getInputStream()));
		
				String line = "";
				sb.append("Presented to you by fortune\n");
				sb.append("BSD Experimental\n\n");
				while ((line = reader.readLine())!= null) {
					sb.append(line + "\n");
				}
		  	}
		  	catch(Exception e)
		  	{
		  		sb.append("Well done, you broke me!\n");
		  	}
	 
			String result = sb.toString();
			return Response.status(200).entity(result).build();
	  }
}