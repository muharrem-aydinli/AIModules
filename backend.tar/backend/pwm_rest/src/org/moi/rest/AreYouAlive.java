package org.moi.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Muharrem Aydinli
 *
 */

@Path("/areyoualive")
public class AreYouAlive {
	/* Get actual class name to be printed on */
	private static final Logger LOG = LogManager.getLogger(AreYouAlive.class);
	
	@GET
	@Produces("application/xml")
	public String imAlive() {
		
		LOG.debug("Hello this is a debug message");
		LOG.info("Hello this is an info message");
		LOG.error("Hello this is an error message");
		LOG.fatal("Hello this is a fatal message");
 
		String result = "I'm alive and breathing";
		return "<AreYouAlive>" + result + "</AreYouAlive>";
	}
}
