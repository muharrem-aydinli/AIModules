/**
 * 
 */
package org.moi.rest;

import java.io.File;
import java.io.FileNotFoundException;
/**
 * @author Muharrem Aydinli
 *
 */
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.moi.jsonObjects.DeleteHelper;
import org.moi.jsonObjects.ExecutableCaller;
import org.moi.jsonObjects.ReadHelper;
import org.moi.jsonObjects.JsonObjectForScoring;
import org.moi.jsonObjects.WriteHelper;
import org.moi.utils.ValidationUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

@Path("/scoring")
@Consumes("application/json")
@Produces("application/json")
public class Scoring {
	/* Get actual class name to be printed on */
	private static final Logger LOG = LogManager.getLogger(Scoring.class);
	
	//@Context
    //UriInfo uriInfo;
    //@Context
    //Response response;
    @Context
    ServletContext servletContext;
    //@Context
    //Request request;
	@POST
	@Path("/doScore")
	@Consumes("application/json; charset=UTF-8")
	// { "JSON_String" : [ {"WhatSequence" : 2},{"SpeciesSequence" : "0"},{"WhatMatrix" : 2},{"AnimalClassMatrix" : "0"},{"FASTA" : {">foo" : "AAAA",">foobar" : "CCCC"}},{"Matrix" : {">bar" : "2 2 2 2",">baz" : "3 3 3 3"}},{"MinThreshold" : "6"},{"MaxDeficit" : "100"},{"ModuleFilterActivate" : "0"}]}
	
	@Produces("application/json")
	public Response score(final String jsonInput) 
	{
		LOG.debug("<score>");
		boolean isInputJSONKeysAndValuesValid = false;
		JsonNode jsonNodeInput = null;

		try{
			// check if jsonInput is well formed json
			File file = 
					new File(servletContext.getRealPath("/WEB-INF/classes/Schema/input.json.schema"));

			String jsonInputSchema = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
			
			final JsonNode jsonNodeInputSchema = JsonLoader.fromString(jsonInputSchema);
			jsonNodeInput = JsonLoader.fromString(jsonInput);

			LOG.debug("Size of root JsonInput: " + jsonNodeInput.size());
			
			final JsonSchemaFactory jsonSchemaFactory = JsonSchemaFactory.byDefault();

	        final JsonSchema schema = jsonSchemaFactory.getJsonSchema(jsonNodeInputSchema);

	        ProcessingReport report;

	        report = schema.validate(jsonNodeInput);
	        boolean isJsonInputValid = report.isSuccess();
	        System.out.println(isJsonInputValid);
	        
	        Iterator<ProcessingMessage> procMessageIterator = report.iterator();
	        while(procMessageIterator.hasNext())
	        {
	        	ProcessingMessage procMessage = procMessageIterator.next();
	        	LOG.error("JSON schema validation error: " + procMessage.getMessage());
	        }
	        
			isInputJSONKeysAndValuesValid =
	        		ValidationUtils.isJSONKeysAndValuesValid(jsonNodeInput);
		}
		catch (FileNotFoundException e)
		{
			LOG.error("FileNotFoundException:\n", e.getStackTrace(), e.getMessage());
		} catch (IOException e) {
			LOG.error("IOException:\n", e.getStackTrace(), e.getMessage());
		} catch (ProcessingException e) {
			LOG.error("ProcessingException:\n", e.getStackTrace(), e.getMessage());
		}
		
		if(isInputJSONKeysAndValuesValid == false)
		{
			LOG.error("JSON Keys and Values were not valid.");
			return Response.status(300).build();
		}
		
		// Write jsonInput to file
		String dnaSavedFileName = ""; 
		String matrixSavedFileName = "";
		
		if(jsonNodeInput.get("JSON_String").get(0).findValue("WhatSequence").asInt() == 1
			&& jsonNodeInput.get("JSON_String").get(1).findValue("SpeciesSequence").asText() != "0")
			dnaSavedFileName = WriteHelper.writeFileToHDD("species", jsonNodeInput);
		if(jsonNodeInput.get("JSON_String").get(2).findValue("WhatMatrix").asInt() == 1
			&& jsonNodeInput.get("JSON_String").get(3).findValue("AnimalClassMatrix").asText() != "0")
			matrixSavedFileName = WriteHelper.writeFileToHDD("animalClass", jsonNodeInput);
		if(jsonNodeInput.get("JSON_String").get(4).findValue("FASTA").asText() != "null")
			dnaSavedFileName = WriteHelper.writeFileToHDD("sequence", jsonNodeInput); 
		if(jsonNodeInput.get("JSON_String").get(5).findValue("Matrix").asText() != "null")
			matrixSavedFileName = WriteHelper.writeFileToHDD("matrix", jsonNodeInput);
		
		// Call tessWms and Save output to file
		String outputSavedFileName = 
				ExecutableCaller.CallTessWmsAndSaveOutput(dnaSavedFileName, matrixSavedFileName, 
						servletContext.getRealPath("/WEB-INF/classes/Executable/tessWms"),
						jsonNodeInput.get("JSON_String").get(6).findValue("MinThreshold").asText(),
						jsonNodeInput.get("JSON_String").get(7).findValue("MaxDeficit").asText());
		
		if(outputSavedFileName == null)
		{
			String errorString = "{ \"Error\" : \"Something went wrong. Probably the executable could not be called.\"}";
			return Response.status(200).entity(errorString).build();
		}
		
		// Read saved output
		List<String> resultList = ReadHelper.getTessWmsResultFromFile(outputSavedFileName);
		
		ObjectMapper mapper = new ObjectMapper();

		LOG.debug("JsonInput:\n" + jsonInput);
		String jsonInString = "";
		try
		{	
			JsonObjectForScoring startJsonObject = new JsonObjectForScoring();
			
			startJsonObject.childElemtsToString(resultList);
			
			jsonInString = mapper.writeValueAsString(startJsonObject);
			
			// e.g. when result shall be sent by email, this block can zip and save that file.
			//String resultJSONFilename = WriteHelper.writeFile("resultJSON_", jsonInString);
			//String resultJSONZippedFilename = WriteHelper.zipFileAndSave(resultJSONFilename);
			
			// Workaround for Tess executable: if sequence.lenght < (matrix.length)/4 no valid json is returned
			//jsonInString = jsonInString.replaceAll(",[\\s]*}", " }");
			
			LOG.debug("result before filter for modules:\n" + jsonInString);
			
			// Modules filtering
			byte shouldFilterForModules = (byte)jsonNodeInput.get("JSON_String").get(8)
											.findValue("ModuleFilterActivate").asInt();
			
			LOG.debug("Should filter for modules: " + (shouldFilterForModules == (byte)1 ? "YES" : "NO"));
				
			// Module Filtering is, for the moment, done by angular-client 
			if(shouldFilterForModules == 0)
			{;}
			else if(shouldFilterForModules == 1)
			{;}
			
			LOG.debug("result after filter for modules:\n" + jsonInString);
			
			// Delete generated files.
			DeleteHelper.deleteFileFromDisk(dnaSavedFileName);
			DeleteHelper.deleteFileFromDisk(matrixSavedFileName);
			DeleteHelper.deleteFileFromDisk(outputSavedFileName);
			
			return Response.status(200).entity(jsonInString).build();
			// From https://stackoverflow.com/questions/18445593/getting-a-zip-file-with-a-java-rest-client-resteasy
			// e.g. when result shall be sent by email, this block can zip and save that file.
			/*File file = new File(Paths.get("/tmp").toString() + File.separator + resultJSONZippedFilename);
		    ResponseBuilder response = Response.ok((Object) file);
		    response.header("Content-Disposition","attachment; filename="+resultJSONZippedFilename);
		    response.header("Content-Encoding","gzip");
		    return response.build();*/
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		LOG.debug("</score>");
		
		return Response.status(300).build();
  	}
}