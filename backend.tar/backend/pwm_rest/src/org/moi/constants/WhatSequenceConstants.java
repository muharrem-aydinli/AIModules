package org.moi.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Muharrem Aydinli
 *
 */

public enum WhatSequenceConstants {

	SEQUENCES_FROM_DB(1),
    OWN_SEQUENCES(2);

    private int validNumber;

    
    WhatSequenceConstants(int number)
    {
    	this.validNumber = number;
    }
    
    public int getValidNumber()
    {
    	return validNumber;
    }
 
    // adapted from https://howtodoinjava.com/core-java/enum/java-enum-string-example/
  //****** Reverse Lookup Implementation************//
    
    //Lookup table
    private static final Map<Integer, WhatSequenceConstants> lookup = new HashMap<>();
  
    //Populate the lookup table on loading time
    static
    {
        for(WhatSequenceConstants env : WhatSequenceConstants.values())
        {
            lookup.put(env.getValidNumber(), env);
        }
    }
  
    //This method can be used for reverse lookup purpose
    public static WhatSequenceConstants get(int number)
    {
        return lookup.get(number);
    }
}
