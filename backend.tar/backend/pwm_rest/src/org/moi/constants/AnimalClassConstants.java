package org.moi.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Muharrem Aydinli
 *
 */

public enum AnimalClassConstants {

	NONE("0"),
	FUNGI("FUNGI"),
	INSECTS("INSECTS"),
	NEMATODES("NEMATODES"),
	PLANTS("PLANTS"),
	UROCHORDATES("UROCHORDATES"),
	VERTEBRATES("VERTEBRATES"),
	ALL("ALL");

    private String animalClass;
   
    AnimalClassConstants(String animalClass)
    {
    	this.animalClass = animalClass;
    }
    
    public String getValidAnimalClass()
    {
    	return animalClass;
    }
 
    // adapted from https://howtodoinjava.com/core-java/enum/java-enum-string-example/
  //****** Reverse Lookup Implementation************//
    
    //Lookup table
    private static final Map<String, AnimalClassConstants> lookup = new HashMap<>();
  
    //Populate the lookup table on loading time
    static
    {
        for(AnimalClassConstants env : AnimalClassConstants.values())
        {
            lookup.put(env.getValidAnimalClass(), env);
        }
    }
  
    //This method can be used for reverse lookup purpose
    public static AnimalClassConstants get(String animalClass)
    {
        return lookup.get(animalClass);
    }
}
