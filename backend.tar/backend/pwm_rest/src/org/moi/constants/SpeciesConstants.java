package org.moi.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Muharrem Aydinli
 *
 */

public enum SpeciesConstants {

	NONE("0"),
	HOMO_SAPIENS("HOMO SAPIENS"),
	RATTUS_NORVEGICUS("RATTUS NORVEGICUS"),
	ALL("ALL");

    private String species;
   
    SpeciesConstants(String species)
    {
    	this.species = species;
    }
    
    public String getValidSpecies()
    {
    	return species;
    }
 
    // adapted from https://howtodoinjava.com/core-java/enum/java-enum-string-example/
  //****** Reverse Lookup Implementation************//
    
    //Lookup table
    private static final Map<String, SpeciesConstants> lookup = new HashMap<>();
  
    //Populate the lookup table on loading time
    static
    {
        for(SpeciesConstants env : SpeciesConstants.values())
        {
            lookup.put(env.getValidSpecies(), env);
        }
    }
  
    //This method can be used for reverse lookup purpose
    public static SpeciesConstants get(String species)
    {
        return lookup.get(species);
    }
}
