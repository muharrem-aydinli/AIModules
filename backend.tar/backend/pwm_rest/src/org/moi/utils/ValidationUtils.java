package org.moi.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.moi.constants.AnimalClassConstants;
import org.moi.constants.SpeciesConstants;
import org.moi.constants.WhatMatrixConstants;
import org.moi.constants.WhatSequenceConstants;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.primitives.Bytes;
import com.google.common.primitives.Ints;

/**
 * @author Muharrem Aydinli
 *
 */

public class ValidationUtils {
    
	/* Get actual class name to be printed on */
	private static final Logger LOG = LogManager.getLogger(ValidationUtils.class);
	
	/**
	 * This method checks if keys match Fasta format, and DNA values match
	 * allowed DNA bases, and Matrix values are numerical and a multiple
	 * of four
	 * @param jsonNodeInput: Parsed Json Input String
	 * @return true: keys and values are valid
	 */
	public static boolean isJSONKeysAndValuesValid(JsonNode jsonNodeInput)
	{
		LOG.debug("<isJSONKeysAndValuesValid>");
		
		boolean isJsonValid = true;
		
		// is key value valid
		Iterator<Map.Entry<String, JsonNode>> fields = jsonNodeInput.fields();
		while (fields.hasNext()) {
		   Map.Entry<String, JsonNode> entry = fields.next();
		   
		   byte whatSequence = (byte)entry.getValue().get(0).get("WhatSequence").asInt();
		   if(isJsonValid == true)
			   isJsonValid  = validateSequenceSelect(whatSequence);
		   else
		   {
			   LOG.error("Json seems to be invalid.");
			   return isJsonValid;
		   }
		   
		   String species = entry.getValue().get(1).get("SpeciesSequence").asText();
		   if(isJsonValid == true)
			   isJsonValid  = validateSpecies(species);
		   else
		   {
			   LOG.error("Selected Matrix radioButton not valid.");
			   return isJsonValid;
		   }
		   
		   byte whatMatrix = (byte)entry.getValue().get(2).get("WhatMatrix").asInt();
		   if(isJsonValid == true)
			   isJsonValid  = validateMatrixSelect(whatMatrix);
		   else
		   {
			   LOG.error("Json seems to be invalid.");
			   return isJsonValid;
		   }
		   
		   String animalClass = entry.getValue().get(3).get("AnimalClassMatrix").asText();
		   if(isJsonValid == true)
			   isJsonValid  = validateAnimalClass(animalClass);
		   else
		   {
			   LOG.error("Selected Matrix radioButton not valid.");
			   return isJsonValid;
		   }
		   
		   if(entry.getValue().get(4).get("FASTA").size() != 0)
		   {
			   Iterator<Map.Entry<String,JsonNode>> fastaNodes = entry.getValue().get(4).get("FASTA").fields();
			   if(isJsonValid == true)
				   isJsonValid  = validateFASTA(fastaNodes);
			   else
			   {
				   LOG.error("Selected Animalclass not valid.");
				   return isJsonValid;
			   }
		   }
		   else
		   	{;}// do nothing
		   
		   if(entry.getValue().get(5).get("Matrix").size() != 0)
		   {
			   Iterator<Map.Entry<String,JsonNode>> matrixNodes = entry.getValue().get(5).get("Matrix").fields();
			   if(isJsonValid == true)
				   isJsonValid = validateMatrix(matrixNodes);
			   else
			   {
				   LOG.error("DNA fasta invalid or DNA invalid or DNA Titles duplicate.");
				   return isJsonValid;
			   }
		   }
		   else
		   	{;}// do nothing
			   

		   try
		   {
			   int minThreshold = entry.getValue().get(6).get("MinThreshold").asInt();
			   int maxDeficit = entry.getValue().get(7).get("MaxDeficit").asInt();
			   byte modulesFilterActivate = (byte)entry.getValue().get(8).get("ModuleFilterActivate").asInt();
		   }
		   catch(Exception e)
		   {
			   LOG.error("MinThreshold of MaxDeficit invalid.");
			   isJsonValid = false;
		   }
		   
		   LOG.debug("JSON root key --> " + entry.getKey() + " JSON root  value-->" + entry.getValue());
		}
		LOG.debug("</isJSONKeysAndValuesValid>");
		
		return isJsonValid;
	}
	
	/**
	 * Validate FASTA DNA Block of input json
	 * @return
	 */
	private static boolean validateFASTA(Iterator<Map.Entry<String,JsonNode>> fastaNodes)
	{
		LOG.debug("<validateFASTA>");
		
		boolean isFastaBlockValid = true;
		List<String> fastaDNATitles = new ArrayList<String>();
		
		while (fastaNodes.hasNext()) {
			   Map.Entry<String, JsonNode> entryFasta = fastaNodes.next();
			   
			   if(entryFasta.getKey() != null && entryFasta.getValue().asText() != null)
				   LOG.debug("JSON Fasta DNA key --> " + entryFasta.getKey() + " JSON Fasta DNA value-->" + entryFasta.getValue());
			   else 
			   {
				   LOG.error("JSON Fasta DNA key or value not available!");
				   return false;
			   }
			   
			   if(isFastaBlockValid == true)
				   isFastaBlockValid = isKeyFastaFormat(entryFasta.getKey(), fastaDNATitles);
			   else 
			   {
				   LOG.error("DNA value not valid!");
				   return isFastaBlockValid;
			   }
			   
			   if(isFastaBlockValid == true)
			   {   
				   isFastaBlockValid = isValueDNA(entryFasta.getValue().textValue()
						   							.toUpperCase().trim().replaceAll(" ", ""));
			   }
			   else 
			   {
				   LOG.error("JSON Fasta DNA key not valid!");
				   return isFastaBlockValid;
			   }	   
		}
		
		if(!fastaDNATitles.isEmpty())
		{
			Set<String> set = new HashSet<String>(fastaDNATitles);

			if(set.size() < fastaDNATitles.size()){
				isFastaBlockValid = false;
				LOG.error("Fasta DNA Titles include duplicates. Please check them.");
			}
		}
		LOG.debug("</validateFASTA>");
		
		return isFastaBlockValid;
	}
	
	/**
	 * Key must have format >foo
	 * @return
	 */
	private static boolean isKeyFastaFormat(String fastaKey, List<String> fastaTitles)
	{
		LOG.debug("<isKeyFastaFormat>");
		char greaterThan = '>';
		fastaKey = fastaKey.toUpperCase().trim();
		if(fastaKey.charAt(0) == greaterThan)
		{
			fastaTitles.add(fastaKey);
			LOG.debug("</isKeyFastaFormat>");
			return true;
		}
		else
		{
			LOG.error("Fastakey: " + fastaKey + " not valid!");
			return false;
		}
	}
	
	/**
	 * Is DNA Base allowed
	 * @param dnaValue
	 * @return
	 */
	private static boolean isValueDNA(String dnaValue)
	{
		LOG.debug("<isValueDNA>");
		String validBases = "^[ACGT]+$";
		dnaValue = dnaValue.toUpperCase().trim().replaceAll(" ", "");
		Pattern p = Pattern.compile(validBases);
		Matcher m = p.matcher(dnaValue);
		boolean b = m.matches();
		if(b == true)
		{
			LOG.debug("</isValueDNA>");
			return true;
		}
		else
		{
			LOG.error("DNA value " + dnaValue + " has invalid Bases! Valid Bases are: " + validBases);
			return false;
		}
	}
	
	/**
	 * Validate Matrix block of input json
	 * @return
	 */
	private static boolean validateMatrix(Iterator<Map.Entry<String,JsonNode>> matrixNodes)
	{
		LOG.debug("<validateMatrix>");
		
		boolean isMatrixBlockValid = true;
		List<String> fastaMatrixTitles = new ArrayList<String>();
		
		while (matrixNodes.hasNext()) {
			   Map.Entry<String, JsonNode> entryMatrix = matrixNodes.next();
			   
			   if(entryMatrix.getKey() != null && entryMatrix.getValue() != null)
				   LOG.debug("JSON Matrix key --> " + entryMatrix.getKey() + " JSON Matrix value-->" + entryMatrix.getValue());
			   else
			   {
				   LOG.error("JSON Fasta Matrix key or value not available!");
				   return false;
			   }
			   
			   if(isMatrixBlockValid == true)
				   isMatrixBlockValid = isKeyFastaFormat(entryMatrix.getKey(), fastaMatrixTitles);
			   else 
			   {
				   LOG.error("Matrix value not valid");
				   return isMatrixBlockValid;
			   }
			   
			   if(isMatrixBlockValid == true)
				   isMatrixBlockValid = isMatrixNumericalAndMultipleOfFour(entryMatrix.getValue().asText());
			   else 
			   {
				   LOG.error("JSON Fasta Matrix key not valid!");
				   return isMatrixBlockValid;
			   }   
		}
		
		if(!fastaMatrixTitles.isEmpty())
		{
			Set<String> set = new HashSet<String>(fastaMatrixTitles);

			if(set.size() < fastaMatrixTitles.size()){
				isMatrixBlockValid = false;
				LOG.error("Fasta Matrix Titles include duplicates. Please check them.");
			}
		}
		
		LOG.debug("</validateMatrix>");
		
		return isMatrixBlockValid;
	}
	
	/**
	 * Is Matrix numerical and multiple of 4
	 * @param dnaValue
	 * @return
	 */
	private static boolean isMatrixNumericalAndMultipleOfFour(String matrixValue)
	{
		LOG.debug("<isMatrixNumericalAndMultipleOfFour>");
		boolean isMultipleOfFour = true;
		
		try
		{
			String[] strArr = matrixValue.split(" ");
			Integer.parseInt(Integer.toString((strArr.length/4)));
		}
		catch(NumberFormatException e) 
		{ 
			LOG.error("Matrix Not Multiple of Four\n", e.getMessage(), e.getStackTrace());
	        return false; 
	    } 
		catch(NullPointerException e) 
		{
			LOG.error("Something went wrong:\n", e.getMessage(), e.getStackTrace());
	        return false;
	    }
		
		LOG.debug("</isMatrixNumericalAndMultipleOfFour>");
		return isMultipleOfFour;
	}
	
	/**
	 * Is selected Matrix radio button valid
	 * @param whatMatrix: allowed are 	1 (use Matrix values from Jaspar DB, animal class has to be selected)
	 * 									2 (use own matrices, which have to be embedded in this Json)
	 * @return
	 */
	private static boolean validateMatrixSelect(byte whatMatrix)
	{
		LOG.debug("<validateMatrixSelect>");
		boolean isWhatMatrix = true;
		
		try
		{
			WhatMatrixConstants valid = WhatMatrixConstants.get(whatMatrix);
			if(valid == null
					|| valid.getValidNumber() != (int)whatMatrix)
				return false;
		}
		catch(Exception e) 
		{
			LOG.error("Something went wrong in validateMatrixSelect():\n", e.getMessage(), e.getStackTrace());
	        return false;
	    }
		
		LOG.debug("</validateMatrixSelect>");
		return isWhatMatrix;
	}
	
	/**
	 * Is selected Matrix  valid
	 * @param whatMatrix: Allowed are Constants in AnimalClassConstants
	 * @return
	 */
	private static boolean validateAnimalClass(String animalClass)
	{
		LOG.debug("<validateAnimalClass>");
		boolean isAnimalClass = true;
		
		try
		{
			AnimalClassConstants valid = AnimalClassConstants.get(animalClass);
			if(valid == null
					|| !animalClass.equals(valid.getValidAnimalClass()))
				return false;
		}
		catch(Exception e) 
		{
			LOG.error("Something went wrong in validateAnimalClass():\n", e.getMessage(), e.getStackTrace());
	        return false;
	    }
		
		LOG.debug("</validateAnimalClass>");
		return isAnimalClass;
	}
	
	/**
	 * Is selected Sequence radio button valid
	 * @param whatSequence: allowed are 	1 (use genomes values from DB, species has to be selected)
	 * 										2 (use own dna sequences, which have to be embedded in this Json)
	 * @return
	 */
	private static boolean validateSequenceSelect(byte whatSequence)
	{
		LOG.debug("<validateSequenceSelect>");
		boolean isWhatSequence = true;
		
		try
		{
			WhatSequenceConstants valid = WhatSequenceConstants.get(whatSequence);
			if(valid == null
					|| valid.getValidNumber() != (int)whatSequence)
				return false;
		}
		catch(Exception e) 
		{
			LOG.error("Something went wrong in validateSequenceSelect():\n", e.getMessage(), e.getStackTrace());
	        return false;
	    }
		
		LOG.debug("</validateSequenceSelect>");
		return isWhatSequence;
	}
	
	/**
	 * Is selected Sequence valid
	 * @param species: Allowed are Constants in SpeciesConstants
	 * @return
	 */
	private static boolean validateSpecies(String species)
	{
		LOG.debug("<validateSequenceSelect>");
		boolean isSpecies = true;
		
		try
		{
			SpeciesConstants valid = SpeciesConstants.get(species);
			if(valid == null
					|| !species.equals(valid.getValidSpecies()))
				return false;
		}
		catch(Exception e) 
		{
			LOG.error("Something went wrong in validateSpecies():\n", e.getMessage(), e.getStackTrace());
	        return false;
	    }
		
		LOG.debug("</validateSequenceSelect>");
		return isSpecies;
	}
}
