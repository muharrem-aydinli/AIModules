package moi.ego.main;

/**
 * @author Muharrem Aydinli
 */

public class SpeciesEnum {

	public enum Species
	{
		FUNGI(1),
		INSECTS(2),
		NEMATODES(3),
		PLANTS(4),
		UROCHORDATES(5),
		VERTEBRATES(6)
		; // semicolon needed when fields / methods follow


	    private final int species;

	    Species(int species) {
	        this.species = species;
	    }
	    
	    public int getSpecies() {
	        return this.species;
	    }
	}
}
