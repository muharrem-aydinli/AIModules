package moi.ego.main;

/**
 * @author Muharrem Aydinli
 */
public class NullOrEmptyException extends Exception {

	
	private static final long serialVersionUID = 9112822332913277949L;
	public NullOrEmptyException() { super(); }
	public NullOrEmptyException(String message) { super(message); }
	public NullOrEmptyException(String message, Throwable cause) { super(message, cause); }
	public NullOrEmptyException(Throwable cause) { super(cause); }	  
}
