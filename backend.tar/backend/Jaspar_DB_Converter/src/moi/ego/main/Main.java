package moi.ego.main;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/***
 * download files from
 * 2018:
 * http://jaspar.genereg.net/downloads/
 * e.g.:
 * http://jaspar.genereg.net/download/CORE/JASPAR2018_CORE_vertebrates_non-redundant_pfms_jaspar.txt
 * http://jaspar.genereg.net/download/CORE/JASPAR2020_CORE_vertebrates_non-redundant_pfms_jaspar.txt
 * put files in /bin/ Folder
 * @author Muharrem Aydinli
 *
 */
	
public class Main {
	
	private static int lineCounterForTable = 1;
	
	// Threshold of experiments/aligned sequences used to create matrix; anything above this threshold will be used.
	private static final int THRESHOLD_NUMBER_OF_EXPERIMENTS_FOR_MATRIX = 20; 
	
	public static void main(String[] args) throws Exception
	{
		String decodedPath = getAbsolutePathOfProgram();
		
		List<File> listOfTxtFiles = getTxtFilesFromPath(decodedPath);
		listOfTxtFiles.forEach(file -> System.out.println("Found files: " + file));
		
		for(File item : listOfTxtFiles)
		{
			try
			{
				List<String> lines = Files.readAllLines(item.toPath(), StandardCharsets.UTF_8);
				List<String> header = getHeader(lines);
				List<String> matrix = getMatrix(lines);
				List<String> cleanMatrix = cleanMatrix(matrix);
				List<String> cleanAndOneLinerMatrix = cleanAndOneLinerMatrix(cleanMatrix);
				List<String> acgtOrderedMatrix = orderMatrixByACGT(cleanAndOneLinerMatrix);
				List<String> acgtOrderedFinal = getStringOfHeaderAndOrderedMatrixByACGT(header, acgtOrderedMatrix);
				List<String> acgtOrderedFinalForDat = 
						getStringOfHeaderAndOrderedMatrixByACGTAsDatFile(item, header, acgtOrderedMatrix);
				
				writeOrderedListAsFasta(item, acgtOrderedFinal);
				writeOrderedListAsDatForPostgres(item, acgtOrderedFinalForDat);
			}
			catch (IOException ex)
			{}
		}
	}
	
	/***
	 * Gets the absolute Path this program is running in
	 * @return: String of absolute Path
	 */
	public static String getAbsolutePathOfProgram()
	{
		String path = Main.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String decodedPath = null;
		try {
			decodedPath = URLDecoder.decode(path, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return decodedPath;
	}
	
	/***
	 * Gets txt Files from the program running path. The txt Files must be in the same directory as the running application.
	 * Subfolders are not searched.
	 * A File consists of n Matrices in this structure:
	 * >MA0267.1	ACE2
	 * A  [    45      1      0     90      0      0     49 ]
	 * C  [    28     92    100     10      0    100     20 ]
	 * G  [    21      6      0      0    100      0     17 ]
	 * T  [     5      1      0      0      0      0     14 ]
	 * >MA0268.1	ADR1
	 * A  [    41      0      0      0      0     64     34 ]
	 * C  [    24    100     85    100    100      6     51 ]
	 * G  [    13      0      0      0      0     20      6 ]
	 * T  [    22      0     15      0      0     10      9 ]
	 * @param absolutePath: absolute PAth of running App.
	 * @return: List of txt Files as File objects.
	 * @throws NullOrEmptyException 
	 */
	public static List<File> getTxtFilesFromPath(String absolutePath) throws NullOrEmptyException
	{
		CheckParameterNullOrEmpty(absolutePath);
		File folder = new File(absolutePath);
		File[] listOfFiles = folder.listFiles();
		List<File> listOfTxtFiles = new ArrayList<File>();
		
		for (File file : listOfFiles) {
		    if (file.isFile() && file.toString().endsWith(".txt"))
		    {
		    	listOfTxtFiles.add(file);
		    }
		}
		return listOfTxtFiles;
	}
	
	/***
	 * Gets the headers (begins with >) from the read file,
	 * e.g.: >MA0267.1	ACE2, IMPORTANT not "\t" allowed or the frontend will invalidate JSON response
	 * Therefore "\t" is here replaced by " "
	 * @param lines: read file
	 * @return: List of all headers found.
	 * @throws NullOrEmptyException 
	 */
	public static List<String> getHeader(List<String> lines) throws NullOrEmptyException
	{
		CheckParameterNullOrEmpty(lines);
		List<String> headerList = new ArrayList<String>();
		for(String line : lines)
		{
			if(line.startsWith(">"))
				headerList.add(line.replace("\t", " "));
		}
		
		return headerList;
	}
	
	/***
	 * Gets the matrix (!begins with >) from the read file, 
	 * e.g.: 
	 * A  [    45      1      0     90      0      0     49 ]
 	 * C  [    28     92    100     10      0    100     20 ]
	 * G  [    21      6      0      0    100      0     17 ]
	 * T  [     5      1      0      0      0      0     14 ]
	 * @param lines: read file
	 * @return: List of all matrices found.
	 * @throws NullOrEmptyException 
	 */
	public static List<String> getMatrix(List<String> lines) throws NullOrEmptyException
	{
		CheckParameterNullOrEmpty(lines);
		
		List<String> matrix = new ArrayList<String>();
		for(String line : lines)
		{
			if(!line.startsWith(">"))
				matrix.add(line);
		}
		
		return matrix;
	}
	
	/***
	 * Matrices are Stripped of A,C,T,G,[,] and "\n" and "\t" is replaced by " "
	 * @param matrix
	 * @return
	 * @throws NullOrEmptyException
	 */
	public static List<String> cleanMatrix(List<String> matrix) throws NullOrEmptyException
	{
		CheckParameterNullOrEmpty(matrix);
		
		List<String> cleanMatrix = new ArrayList<String>();
		for(String line : matrix)
		{
			line = line.replace("A", "");
			line = line.replace("C", "");
			line = line.replace("G", "");
			line = line.replace("T", "");
			line = line.replace("[", "");
			line = line.replace("]", "");
			line = line.replace("\n", " ");
			line = line.replace("\t", " ");
			cleanMatrix.add(line);
		}
		
		return cleanMatrix;		
	}
	
	/***
	 * A File consists of n Matrices in this structure:
	 * >MA0267.1	ACE2
	 * A  [    45      1      0     90      0      0     49 ]
	 * C  [    28     92    100     10      0    100     20 ]
	 * G  [    21      6      0      0    100      0     17 ]
	 * T  [     5      1      0      0      0      0     14 ]
	 * >MA0268.1	ADR1
	 * A  [    41      0      0      0      0     64     34 ]
	 * C  [    24    100     85    100    100      6     51 ]
	 * G  [    13      0      0      0      0     20      6 ]
	 * T  [    22      0     15      0      0     10      9 ]
	 * 
	 * In the cleanMatrix List the structure is as follows:
	 * 45      1      0     90      0      0     49
	 * 28     92    100     10      0    100     20
	 * 21      6      0      0    100      0     17
	 * 5      1      0      0      0      0     14
	 * 
	 * This function concatenates 4 following lines: 0-3, 4-7, ...
	 * @param cleanMatrix
	 * @return
	 * @throws NullOrEmptyException
	 */
	public static List<String> cleanAndOneLinerMatrix(List<String> cleanMatrix) throws NullOrEmptyException
	{	
		CheckParameterNullOrEmpty(cleanMatrix);
		
		List<String> concatenatedMatrix = new ArrayList<String>();
		String temp = "";
		int linecounter = 0;
		for(String line : cleanMatrix)
		{
			if(linecounter < 4)
			{
				temp += line.toString();
				temp += " ";
				linecounter++;
			}
			else
			{
				concatenatedMatrix.add(temp);
				// reset all, but it is important to note, that the current line is already in the work pipeline
				// so linecounter is set to 1, temp is reset and filled
				linecounter = 1;
				temp = "";
				temp += line.toString();
			}
		}
		// concatenate last matrix here
		concatenatedMatrix.add(temp);
		
		return concatenatedMatrix;
	}
	
	/***
	 * Each line in the Parameter List is one Matrix. It has the structure AAA...CCC...GGG...TTT...
	 * This Function orders it like ACGTACGTACGT...
	 * @param cleanAndOneLinerMatrix
	 * @return
	 * @throws NullOrEmptyException 
	 */
	public static List<String> orderMatrixByACGT(List<String> cleanAndOneLinerMatrix) throws NullOrEmptyException
	{
		CheckParameterNullOrEmpty(cleanAndOneLinerMatrix);
		
		List<String> acgtOrderedMatrix = new ArrayList<String>();
		String temp = "";
		for(String line : cleanAndOneLinerMatrix)
		{
			line = line.trim().replaceAll(" +", " ");
			String[] str = line.split("\\s+");
			int lenght = str.length;
			int lengthOfOneBase = lenght/4;
			for(int i = 0; i < lengthOfOneBase; i++)
			{
				temp += str[i];						 //A
				temp += " ";
				temp += str[i + lengthOfOneBase * 1];//C
				temp += " ";
				temp += str[i + lengthOfOneBase * 2];//G
				temp += " ";
				temp += str[i + lengthOfOneBase * 3];//T
				temp += " ";
			}
			acgtOrderedMatrix.add(temp.trim());

			temp = "";		
		}
		
		
		return acgtOrderedMatrix;
	}
	
	/***
	 * Consolidates header and matrix into a string, header and matrix alternates per line.
	 * @param header
	 * @param acgtOrderedMatrix
	 * @return: String which has in the first line the header, in the second line the ordered matrix, in the third
	 * line the next header, in the forth line the next matrix, ...
	 * @throws Exception
	 */
	public static List<String> getStringOfHeaderAndOrderedMatrixByACGT(List<String> header, List<String> acgtOrderedMatrix) throws Exception
	{
		CheckParameterNullOrEmpty(header);
		CheckParameterNullOrEmpty(acgtOrderedMatrix);
		
		int headerLength = header.size();
		int matrixLength = acgtOrderedMatrix.size();
		if(headerLength != matrixLength)
			throw new Exception("Headerlength and matrixlength are not equal!");
		
		List<String> result = new ArrayList<String>();
		for(int i = 0; i < headerLength; i++)
		{
			result.add(header.get(i));
			result.add(acgtOrderedMatrix.get(i));
		}
		
		return result;
	}
	
	/***
	 * Consolidates header and matrix into a string, header and matrix alternates per line.
	 * @param header
	 * @param acgtOrderedMatrix
	 * @return: String which has in the first line the header, in the second line the ordered matrix, in the third
	 * line the next header, in the forth line the next matrix, ...
	 * @throws Exception
	 */
	public static List<String> getStringOfHeaderAndOrderedMatrixByACGTAsDatFile(File item, List<String> header, List<String> acgtOrderedMatrix) throws Exception
	{
		CheckParameterNullOrEmpty(item);
		CheckParameterNullOrEmpty(header);
		CheckParameterNullOrEmpty(acgtOrderedMatrix);
		
		int headerLength = header.size();
		int matrixLength = acgtOrderedMatrix.size();
		if(headerLength != matrixLength)
			throw new Exception("Headerlength and matrixlength are not equal!");
		
		List<String> result = new ArrayList<String>();
		int speciesIndex = 0;
		
		if(item.toString().toLowerCase().contains("fungi"))
			speciesIndex = SpeciesEnum.Species.FUNGI.getSpecies();
		else if(item.toString().toLowerCase().contains("insects"))
			speciesIndex = SpeciesEnum.Species.INSECTS.getSpecies();
		else if(item.toString().toLowerCase().contains("nematodes"))
			speciesIndex = SpeciesEnum.Species.NEMATODES.getSpecies();
		else if(item.toString().toLowerCase().contains("plants"))
			speciesIndex = SpeciesEnum.Species.PLANTS.getSpecies();
		else if(item.toString().toLowerCase().contains("urochordates"))
			speciesIndex = SpeciesEnum.Species.UROCHORDATES.getSpecies();
		else if(item.toString().toLowerCase().contains("vertebrates"))
			speciesIndex = SpeciesEnum.Species.VERTEBRATES.getSpecies();
		
		
		for(int i = 0; i < headerLength; i++)
		{
			String[] matrixElements = acgtOrderedMatrix.get(i).split(" ");
			int numberOfExperimentsPerMatrix = Integer.parseInt(matrixElements[0]) + 
					Integer.parseInt(matrixElements[1]) + 
					Integer.parseInt(matrixElements[2]) + 
					Integer.parseInt(matrixElements[3]);
			
			String temp = "";
			temp += lineCounterForTable++ + ";";
			temp += header.get(i) + ";";
			temp += speciesIndex + ";";
			temp += acgtOrderedMatrix.get(i);
			if(numberOfExperimentsPerMatrix > THRESHOLD_NUMBER_OF_EXPERIMENTS_FOR_MATRIX)
				result.add(temp);
			else
			{
				System.out.println("Sum of experiments for matrix " + header.get(i) + ": " + 
					numberOfExperimentsPerMatrix);
				// decrease counter, jump to next iteration
				lineCounterForTable--;
				continue;
			}
		}
		
		return result;
	}
	
	/***
	 * Write fasta file with ordered matrix
	 * @param item
	 * @param acgtOrderedFinal
	 * @throws NullOrEmptyException
	 * @throws IOException
	 */
	private static void writeOrderedListAsFasta(File item, List<String> acgtOrderedFinal) throws NullOrEmptyException, IOException
	{
		CheckParameterNullOrEmpty(item);
		CheckParameterNullOrEmpty(acgtOrderedFinal);
		
		String newFilename = item.getAbsolutePath() + ".ordered";
		Path file = Paths.get(newFilename);
		System.out.println("Writing Fasta-file to: " + newFilename);
		Files.write(file, acgtOrderedFinal, Charset.forName("UTF-8"));
	}
	
	/***
	 * Write dat file with ordered matrix
	 * @param item
	 * @param acgtOrderedFinal
	 * @throws NullOrEmptyException
	 * @throws IOException
	 */
	private static void writeOrderedListAsDatForPostgres(File item, List<String> acgtOrderedFinal) throws NullOrEmptyException, IOException
	{
		CheckParameterNullOrEmpty(item);
		CheckParameterNullOrEmpty(acgtOrderedFinal);
		
		String newFilename = item.getAbsolutePath() + ".dat";
		Path file = Paths.get(newFilename);
		System.out.println("Writing Dat-file to: " + newFilename);
		Files.write(file, acgtOrderedFinal, Charset.forName("UTF-8"));
	}
	
	public static void CheckParameterNullOrEmpty(Object o) throws NullOrEmptyException
	{
		if(o == null || o == "")
			throw new NullOrEmptyException();
	}
}
