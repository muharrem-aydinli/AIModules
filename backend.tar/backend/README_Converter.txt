It is written in Java and converts all .txt files from jaspar websites that are in the same folder as the app.

The pfm can be downloaded from 
http://jaspar.genereg.net/downloads/
 * e.g.:
 * http://jaspar.genereg.net/download/CORE/JASPAR2018_CORE_vertebrates_non-redundant_pfms_jaspar.txt

They are available for multiple species and have the format

>MA0266.1	ABF2
A  [    18      9      0      0    100      0     95 ]
C  [    39      9    100      0      0      0      2 ]
G  [    25      2      0      0      0    100      2 ]
T  [    18     80      0    100      0      0      2 ]

The converter converts this to Fasta Format (.txt.ordered)
>MA0266.1	ABF2
18 39 25 18 9 9 2 80 0 100 0 0 0 0 0 100 100 0 0 0 0 0 100 0 95 2 2 2

acgtacgtacgt...
This can be used directly for the tesswms binary.

The converter converts also to the dat format (.txt.dat)
3;>MA0266.1	ABF2;1;18 39 25 18 9 9 2 80 0 100 0 0 0 0 0 100 100 0 0 0 0 0 100 0 95 2 2 2
This file format is use by dockerfile to COPY the pfms directly into the postgres db.
