'use strict';

/**
 * @ngdoc overview
 * @name workspaceAngularWithYeomanApp
 * @description
 * # workspaceAngularWithYeomanApp
 *
 * Main module of the application.
 */
angular
  .module('workspaceAngularWithYeomanApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'LocalStorageModule',
    '720kb.tooltips'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/tool.html',
        controller: 'ToolCtrl',
        controllerAs: 'tool'
      })
      .when('/tool', {
        templateUrl: 'views/tool.html',
        controller: 'ToolCtrl',
        controllerAs: 'tool'
      })
    .when('/utils', {
      templateUrl: 'views/utils.html',
      controller: 'UtilsCtrl',
      controllerAs: 'utils'
    })
    .when('/contact', {
      templateUrl: 'views/contact.html',
      controller: 'ContactCtrl',
      controllerAs: 'contact'
      })
      .otherwise({
        redirectTo: '/'
      });
	})
  .config(function (localStorageServiceProvider) {
  	localStorageServiceProvider
    .setPrefix('pwm');
	})
	
	.service('sharedProperties', function() {
		var currentLanguage = englishTexts;
		return {
			getCurrentLanguage: function() {
				return currentLanguage;
			},
			setCurrentLanguage: function(value) {
				currentLanguage = value;
			}
		};
	})
	.service('languageImages', function() {
		var languageImages = languageImage;
		return {
			getLanguageImages: function() {
				return languageImages;
			}
		};
	});
 
