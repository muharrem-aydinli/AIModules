'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller
 * @description
 * colors
 */

 /*var sequenceAndMatrixColors = [
   "aqua",
   "lime",
   "black",
   "maroon",
   "teal",
   "blue",
   "navy",
   "fuchsia",
   "olive",
   "gray",
   "purple",
   "green",
   "yellow",
   "red",
   "silver",
   "#F0F8FF",
   "#FAEBD7",
   "#00FFFF",
   "#7FFFD4",
   "#F0FFFF",
   "#F5F5DC",
   "#FFE4C4",
   "#000000",
   "#FFEBCD",
   "#0000FF",
   "#8A2BE2",
   "#A52A2A",
   "#DEB887",
   "#5F9EA0",
   "#7FFF00",
   "#D2691E",
   "#FF7F50",
   "#6495ED",
   "#FFF8DC",
   "#DC143C",
   "#00FFFF",
   "#00008B",
   "#008B8B",
   "#B8860B",
   "#A9A9A9",
   "#006400",
   "#BDB76B",
   "#8B008B",
   "#556B2F",
   "#FF8C00",
   "#9932CC",
   "#8B0000",
   "#E9967A",
   "#8FBC8F",
   "#483D8B",
   "#2F4F4F",
   "#00CED1",
   "#9400D3",
   "#FF1493",
   "#00BFFF",
   "#696969",
   "#1E90FF",
   "#B22222",
   "#FFFAF0",
   "#228B22",
   "#FF00FF",
   "#DCDCDC",
   "#F8F8FF",
   "#FFD700",
   "#DAA520",
   "#808080",
   "#008000",
   "#ADFF2F",
   "#F0FFF0",
   "#FF69B4",
   "#CD5C5C",
   "#4B0082",
   "#FFFFF0",
   "#F0E68C",
   "#E6E6FA",
   "#FFF0F5",
   "#7CFC00",
   "#FFFACD",
   "#ADD8E6",
   "#F08080",
   "#E0FFFF",
   "#FAFAD2",
   "#D3D3D3",
   "#90EE90",
   "#FFB6C1",
   "#FFA07A",
   "#20B2AA",
   "#87CEFA",
   "#778899",
   "#B0C4DE",
   "#FFFFE0",
   "#00FF00",
   "#32CD32",
   "#FAF0E6",
   "#FF00FF",
   "#800000",
   "#66CDAA",
   "#0000CD",
   "#BA55D3",
   "#9370DB",
   "#3CB371",
   "#7B68EE",
   "#00FA9A",
   "#48D1CC",
   "#C71585",
   "#191970",
   "#F5FFFA",
   "#FFE4E1",
   "#FFE4B5",
   "#FFDEAD",
   "#000080",
   "#FDF5E6",
   "#808000",
   "#6B8E23",
   "#FFA500",
   "#FF4500",
   "#DA70D6",
   "#EEE8AA",
   "#98FB98",
   "#AFEEEE",
   "#DB7093",
   "#FFEFD5",
   "#FFDAB9",
   "#CD853F",
   "#FFC0CB",
   "#DDA0DD",
   "#B0E0E6",
   "#800080",
   "#663399",
   "#FF0000",
   "#BC8F8F",
   "#4169E1",
   "#8B4513",
   "#FA8072",
   "#F4A460",
   "#2E8B57",
   "#FFF5EE",
   "#A0522D",
   "#C0C0C0",
   "#87CEEB",
   "#6A5ACD",
   "#708090",
   "#FFFAFA",
   "#00FF7F",
   "#4682B4",
   "#D2B48C",
   "#008080",
   "#D8BFD8",
   "#FF6347",
   "#40E0D0",
   "#EE82EE",
   "#F5DEB3",
   "#F5F5F5",
   "#FFFF00",
   "#9ACD32"
 ];*/

// Adapted from http://martin.ankerl.com/2009/12/09/how-to-create-random-colors-programmatically/
// HSV values in [0..1[
// returns [r, g, b] values from 0 to 255
function hsvToRGB(h, s, v)
{
  var h_i = parseInt(h*6);
  var f = h*6 - h_i;
  var p = v * (1 - s);
  var q = v * (1 - f*s);
  var t = v * (1 - (1 - f) * s);
  var r, g, b;
  
  switch(h_i)
  {
	  case(0):
		r = v; g = t; b = p;
		break;
	  case(1):
		r = q; g = v; b = p;
		break;
	  case(2):
		r = p; g = v; b = t;
		break;
	  case(3):
		r = p; g = q; b = v;
		break;
	  case(4):
		r = t; g = p; b = v;
		break;
	  case(5):
		r = v; g = p; b = q;
		break;
  }

  return [parseInt(r*256), parseInt(g*256), parseInt(b*256)];
}

// use golden ratio
var golden_ratio_conjugate = 0.618033988749895;
var h = Math.random(); // use random start value
var s = Math.random();
var v = Math.random();
function getRandomRGB() {
  h += golden_ratio_conjugate;
  h %= 1;
  s += golden_ratio_conjugate;
  s %= 1;
  v += golden_ratio_conjugate;
  v %= 1;
  return hsvToRGB(h, 0.5, 0.95);
  //return hsvToRGB(h, s, v);
}
