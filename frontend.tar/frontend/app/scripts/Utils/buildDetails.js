'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller
 * @description
 * buildDetails: Details window content is generated
 */

function buildDetailsForScoring(arrayOfOnlySequences, arrayOfOnlyMatrices, parsedResultJSON, countOfMatrixElements, globalCountOfHits, matrixCheckboxes)
{
	var detailsHTML = "<title>TFBS</title>";
	detailsHTML += "<meta charset='UTF-8'>";
	detailsHTML += "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
	detailsHTML += "<button id='btnExportResult' onclick='exportResult()'>Export Result</button>";
	detailsHTML += "<script type='text/javascript'>function exportResult(){" + 
						"var downloadURL;" +
						"var dataType = 'application/vnd.ms-excel';" +
						"var tableElement = document.getElementById('hitResults');" +
						"var tableData = tableElement.outerHTML.replace(/ /g, '%20');" +
						"var fileName = 'tfbs_hits.xls';" +
						"downloadURL = document.createElement('a');" +
						
						"document.body.appendChild(downloadURL);" +
						
						"if(navigator.msSaveOrOpenBlob){" +
						"	var blob = new Blob(['\ufeff', tableData], {" +
						"		type: dataType" +
						"	});" +
						"	navigator.msSaveOrOpenBlob( blob, fileName);" +
						"}else{" +
						"	downloadURL.href = 'data:' + dataType + ', ' + tableData;" +
						"	downloadURL.download = fileName;" +
						"	downloadURL.click();" +
						"}" +
						"}</script>";
	var detailsHTMLtemp = "";
	var tabulator = "&emsp;";
	var doubleTabulator = tabulator + tabulator;
	var tripleTabulator = tabulator + tabulator + tabulator;
	var quadrupelTabulator = tabulator + tabulator + tabulator + tabulator;
	
	detailsHTML += "<table style='width:100%' border='1' id='hitResults'>" + 
							"<tr>" + 
								"<th>Sequence Name</th>" +
								"<th>Sequence Length</th>" +
								"<th>Matrix Title</th>" +
								//"<th>Matrix</th>" +
								"<th>Matrix Length</th>" +
								"<th>Hit No.</th>" +
								"<th>Hit Sense</th>" +
								"<th>Hit Start</th>" +
								"<th>Hit Stop</th>" +
								"<th>Hit Score (La)</th>" +
								"<th>Hit Max log likelihood ratio score (Lm) or matrix possible</th>" +
								"<th>Difference (Ld) (maxscore(Lm) - score(La))</th>" +
								"<th>Hit Oligo</th>" +
							"</tr>";
	
	for(var i = 0; i < Object.keys(parsedResultJSON.WMS).length; ++i)
	{
	 	var sequenceKey = Object.keys(parsedResultJSON.WMS)[i];
	 	var sequenceValue = parsedResultJSON.WMS[sequenceKey];
	 	detailsHTMLtemp += "<tr><td><b>" + sequenceValue.Title + "</b></td>";
	 	detailsHTMLtemp += "<td>" + sequenceValue.Length + "</td>";
	 	detailsHTML += detailsHTMLtemp;
	 	detailsHTMLtemp = "";
	 	
	 	var firstMatrixDetected = 0;
	 	var firstMatrixInserted = 0;
	 	var matrixDefined = 0;
	 	for(var j = 0; j < countOfMatrixElements; ++j)
	 	{
			// Workaround because some "Matrix"+i gets deleted in tools.js filterResponseByModule() when module filter is activated
			if(parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)] !== undefined 
				&& isMatrixCheckboxEnabled(parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)].Title, matrixCheckboxes) )
			{
				// Because Hits start not always with Hit1, Hit2 but Hit4, Hit7; This flas does keep it orderly.
				var hitCounter = 1;
				
				var matrixKey = Object.keys(parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)]);
				var matrixValue = parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)];
				if(firstMatrixInserted !== 0)
				{
					detailsHTMLtemp += "<td>" +"</td>";
					detailsHTMLtemp += "<td>" +"</td>";
				}
				detailsHTMLtemp += "<td>" + matrixValue.Title + "</td>";
				//detailsHTMLtemp += "<td>" + "</td>";
				detailsHTMLtemp += "<td>" + matrixValue.Length + "</td>";
				
				if(globalCountOfHits !== 0)
				{
					var isMatrixNameAdded = false;
					
					for(var k = 0; k < globalCountOfHits; ++k)
					{
						if(parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)]["Hit" + (k + 1)] !== undefined)
						{
							if(!isMatrixNameAdded)
							{
								detailsHTML += detailsHTMLtemp;
								isMatrixNameAdded = true;
							}
							var hitValue = parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)]["Hit" + (k + 1)];
							if(k>0
								&& firstMatrixInserted > 0
								|| matrixDefined > 0)
							{
								//detailsHTML += "<td>" + "</td>";
								detailsHTML += "<td>" + "</td>";
								detailsHTML += "<td>" + "</td>";
								detailsHTML += "<td>" + "</td>";
								detailsHTML += "<td>" + "</td>";
								firstMatrixDetected++;
							}

							detailsHTML += "<td>" + hitCounter + "</td>";
							detailsHTML += "<td>" + hitValue.Sense + "</td>";
							detailsHTML += "<td>" + hitValue.Start + "</td>";
							detailsHTML += "<td>" + hitValue.Stop + "</td>";
							detailsHTML += "<td>" + hitValue.La + "</td>";
							detailsHTML += "<td>" + hitValue.Lm + "</td>";
							detailsHTML += "<td>" + hitValue.Ld + "</td>";
							detailsHTML += "<td>" + hitValue.Oligo + "</td></tr>";
							++firstMatrixInserted;
							++matrixDefined;
							++hitCounter;
						}else{--matrixDefined;}
					}
				}
				else
				{
					for(var k = 0; k < globalCountOfHits; ++k)
					{
						detailsHTML += detailsHTMLtemp;
						var hitValue = parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)]["Hit" + (k + 1)];
						if(k>0
							&& parsedResultJSON.WMS[sequenceKey]["Matrix" + (j + 1)]["Hit" + (k + 1)] !== undefined)
						{
							//detailsHTML += "<td>" + "</td>";
							detailsHTML += "<td>" + "</td>";
							detailsHTML += "<td>" + "</td>";
							detailsHTML += "<td>" + "</td>";
							detailsHTML += "<td>" + "</td>";
							firstMatrixDetected++;
						}

						detailsHTML += "<td>" + (k + 1) + "</td>";
						detailsHTML += "<td>" + hitValue.Sense + "</td>";
						detailsHTML += "<td>" + hitValue.Start + "</td>";
						detailsHTML += "<td>" + hitValue.Stop + "</td>";
						detailsHTML += "<td>" + hitValue.La + "</td>";
						detailsHTML += "<td>" + hitValue.Lm + "</td>";
						detailsHTML += "<td>" + hitValue.Ld + "</td>";
						detailsHTML += "<td>" + hitValue.Oligo + "</td></tr>";
					}
				}
				detailsHTMLtemp = "";
			}
			else
				continue;
		}
		firstMatrixDetected = 0;
	}
	//detailsHTML = "</tr></table>";
	
	return detailsHTML;
}

function isMatrixCheckboxEnabled(matrixName, checkboxes)
{
	var isEnabled = false;
	
	for(var i = 0; i < checkboxes.length; i++)
	{
		if(matrixName === checkboxes[i].id
			&& checkboxes[i].checked === true)
			return true;
	}
	return isEnabled;
}

function buildDetails(aStr)
{
	var detailsHTML = "<title>Result</title>";
	detailsHTML += "<meta charset='UTF-8'>";
	detailsHTML += "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
	detailsHTML += "Result:<br/><br/>"
	detailsHTML += aStr;
	
	return detailsHTML;
}

function buildDetailsForModules(parsedResultJSON, countOccurencesOfModulesWithInterval)
{
	var detailsHTML = "<title>Modules</title>";
	detailsHTML += "<meta charset='UTF-8'>";
	detailsHTML += "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
	detailsHTML += "<button id='btnExportResult' onclick='exportResult()'>Export Result</button>";
	detailsHTML += "<script type='text/javascript'>function exportResult(){" + 
						"var downloadURL;" +
						"var dataType = 'application/vnd.ms-excel';" +
						"var tableElement = document.getElementById('hitResults');" +
						"var tableData = tableElement.outerHTML.replace(/ /g, '%20');" +
						"var fileName = 'modules.xls';" +
						"downloadURL = document.createElement('a');" +
						
						"document.body.appendChild(downloadURL);" +
						
						"if(navigator.msSaveOrOpenBlob){" +
						"	var blob = new Blob(['\ufeff', tableData], {" +
						"		type: dataType" +
						"	});" +
						"	navigator.msSaveOrOpenBlob( blob, fileName);" +
						"}else{" +
						"	downloadURL.href = 'data:' + dataType + ', ' + tableData;" +
						"	downloadURL.download = fileName;" +
						"	downloadURL.click();" +
						"}" +
						"}</script>";
	var detailsHTMLtemp = "";
	
	detailsHTML += "<table style='width:100%' border='1' id='hitResults'>" + 
							"<tr>" + 
								"<th>Sequence Name</th>" +
								"<th>Module</th>" +
								"<th>Module Start</th>" +
								"<th>Module End</th>" +
								"<th>Sense</th>" +
							"</tr>";
	
	for(var i = 0; i < Object.keys(parsedResultJSON.WMS).length; ++i)
	{
	 	var sequenceKey = Object.keys(parsedResultJSON.WMS)[i];
	 	var sequenceValue = parsedResultJSON.WMS[sequenceKey];
	 	detailsHTMLtemp += "<tr><td><b>" + sequenceValue.Title + "</b></td>";
	 	//detailsHTMLtemp += "<td>" + sequenceValue.Length + "</td>";
	 	detailsHTML += detailsHTMLtemp;
	 	detailsHTMLtemp = "";
	 	
	 	var firstModuleDetected = 0;
	 	for(var j = 0; j < countOccurencesOfModulesWithInterval.N[i].length; ++j)
	 	{
			// A Module looks like this in countOccurencesOfModulesWithInterval: "MA0658.1 LHX6;;MA0705.1 Lhx8##113;122##114;121##8##1"
			var module = countOccurencesOfModulesWithInterval.N[i][j].split('##');
			var moduleName = module[0].split(';;')[0] + "::" + module[0].split(';;')[1];
			var moduleStart = module[1].split(';')[0];
			var moduleStop = module[2].split(';')[1];
			var sense = "N";
			
			if(firstModuleDetected > 0)
				detailsHTML += "<td/>";
				
			detailsHTML += "<td>" + moduleName + "</td>";
			detailsHTML += "<td>" + moduleStart + "</td>";
			detailsHTML += "<td>" + moduleStop + "</td>";
			detailsHTML += "<td>" + sense + "</td></tr>";
			firstModuleDetected++;
		}
		for(var j = 0; j < countOccurencesOfModulesWithInterval.R[i].length; ++j)
	 	{
			// A Module looks like this in countOccurencesOfModulesWithInterval: "MA0658.1 LHX6;;MA0705.1 Lhx8##113;122##114;121##8##1"
			var module = countOccurencesOfModulesWithInterval.R[i][j].split('##');
			var moduleName = module[0].split(';;')[0] + "::" + module[0].split(';;')[1];
			var moduleStart = module[1].split(';')[0];
			var moduleStop = module[2].split(';')[1];
			var sense = "R";
			
			if(firstModuleDetected > 0)
				detailsHTML += "<td/>";
			
			detailsHTML += "<td>" + moduleName + "</td>";
			detailsHTML += "<td>" + moduleStart + "</td>";
			detailsHTML += "<td>" + moduleStop + "</td>";
			detailsHTML += "<td>" + sense + "</td></tr>";
			firstModuleDetected++;
		}
		
		firstModuleDetected = 0;
	}
	
	return detailsHTML;
}
