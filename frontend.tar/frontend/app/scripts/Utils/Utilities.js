'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller
 * @description
 * Utilities: Shared Functions
 */

function matrixAsFourColumns(matrixSpacingAfterNewline, aMatrixAsString, matrixSeparator)
{
	var matrixArr = [];
	matrixArr = aMatrixAsString.split(' ');
	var aMatrixAsFourColumns = "A " + matrixSpacingAfterNewline + "C " + matrixSpacingAfterNewline + "G " + matrixSpacingAfterNewline + "T " + matrixSeparator;
	
	for(var i = 1; i <= matrixArr.length; ++i)
	{
		aMatrixAsFourColumns += matrixSpacingAfterNewline + matrixArr[i - 1];
		aMatrixAsFourColumns += " ";
		if(i%4 === 0)
		{
			aMatrixAsFourColumns += matrixSeparator;
		}
	}
	
	return aMatrixAsFourColumns;
}
