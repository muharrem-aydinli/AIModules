'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller
 * @description
 * languages
 */

 var germanTexts = {
   toolIntro:
	  "Suchen von TFBSs und Modulen in DNA-Sequenzen",
   dnaSequenceInputField :
     "DNA-Sequenz im Fasta-Format eingeben:\n " +
       " > Sequenzname\n " +
       " aagtccc",
   dnaSequenceInputFieldPlaceholder :
     "DNA-Sequenz im Fasta-Format eingeben.",
   dnaSequenceInputError :
     "Bitte DNA-Sequenz eingeben.",
   matrixSequenceInputError :
     "Bitte Matrix eingeben.",
   dataSourceChoose :
     "Datenquelle für das Scoring wählen.",
   dataSourceSeqChoose :
     "Datenquelle für DNA Sequenz wählen.",
   errorDNAInput :
     "DNA Sequenz eingeben!",
   errorDNATooLong :
     "DNA Sequenz zu lang!",
   errorDNAFastaFormat :
     "Fasta Format muss mit '>' beginnen!",
   errorMatrixInput :
     "Matrix eingeben!",
   errorMatrixTooLong :
     "Matrix ist zu lang!",
   errorMatrixFormat :
     "Matrix Format muss mit '>' beginnen!",
   minThreshold:
	 "Minimum Score Threshold (La: log likelihood ratio score)",
   minThresholdTooltip:
     "Nur log likelihood ratio scores (La) größer diesem Wert als Ergebnis ausgeben. Für Details siehe 'Contact'",
   maxDeficit:
	 "Maximum log likelihood Defizit (Ld)",
   maxDeficitThreshold:
     "Nur (maxscore - score = Ld) kleiner diesem Wert als Ergebnis ausgeben. (Max Log Likelihood ratio score(Lm) - log likelihood ratio score(La) = Maximum log likelihood deficit(Ld))",
   activateModulesSearch:
     "Soll das Ergebnis auf gemeinsame Module gefiltert werden:\n 1. Mindestens zwei Sequenzen müssen eingegeben sein\n 2. Gefundene TFBSs (Transcription Factor Binding Sites) befindet sich auf n Sequenzen.\n     n kann weiter unten als Schwellenwert definiert weden, nachdem die Checkbox angeklickt wurde.\n 3. Zwei TFBSs befinden sich mindestens auf je zwei Sequenzen. Die Differenz\n     der Basenpositionen der beiden TFBS auf der einen Sequenz darf sich höchstens\n     um +/- 200 bp von der anderen Sequenz unterscheiden",
   receiveEmail :
     "Wollen Sie eine Email mit den Ergebnissen erhalten?",
   matrixInputField :
     "\tMatrix eingeben im Format (A C G T). Uracil (U) durch Thymin (T) ersetzen:\n " +
       "\t > Matrixname\n " +
       "\t 1 2 3 4\n " +
       "\t 4 5 6 7\n",
   matrixInputFieldPlaceholder :
     "Bitte Matrizen eingeben.",
   aYes :
     "Ja",
   errorInvalidEmail:
     "Emailformat ist nicht valide.",
   titleRestartButton:
	 "Alles muss neu eingegeben werden. Aktuelle Ergebnisse gehen verloren.",
   rescoreNotAllowed:
	  "Bitte Seite neu laden.",
   contactText:
	  "Für Kontaktdaten bitte untigem Link folgen.",
   introductionOnMain:
	  "AIModules ermöglicht es Ihnen Transkriptionsfaktorbindestellen (TFBSs) und Module auf DNA mittels eigenen Matrizen oder der JASPAR 2022 Datenbank zu ermitteln.",
   introductionOnUtils:
	  "Kleine Hilfsmittel, die das Leben vereinfachen.",
   utilsSequences2Frequences:
	  "Sequenzen zu Frequenzen Konverter",
   utilsSequences2FrequencesIntro:
	  "Gewünschten Matrixnamen im Fasta-Format eingeben.\n " +
	  "Darunter zu konvertierende RNA(U->T)/DNA-Sequenzen.\n" +
	  "Je Sequenz neue Zeile.\n" +
	  "Sequenzen müssen alle gleich lang sein.\n" +
	  "Ein Matrixname pro Lauf.\n" +
       " > Matrixname\n " +
       " aagtccc\n" +
       "  ccttaac\n",
	warningResultMayBeWiderThanScreen:
		"",
	svgConvert:
		"SVG kann mit der freien Software GIMP in die Formate EPS oder TIFF konvertiert werden.",
	licenses:
		"Lizenzbedingungen",
	TFBSScoring:
		"Für die Bestimmung von TFBS und das Scoring wurden diese Paper verwendet:",
	modulesHint:
		"Tipp: \nZuerst ohne Modulefilterung mit einem low Score und Matrizen aus der Datenbank nach TFBSs suchen. \nDann die gewünschten Matrizen kopieren und mit diesen nach Modulen suchen.",
	workaroundForHighLoad:
		"Sollte die Berechung/das Rendern zu lange dauern, starten Sie bitte neu und versuchen bitte Folgendes: \nDen Schwellenwert für die Modulefilterung unverändert lassen und/oder \nLa erhöhen und/oder \nLd verringern und/oder\nSequenzanzahl verringern",
	rnaToDNAConverted:
		"",
	precisionOfTFsOnSequencesTooltip:
		"Gibt an, auf wie vielen Sequenzen ein jeder TF vorkommen muss, damit dieser in die Modulefilterung mit eingeht.",
	precisionOfTFsOnSequences:
		"Schwellenwert, ab dem ein TF in die Modulefilterung eingeht (s. Punkt 2. oben):"
 };

 var englishTexts = {
   toolIntro:
	  "Search TFBSs and Modules in DNA-Sequences",
   dnaSequenceInputField :
     "Input here DNA-Sequence in Fasta-Format:\n " +
       " > sequence_name\n " +
       " aagtccc",
   dnaSequenceInputFieldPlaceholder :
     "Input DNA-Sequence in Fasta-Format here.",
   dnaSequenceInputError :
     "Please type DNA sequence.",
   matrixSequenceInputError :
     "Please input matrix.",
   dataSourceChoose :
     "Select Data Source for Scoring.",
   dataSourceSeqChoose :
     "Select Data Source for DNA Sequence.",
   errorDNAInput :
     "Input DNA-Sequence!",
   errorDNATooLong :
     "Input Sequence is Too long!",
   errorDNAFastaFormat :
     "Fasta Format must begin with '>'!",
   errorMatrixInput :
     "Input Matrix!",
   errorMatrixTooLong :
     "Matrix is Too long!",
   errorMatrixFormat :
     "Matrix Format must begin with '>'!",
   minThreshold:
	 "Minimum Score Threshold (La: log likelihood ratio score)",
   minThresholdTooltip:
     "Only show log likelihood ratio scores (La) bigger than this value. For details see 'Contact'",
   maxDeficit:
	 "Maximum log likelihood Deficit (Ld)",
   maxDeficitThreshold:
     "Only show scores which match: (maxscore - score = Ld) smaller than this value. (Max Log Likelihood ratio score(Lm) - log likelihood ratio score(La) = Maximum log likelihood deficit(Ld))",
   activateModulesSearch:
     "Should the filter for common modules be activated:\n    1. At least two Sequences have to be available\n    2. TFBS (Transcription Factor Binding Site) is common to n sequences.\n        The threshold for n can be defined below after checking the checkbox. \n    3. Any two TFBS are common in at least two sequences and differ from start to end only by +/- 200bps",
   receiveEmail :
     "Do you want to receive email with results?",
   matrixInputField :
     "\tInput Matrix formatted like (A C G T). Please replace Uracil (U) with Thymine (T):\n " +
       "\t > matrix_name\n " +
       "\t 0 1 2 3\n " +
       "\t 4 5 6 7\n ",
   matrixInputFieldPlaceholder :
     "Please insert matrices.",
   aYes :
     "Yes",
   errorInvalidEmail:
     "Email has no valid format.",
   titleRestartButton:
	 "Latest results will be lost.",
   rescoreNotAllowed:
	  "Please reload page.",
   contactText:
	  "Contacts are in Link below.",
   introductionOnMain:
	  "AIModules enables you to find transcription factor binding sites (TFBSs) and modules on DNA using own matrices or the JASPAR 2022 database.",
   introductionOnUtils:
	  "Here you can find small tools that help you be more productive.",
   utilsSequences2Frequences:
	  "Sequences to frequences Converter",
   utilsSequences2FrequencesIntro:
	  "Input random matrix name in Fasta-Format.\n " +
	  "Unterneath input RNA(U->T)/DNA sequences to convert.\n" +
	  "Each sequence must be on a new line.\n" +
	  "All sequences must have the same length.\n" +
	  "One matrixname at a time.\n" +
       " > matrixname\n " +
       " aagtccc\n" +
       "  ccttaac\n",
	warningResultMayBeWiderThanScreen:
		"",
	svgConvert:
		"SVG format may be converted to EPS or TIFF using free software GIMP.",
	licenses:
		"Licenses",
	TFBSScoring:
		"For locating and scoring the TFBSs these papers where used:",
	modulesHint:
		"Hint: \nFirst search for TFBSs without the module filtering functionality but with a low Score and Matrices \nfrom Database. \nThen copy needed Matrices and do a modules search with these matrices.",
	workaroundForHighLoad:
		"If scoring/redering should take too long, please restart and try the following: \nLeave threshold for module filtering unchanged and/or \nincrease La and/or \ndecrease Ld and/or\ntry with fewer sequences",
	rnaToDNAConverted:
		"",
	precisionOfTFsOnSequencesTooltip:
		"TFs have to be common to this amount of input sequences, to be considered for module filtering.",
	precisionOfTFsOnSequences:
		"Threshold for a TF to be considered for module filtering (see above under 2.):"
 };
 
var languageImage = [
      {language : "Deutsch", imageSource : "images/germany.png"},
      {language : "English", imageSource : "images/United_Kingdom.png"}
];
