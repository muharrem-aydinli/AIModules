'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the workspaceAngularWithYeomanApp
 */
angular.module('workspaceAngularWithYeomanApp')
  .controller('ToolCtrl', function ($scope, $http, localStorageService, sharedProperties, languageImages, $interval) {

    $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();

    $scope.inputSequenceDNA = "";
    
    // serverstation54
    $scope.callURL = 'https://bioinfo-wuerz.de';
    
    /* deactivated until smtp-server is available
    $scope.checkBoxForEmail = false;

    $scope.isCheckboxForEmail = function () {
      return $scope.checkBoxForEmail === false ? false : true;
    };

    $scope.emailAddress = "";

	$scope.regExEmail = /[\.\-_a-zA-Z0-9]{1,20}@[\.\-_a-zA-Z0-9]{1,20}\.[a-zA-Z0-9]{1,10}/;
	
    $scope.isEmailValid = function () {
      return $scope.emailAddress.contains("@") && $scope.emailAddress.contains(".");
    };*/
    
    $scope.checkboxForModuleFilter = false;

    $scope.inputMatrices = "";

    $scope.radioButtons = [{
        id : 1,
        name : "Jaspar 2022 Database"
    }, {
        id : 2,
        name : "Own Matrices"
    }];

    $scope.selectedRadioButton = {};
    
    $scope.radioButtonsSeq = [/*{
        id : 1,
        name : "Genome aus Datenbank"
    }, */{
        id : 2,
        name : "Own Sequences"
    }];

    $scope.selectedRadioButtonSeq = {};

    $scope.myRegEx = /^>/;

	$scope.selectedRadioButtonSeq.selectedID = "2";

    $scope.isButtonActivate = function()
    {
      if (dNAJSONValid === true
          && matrixJSONValid === true
          && $scope.selectedRadioButton.selectedID === "2"
          && $scope.selectedRadioButtonSeq.selectedID === "2"
		  || $scope.selectedRadioButton.selectedID === "1"
          && $scope.selectedDropDownItem !== ""
          && $scope.selectedDropDownItem !== "0"
          && $scope.selectedDropDownItem !== "empty"
          && $scope.selectedRadioButtonSeq.selectedID === "1"
          && $scope.selectedDropDownItemSpecies !== ""
          && $scope.selectedDropDownItemSpecies !== "0"
          && $scope.selectedDropDownItemSpecies !== "empty"
          || matrixJSONValid === true
          && $scope.selectedRadioButtonSeq.selectedID === "1"
          && $scope.selectedRadioButton.selectedID === "2"
          && $scope.selectedDropDownItemSpecies !== ""
          && $scope.selectedDropDownItemSpecies !== "0"
          && $scope.selectedDropDownItemSpecies !== "empty"        
          || dNAJSONValid === true
          && $scope.selectedRadioButtonSeq.selectedID === "2"
          && $scope.selectedRadioButton.selectedID === "1"
          && $scope.selectedDropDownItem !== ""
          && $scope.selectedDropDownItem !== "0"
          && $scope.selectedDropDownItem !== "empty")
        {return true;}
      else
        {return false;}
    };
    
    $scope.isCallSuccess = false;
    
    $scope.svgScaleFactor = 2;

	// Objects for local storage
	/*function submitToLocalStorage(key, val) {
   		return localStorageService.set(key, val);
	}

	function getItemFromLocalStorage(key) {
   		return localStorageService.get(key);
  	}

	function removeItemFromLocalStorage(key) {
   		return localStorageService.remove(key);
  	}*/

    var dNAJSONValid = false;
    var dNAJSON = "";
    $scope.dnaAsOneLiner = [];
    $scope.validateDNA = function()
    {
      // Reset
      dNAJSONValid = false;
      dNAJSON = "";

      var dnaResult = [];
      var dnatemp = $scope.inputSequenceDNA;
      dnatemp = dnatemp.trim();
      var dnatempArr = dnatemp.split('\n');
      var longDNAWarning = 0;

      for (var i = 0; i < dnatempArr.length; ++i)
      {
        if(dnatempArr[i] !== "")
        {
          dnaResult.push(dnatempArr[i].trim());
          if(dnatempArr[i].charAt(0) === '>' && longDNAWarning <= 500)
		  {
			  // Reset for next sequence
			  longDNAWarning = 0;
		  }
          else if(dnatempArr[i].charAt(0) !== '>')
			longDNAWarning += dnatempArr[i].length;
		  
        }
      }

      if(dnaResult.length === 1)
      {
        //$scope.errorDNA = "Please type Sequence";
        germanTexts.dnaSequenceInputError = "Bitte DNA-Sequenz eingeben.";
        englishTexts.dnaSequenceInputError = "Please type DNA sequence.";
        return;
      }

	  if(longDNAWarning > 500)
	  {
		  germanTexts.warningResultMayBeWiderThanScreen = "Warnung: Sequenz > 500 Basen. Das Ergebnis könnte über den Bildschirmrand hinausgehen. Sie müssen evtl. horizontal scrollen, um das gesamte Ergebnis zu sehen.";
		  englishTexts.warningResultMayBeWiderThanScreen = "Warning: Sequence > 500 bases. Result may be wider than your screen. You may have to scroll horizontally to see full result.";
	  }
	  else
	  {
		  germanTexts.warningResultMayBeWiderThanScreen = "";
		  englishTexts.warningResultMayBeWiderThanScreen =  "";
	  }
	
      // first index fasta header, next index dna ...
      $scope.dnaAsOneLiner = arrayOfOneLineFastaHeaderAndOneLineDNA(dnaResult);
      // only valid dna Chars
      var isDNABasesValid = validateDNABases($scope.dnaAsOneLiner);
      var isFastaHeaderFilled = false;
      if(!isDNABasesValid)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: Basensequenz enthält invalide Basen (valide: acgt).";
        englishTexts.dnaSequenceInputError = "Incorrect: DNA sequence has invalid Bases (valid: acgt).";
        return;
      }
      else
        {isFastaHeaderFilled = validateFastaHeaderFilled(dnaResult);}

      var isFastaHeaderDuplicate = false;
      if(!isFastaHeaderFilled)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: FASTA Header darf nicht leer sein.";
        englishTexts.dnaSequenceInputError = "Incorrect: FASTA Header cannot be null.";
        return;
      }
      else
        {isFastaHeaderDuplicate = validateFastaHeaderDuplicate(dnaResult);}

      var isHeaderFollowedByDNA = false;
      if(isFastaHeaderDuplicate)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: FASTA Header darf nicht doppelt vorkommen.";
        englishTexts.dnaSequenceInputError = "Incorrect: FASTA Header cannot be duplicate.";
        return;
      }
      else
        {isHeaderFollowedByDNA = validateHeaderFollowedByDNA($scope.dnaAsOneLiner);}

      if(!isHeaderFollowedByDNA)
      {
        germanTexts.dnaSequenceInputError = "Inkorrekt: FASTA Header ohne DNA-Sequenz nicht erlaubt.";
        englishTexts.dnaSequenceInputError = "Incorrect: FASTA Headers without a DNA sequence not allowed.";
        return;
      }
      else
      {
        makeJSONFromDNAArray($scope.dnaAsOneLiner);
        germanTexts.dnaSequenceInputError = "Fasta DNA Sequenz ist OK.";
        englishTexts.dnaSequenceInputError = "Fasta DNA Sequences OK.";
      }
    };

    function arrayOfOneLineFastaHeaderAndOneLineDNA(aDnaResult)
    {
      var oneLinerFasta = [];
      var tempString = "";
      for(var i in aDnaResult)
      {
        // < will be handled in validateDNABases()
        if(aDnaResult[i].charAt(0) === '>'
            || aDnaResult[i].charAt(0) === '<')
        {
          if(tempString !== "")
          {
            oneLinerFasta.push(tempString.replace(/ /g, ""));
            tempString = "";
          }
          oneLinerFasta.push(aDnaResult[i]);
        }
        else
        {
			if(convertRNAToDNA(aDnaResult[i]))
			{
				aDnaResult[i] = aDnaResult[i].replace(/u/gi, "t");
				germanTexts.rnaToDNAConverted = "Uracil (U) wurde mit Thymin (T) ersetzt.";
				englishTexts.rnaToDNAConverted = "Uracil (U) has been converted to Thymine (T).";
			}
			else
			{
				germanTexts.rnaToDNAConverted = "";
				englishTexts.rnaToDNAConverted = "";
			}
			
			tempString += aDnaResult[i].toUpperCase();
        }
      }
      // Check if tempString is not empty
      if(tempString !== "")
        {oneLinerFasta.push(tempString.replace(/ /g, ""));}

	  $scope.inputSequenceDNA = oneLinerFasta.toString().replace(/,/g, "\n");
	  
      return oneLinerFasta;
    }

	function convertRNAToDNA(aDnaResult)
    {
      var hasRNABeenConvertedToDNA = false;
      if (aDnaResult.charAt(0) !== '>'
          && aDnaResult.search(/[u]/i) !== -1)
      {
		    hasRNABeenConvertedToDNA = true;
	  }

      return hasRNABeenConvertedToDNA;
    }
    
    function validateDNABases(aDnaResult)
    {
      var isDNABasesValid = true;
      for(var i in aDnaResult)
      {
        if (!isDNABasesValid)
          {break;}

        if (aDnaResult[i].charAt(0) === '<'
            || aDnaResult[i].charAt(0) !== '>'
            && aDnaResult[i].search(/[^gatc]/i) !== -1)
        {
		      isDNABasesValid = false;
	      }
	      else
	      {
		      //The seq string contains only GATC
		      isDNABasesValid = true;
	      }
      }
      return isDNABasesValid;
    }

    function validateFastaHeaderFilled(aDnaResult)
    {
      for(var i in aDnaResult)
      {
        if(aDnaResult[i].charAt(0) === '>'
            && aDnaResult[i].length === 1)
          {return false;}
      }
      return true;
    }

    function validateFastaHeaderDuplicate(aDnaResult)
    {
      var fastaHeader = [];
      for(var i in aDnaResult)
      {
        if(aDnaResult[i].charAt(0) === '>')
          {fastaHeader[i] = aDnaResult[i];}
      }

      var r = [];
      o:for(var j = 0, n = fastaHeader.length; j < n; j++)
      {
        for(var x = 0, y = r.length; x < y; x++)
        {
            if(r[x]===fastaHeader[j]
                && r[x] !== undefined
                && fastaHeader[j] !== undefined)
            {
                return true;
            }
        }
        r[r.length] = fastaHeader[j];
      }
      return false;
    }

    function validateHeaderFollowedByDNA(aDnaAsOneLiner)
    {
      var headerCounter = 0;
      for(var i in aDnaAsOneLiner)
      {
        if(aDnaAsOneLiner[i].charAt(0) === '>')
          {++headerCounter;}
        else
          {--headerCounter;}
      }
      if(headerCounter === 0)
        {return true;}
      else
        {return false;}
    }

    function makeJSONFromDNAArray(aDnaAsOneLiner)
    {
      var i = 0;
      dNAJSON = "{\"FASTA\" : {";
      for(i; i < aDnaAsOneLiner.length; ++i)
      {
        dNAJSON += "\"" + aDnaAsOneLiner[i] + "\"" + " : " + "\"" + aDnaAsOneLiner[++i] + "\"";
        if(aDnaAsOneLiner[i+1] !== undefined)
         {dNAJSON += ",";}
      }
      dNAJSON += "}}";
      dNAJSONValid = isJsonString(dNAJSON);
      return dNAJSON;
    }

    $scope.languages = languageImages.getLanguageImages();

    $scope.translatePage = function(translateTo) {
      if (translateTo === "German")
      {
		sharedProperties.setCurrentLanguage(germanTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
        $scope.radioButtons[0].name = "Jaspar 2022 Datenbank";
        $scope.radioButtons[1].name = "Eigene Matrizen";
        $scope.radioButtonsSeq[0].name = "Eigene Sequenzen";
        //$scope.radioButtonsSeq[1].name = "Genome aus Datenbank";
      }
      else if (translateTo === "English")
      {
		sharedProperties.setCurrentLanguage(englishTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
        $scope.radioButtons[0].name = "Jaspar 2022 Database";
        $scope.radioButtons[1].name = "Own Matrices";
        $scope.radioButtonsSeq[0].name = "Own Sequences";
        //$scope.radioButtonsSeq[1].name = "Genomes from Database";
      }
    };

    var matrixJSONValid = false;
    var matrixJSON = "";
    $scope.matrixAsOneLiner = [];
    $scope.validateMatrix = function validateMatrix()
    {
      // Reset
      matrixJSONValid = false;
      matrixJSON = "";

      var matrixResult = [];
      var matrixtemp = $scope.inputMatrices;
      matrixtemp = matrixtemp.trim();
      var matrixtempArr = matrixtemp.split('\n');

      for (var i = 0; i < matrixtempArr.length; ++i)
      {
        if(matrixtempArr[i] !== "")
        {
          matrixResult.push(matrixtempArr[i].trim());
        }
      }

      if(matrixResult.length === 1)
      {
        //$scope.errorDNA = "Please type Sequence";
        germanTexts.matrixSequenceInputError = "Bitte Matrix eingeben.";
        englishTexts.matrixSequenceInputError = "Please input matrix.";
        return;
      }

      // first index header, next index numbers ...
      $scope.matrixAsOneLiner = arrayOfOneLineMatrixHeaderAndOneLineMatrix(matrixResult);
      $scope.matrixAsOneLiner = trimAllElements($scope.matrixAsOneLiner);
      // only numbers
      var isMatrixNumbersValid = validateMatrixNumbers($scope.matrixAsOneLiner);
      var isMatrixNumbersDividedByFour = false;
      if(!isMatrixNumbersValid)
      {
        germanTexts.matrixSequenceInputError = "Inkorrect: Wahrscheinlichkeiten sind nicht numerisch.";
        englishTexts.matrixSequenceInputError = "Incorrect: Probabilities are not numerical.";
        return;
      }
      else
        {isMatrixNumbersDividedByFour = validateMatrixNumbersDividedByFour($scope.matrixAsOneLiner);}

      var isHeaderFilled = false;
      if(!isMatrixNumbersDividedByFour)
      {
        germanTexts.matrixSequenceInputError = "Inkorrect: Wahrscheinlichkeiten sind kein Vielfaches von 4.";
        englishTexts.matrixSequenceInputError = "Incorrect: Probabilities are not a multiple of 4.";
        return;
      }
      else
        {isHeaderFilled = validateHeaderFilled(matrixResult);}

      var isHeaderDuplicate = false;
      if(!isHeaderFilled)
      {
        germanTexts.matrixSequenceInputError = "Inkorrect: Header darf nicht leer sein.";
        englishTexts.matrixSequenceInputError = "Incorrect: Header cannot be null.";
        return;
      }
      else
        {isHeaderDuplicate = validateHeaderDuplicate(matrixResult);}

      var isHeaderFollowedByProbabilities = false;
      if(isHeaderDuplicate)
      {
        germanTexts.matrixSequenceInputError = "Inkorrect: Header darf nicht doppelt vorkommen.";
        englishTexts.matrixSequenceInputError = "Incorrect: Header cannot be duplicate.";
        return;
      }
      else
        {isHeaderFollowedByProbabilities = validateHeaderFollowedByProbabilities($scope.matrixAsOneLiner);}

      if(!isHeaderFollowedByProbabilities)
      {
        germanTexts.matrixSequenceInputError = "Inkorrekt: Header ohne Wahrscheinlichkeiten nicht erlaubt.";
        englishTexts.matrixSequenceInputError = "Incorrect: Headers without probabilities not allowed.";
        return;
      }
      else
      {
        makeJSONFromMatrixArray($scope.matrixAsOneLiner);
        generateColorAndRectArrayForMatrices($scope.matrixAsOneLiner);
        germanTexts.matrixSequenceInputError = "Matrix ist OK.";
        englishTexts.matrixSequenceInputError = "Matrix OK.";
      }
    };

    function arrayOfOneLineMatrixHeaderAndOneLineMatrix(aMatrixResult)
    {
      var oneLiner = [];
      var tempString = "";
      for(var i in aMatrixResult)
      {
        // < will be handled in validateMatrixNumbers()
        if(aMatrixResult[i].charAt(0) === '>'
            || aMatrixResult[i].charAt(0) === '<')
        {
          if(tempString !== "")
          {
            oneLiner.push(tempString);
            tempString = "";
          }
          oneLiner.push(aMatrixResult[i]);
        }
        else
        {
          tempString += " " + aMatrixResult[i];
        }
      }
      // Check if tempString is not empty
      if(tempString !== "")
        {oneLiner.push(tempString);}

      return oneLiner;
    }

    function trimAllElements(aMatrixAsOneLiner)
    {
      var newMatrixAsOneLiner = [];
      for(var i in aMatrixAsOneLiner)
      {
        newMatrixAsOneLiner[i] = aMatrixAsOneLiner[i].trim();
      }
      return newMatrixAsOneLiner;
    }

    function validateMatrixNumbers(aMatrixResult)
    {
      var isMatrixValidAsNumbers = true;
      for(var i in aMatrixResult)
      {
        if (!isMatrixValidAsNumbers)
          {break;}

        if (aMatrixResult[i].charAt(0) === '<'
            || aMatrixResult[i].charAt(0) !== '>'
            && !isIntOrFloat(aMatrixResult[i]))
        {
          isMatrixValidAsNumbers = false;
        }
        else
        {
          //The seq string contains only numbers
          isMatrixValidAsNumbers = true;
        }
      }
      return isMatrixValidAsNumbers;
    }

    function isIntOrFloat(number)
    {
      var numArr = number.split(" ");
      var isOnlyNumbers = false;
      for(var i in numArr)
      {
        if(numArr[i] === "")
          {continue;}
        var n = Number(numArr[i]);
        if((n === +n && n === (n|0))
            || (n === +n && n !== (n|0)))
          {isOnlyNumbers = true;}
        else
          {return false;}
      }
      return isOnlyNumbers;
    }

    function validateMatrixNumbersDividedByFour(aMatrixResult)
    {
      if(aMatrixResult === undefined)
        {return false;}

      var isMatrixValidAsNumbers = true;
      for(var i in aMatrixResult)
      {
        if (!isMatrixValidAsNumbers)
          {break;}
        if (aMatrixResult[i].charAt(0) === '>')
        {
          {continue;}
        }
        else if(!Number.isInteger(aMatrixResult[i].split(" ").filter(function(i){ return i !== "";}).length/4))
        {
          //if probabilities are not a multiple of 4
          isMatrixValidAsNumbers = false;
        }
      }
      return isMatrixValidAsNumbers;
    }

    function validateHeaderFilled(aMatrixResult)
    {
      for(var i in aMatrixResult)
      {
        if(aMatrixResult[i].charAt(0) === '>'
            && aMatrixResult[i].length === 1)
          {return false;}
      }
      return true;
    }

    function validateHeaderDuplicate(aMatrixResult)
    {
      var header = [];
      for(var i in aMatrixResult)
      {
        if(aMatrixResult[i].charAt(0) === '>')
          {header[i] = aMatrixResult[i];}
      }

      var r = [];
      o:for(var j = 0, n = header.length; j < n; j++)
      {
        for(var x = 0, y = r.length; x < y; x++)
        {
            if(r[x]===header[j]
                && r[x] !== undefined
                && header[j] !== undefined)
            {
                return true;
            }
        }
        r[r.length] = header[j];
      }
      return false;
    }

    function validateHeaderFollowedByProbabilities(aMatrixAsOneLiner)
    {
      var headerCounter = 0;
      for(var i in aMatrixAsOneLiner)
      {
        if(aMatrixAsOneLiner[i].charAt(0) === '>')
          {++headerCounter;}
        else
          {--headerCounter;}
      }
      if(headerCounter === 0)
        {return true;}
      else
        {return false;}
    }

    function makeJSONFromMatrixArray(aMatrixAsOneLiner)
    {
      var i = 0;
      matrixJSON = "{\"Matrix\" : {";
      for(i; i < aMatrixAsOneLiner.length; ++i)
      {
        matrixJSON += "\"" + aMatrixAsOneLiner[i] + "\"" + " : " + "\"" + aMatrixAsOneLiner[++i] + "\"";
        if(aMatrixAsOneLiner[i+1] !== undefined)
         {matrixJSON += ",";}
      }
      matrixJSON += "}}";
      matrixJSONValid = isJsonString(matrixJSON);
      return matrixJSON;
    }

    function isJsonString(str)
    {
      try
      {
        JSON.parse(str);
      }
      catch (e)
      {
        return false;
      }
      return true;
    }

    var colorsForMatrices = [];
	$scope.allRects = [];
    function generateColorAndRectArrayForMatrices(matrixAsOneLiner)
    {
      for(var i in matrixAsOneLiner)
      {
        if(matrixAsOneLiner[i].charAt(0) === '>')
        {
    	    var matrixName = matrixAsOneLiner[i];
    	    matrixName = matrixName.replace(">", "");
	        matrixName = matrixName.trim();
    	    //colorsForMatrices[matrixName] = sequenceAndMatrixColors.pop();
    	    var randomRGB = getRandomRGB();
    	    colorsForMatrices[matrixName] = "rgb(" + randomRGB[0] + ", " + randomRGB[1]  + ", " + randomRGB[2] + ")";
    	    var matrixObj = {};
    	    matrixObj[matrixName] = [];
			$scope.allRects.push(matrixObj);
        }
      }
    }

    $scope.getScoring = function() {
		//resetRectAndCheckboxes();
	  //removeItemFromLocalStorage("allRects");
      var foo= {"foo":"bar", "bar":"223", "sequence":$scope.inputSequenceDNA};
      var sequenceRadioButtonSelect = "{\"WhatSequence\" : " + $scope.selectedRadioButtonSeq.selectedID + "}";
      var sequenceDropdownSelect = "{\"SpeciesSequence\" : " + "\"" + $scope.selectedDropDownItemSpecies + "\"" + "}";
      var matrixRadioButtonSelect = "{\"WhatMatrix\" : " + $scope.selectedRadioButton.selectedID + "}";
      var matrixDropdownSelect = "{\"AnimalClassMatrix\" : " + "\"" + $scope.selectedDropDownItem + "\"" + "}";
      var minThresholdValue = $scope.minThreshold === null ? $scope.defaultMinThreshold : $scope.minThreshold;
      var minThreshold = "{\"MinThreshold\" : " + "\"" + minThresholdValue + "\"" + "}";
      var maxDeficitValue = $scope.maxDeficit === null ? $scope.defaultMaxDeficit : $scope.maxDeficit;
      var maxDeficit = "{\"MaxDeficit\" : " + "\"" + maxDeficitValue + "\"" + "}";
      var activateModulesSearchValue = $scope.checkboxForModuleFilter === false ? "0" : "1";
      var activateModulesFilter = "{\"ModuleFilterActivate\" : " + "\"" + activateModulesSearchValue + "\"" + "}";
	
      var payload = "{ \"JSON_String\" : [ " + sequenceRadioButtonSelect + "," + sequenceDropdownSelect + "," + matrixRadioButtonSelect + "," + 
						matrixDropdownSelect;
						
      if(dNAJSON === "" || dNAJSON === null || dNAJSON === undefined || dNAJSON === 0)
      {
		dNAJSON = "{\"FASTA\" : null}";
		payload += "," + dNAJSON;
	  }
	  else 
	    payload += "," + dNAJSON;
      if(matrixJSON === "" || matrixJSON === null || matrixJSON === undefined || matrixJSON === 0)
      {
		matrixJSON = "{\"Matrix\" : null}";
		payload += "," + matrixJSON;
	  }
	  else
		payload += "," + matrixJSON;
		
	  payload += "," + minThreshold + "," + maxDeficit + "," + activateModulesFilter + "]}";
		
      var isPayloadJson = isJsonString(payload);
    
      if(isPayloadJson)
      {
		var setTimeoutID;
		beginTimer("start");
		setTimeoutID = $interval(function(){beginTimer("loop");}, 100);
		const start = Date.now();
		
        $scope.isLoading = true;
        deactivateControls();
        scrollToEndOfPage();
        
            $http({
              method: 'POST',
              headers: {
                    'Content-Type': 'application/json'
                },
              url: $scope.callURL + '/api/scoring/doScore/',
              data: payload
            }).then(function successCallback(response) {
				$scope.isCallSuccess = true;
				
				document.getElementById("btnDownloadSVG").title = $scope.activeTranslatedText.svgConvert;
				
				disableErrorSection("none");
				if( isErrorsInResponse(response) )
					{showError(response.data);}
				else
				{
				    /*document.getElementById("inputSequences").disabled = true;
				    document.getElementById("inputSequences").style.color = 'grey';
				    document.getElementById("inputMatrices").disabled = true;
				    document.getElementById("inputMatrices").style.color = 'grey';*/
   
				    $interval.cancel(setTimeoutID);
				    console.log("Result from Backend done = " + Math.fround((Date.now() - start) / 1000) + " seconds");
				    const resultDone = Date.now();
				    var isResponseJson = isJsonString(response.data.childElements);
				    if(!isResponseJson)
				    {
						$scope.loading = false;
						alert("Response-JSON is not valid!");
					}
				    
				    var wms = JSON.parse(response.data.childElements);
				    var moduleSearchDone = "";
				    // Should filter for modules?
				    if($scope.checkboxForModuleFilter
						&&hasEnoughSequences(wms))
				    {
						//let proceed = confirm("Response retrieved from Server\n Begin searching for modules on client?");
						//if (proceed === true)
						//{		
							console.log("Start module filtering = " + Math.fround((Date.now() - start) / 1000) + " seconds");				
							wms = getModuleFilteredResult(wms);
							$scope.responseData = wms;
							moduleSearchDone = Date.now();
							console.log("Stop module filtering = " + Math.fround((Date.now() - start) / 1000) + " seconds");	
							document.getElementById("moduleSearchDone").innerHTML = Math.fround((Date.now() - resultDone) / 1000);
						//}
						//else
						//{
							//alert("Program stopped by user.");
							//throw new Error("Program stopped by user.");
						//}
					}
					else if ($scope.checkboxForModuleFilter
						&& !hasEnoughSequences(wms))
						{
						document.getElementById("moduleSearchDone").innerHTML = "[Modules can only be calculated when more than one sequence is available]"
					}
					//let proceedRender = confirm("All done. Start rendering?");
					//if (proceedRender === true)
					//{
						console.log("Start rendering = " + Math.fround((Date.now() - start) / 1000) + " seconds");	
					
						$scope.parsedResultJSON = wms;
						showResultAsPicture(wms);
						scrollToEndOfPage();
					
						console.log("Stop rendering = " + Math.fround((Date.now() - start) / 1000) + " seconds");
						
						if($scope.checkboxForModuleFilter 
							&& hasEnoughSequences(wms))
							document.getElementById("renderDone").innerHTML = Math.fround((Date.now() - moduleSearchDone) / 1000);	
						else
							document.getElementById("renderDone").innerHTML = Math.fround((Date.now() - resultDone) / 1000);
					//}
					//else
					//{
						//alert("Program stopped by user.");
						//throw new Error("Program stopped by user");
					//}
				}
            }, function errorCallback(response) {
              showError( JSON.parse( "{ \"Error\" : " + "\"" + response.status + " = Service is probably unavailable." + "\"" + "}" ) );
            }).finally(function() {
				$scope.isLoading = false;
		});
        //  .then(function(response){ $scope.parsedResultJSON = response; });
      }
      else
      {
		$scope.loading = false;
        alert("JSON is not valid!");
      }
    };

	function beginTimer(cases)
	{
		switch(cases)
		{
			case "start":
				$scope.timeElapsedBegin = Date.now(); break;
			case "loop":
				$scope.timeElapsed = (Date.now() - $scope.timeElapsedBegin)/1000; break;
		}
	}
	
	function isErrorsInResponse(response)
	{
		if(response.data.Error !== undefined)
			{return true;}
		else
			{return false;}
	}
	
	function disableErrorSection(isDisable)
	{
		// "none" = not visible; "block" = visible
		document.getElementById("errorShow").style.display = isDisable;
	}
	
	function showError(response)
	{
		disableErrorSection("block");
		document.getElementById("errorShow").innerHTML = response.Error;
		document.getElementById("errorShow").style.color = 'red';
		document.getElementById("errorShow").style.fontWeight = "bold";
	}
	
	function deactivateControls()
	{
		deactivateScoreButton();
		deactivateSelectAnimalClassesDropDown();
		deactivateDemoButtons();
		deactivateSetScoreButtons();
		deactivateModuleCheckbox();
		deactivateMatrixRadioButtons();
		deactivateHumanPolyA();
	};
	
	function deactivateScoreButton()
	{
		document.getElementById("btnScore").disabled = true;
        document.getElementById("btnScore").style.color = 'grey';
        document.getElementById("btnScore").style.opacity = 0.6;
		document.getElementById("btnScore").style.cursor = 'not-allowed';
		document.getElementById("btnScore").title = $scope.activeTranslatedText.rescoreNotAllowed;
	};
	
	function deactivateSelectAnimalClassesDropDown()
	{
		document.getElementById("selectAnimalClasses").disabled = true;
        document.getElementById("selectAnimalClasses").style.color = 'grey';
        document.getElementById("selectAnimalClasses").style.opacity = 0.6;
		document.getElementById("selectAnimalClasses").style.cursor = 'not-allowed';
	};
	
	function deactivateDemoButtons()
	{
		document.getElementById("btnDemoSeq1").disabled = true;
        document.getElementById("btnDemoSeq1").style.color = 'grey';
        document.getElementById("btnDemoSeq1").style.opacity = 0.6;
		document.getElementById("btnDemoSeq1").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq2").disabled = true;
        document.getElementById("btnDemoSeq2").style.color = 'grey';
        document.getElementById("btnDemoSeq2").style.opacity = 0.6;
		document.getElementById("btnDemoSeq2").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq3").disabled = true;
        document.getElementById("btnDemoSeq3").style.color = 'grey';
        document.getElementById("btnDemoSeq3").style.opacity = 0.6;
		document.getElementById("btnDemoSeq3").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq4").disabled = true;
        document.getElementById("btnDemoSeq4").style.color = 'grey';
        document.getElementById("btnDemoSeq4").style.opacity = 0.6;
		document.getElementById("btnDemoSeq4").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq4.2").disabled = true;
        document.getElementById("btnDemoSeq4.2").style.color = 'grey';
        document.getElementById("btnDemoSeq4.2").style.opacity = 0.6;
		document.getElementById("btnDemoSeq4.2").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq5").disabled = true;
        document.getElementById("btnDemoSeq5").style.color = 'grey';
        document.getElementById("btnDemoSeq5").style.opacity = 0.6;
		document.getElementById("btnDemoSeq5").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq6").disabled = true;
        document.getElementById("btnDemoSeq6").style.color = 'grey';
        document.getElementById("btnDemoSeq6").style.opacity = 0.6;
		document.getElementById("btnDemoSeq6").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq7").disabled = true;
        document.getElementById("btnDemoSeq7").style.color = 'grey';
        document.getElementById("btnDemoSeq7").style.opacity = 0.6;
		document.getElementById("btnDemoSeq7").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq8").disabled = true;
        document.getElementById("btnDemoSeq8").style.color = 'grey';
        document.getElementById("btnDemoSeq8").style.opacity = 0.6;
		document.getElementById("btnDemoSeq8").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq9").disabled = true;
        document.getElementById("btnDemoSeq9").style.color = 'grey';
        document.getElementById("btnDemoSeq9").style.opacity = 0.6;
		document.getElementById("btnDemoSeq9").style.cursor = 'not-allowed';
		
		document.getElementById("btnDemoSeq10").disabled = true;
        document.getElementById("btnDemoSeq10").style.color = 'grey';
        document.getElementById("btnDemoSeq10").style.opacity = 0.6;
		document.getElementById("btnDemoSeq10").style.cursor = 'not-allowed';
	}
	
	function deactivateSetScoreButtons()
	{
		document.getElementById("btnSetDefaultScore").disabled = true;
        document.getElementById("btnSetDefaultScore").style.color = 'grey';
        document.getElementById("btnSetDefaultScore").style.opacity = 0.6;
		document.getElementById("btnSetDefaultScore").style.cursor = 'not-allowed';
		
		document.getElementById("btnSetLowScore").disabled = true;
        document.getElementById("btnSetLowScore").style.color = 'grey';
        document.getElementById("btnSetLowScore").style.opacity = 0.6;
		document.getElementById("btnSetLowScore").style.cursor = 'not-allowed';
	}
	
	function deactivateModuleCheckbox()
	{
		document.getElementById("checkboxForModuleFilter").disabled = true;
        document.getElementById("checkboxForModuleFilter").style.color = 'grey';
        document.getElementById("checkboxForModuleFilter").style.opacity = 0.6;
		document.getElementById("checkboxForModuleFilter").style.cursor = 'not-allowed';
	}
	
	function deactivateMatrixRadioButtons()
	{
		// Not yet implemented
	}
	
	function deactivateHumanPolyA()
	{
		document.getElementById("btnRNADemoSeq1").disabled = true;
        document.getElementById("btnRNADemoSeq1").style.color = 'grey';
        document.getElementById("btnRNADemoSeq1").style.opacity = 0.6;
		document.getElementById("btnRNADemoSeq1").style.cursor = 'not-allowed';
	}
	
	$scope.arrayOfOnlySequences = [];
	$scope.arrayOfOnlyMatrices = [];
    function showResultAsPicture(responseData)
    {
      //$scope.isShowResultAsPicture = true;
      generateArrayOfOnlySequences();
      generateArrayOfOnlyMatrices();
      draw(responseData);
    }
    
    function generateArrayOfOnlySequences()
    {
		for(var i = 0; i < $scope.dnaAsOneLiner.length; ++i)
		{
			if(i%2 === 1)// [0] is Fasta header, [1] is DNA Sequence, ...
				{$scope.arrayOfOnlySequences.push($scope.dnaAsOneLiner[i]);}
		}
	}
	
	function generateArrayOfOnlyMatrices()
    {
		for(var i = 0; i < $scope.matrixAsOneLiner.length; ++i)
		{
			if(i%2 === 1)// [0] is Matrix header, [1] is matrix, ...
				{$scope.arrayOfOnlyMatrices.push($scope.matrixAsOneLiner[i]);}
		}
	}

    function draw(responseData) {
      var countOfSequenceElements = Object.keys(responseData.WMS).length;
      //var ctx = document.getElementById('myCanvas').getContext('2d');

      var maxlinelength = 0;
      var maxlines = 0;
      for(var i = 1; i <= countOfSequenceElements; i++)
      {
        var linelength = parseInt(responseData.WMS["Sequence" + i].Length) * $scope.svgScaleFactor;
        maxlines++;
        if(linelength > maxlinelength)
        {maxlinelength = linelength;}
      }

	  // Empty SVG Container
	  //d3.select("#matrixHits").selectAll("svg").remove();
      //Make an SVG Container
      var svgContainer = d3.select("#matrixHits").append("svg:svg")
                                         .attr("width", (maxlinelength + 300))
                                        .attr("height", (maxlines * 3 * 20 + 20)); // * 3, because 1 line for sequence name, 1 for sequence, 1 for space for hits

	  
      for(var j = 1; j <= countOfSequenceElements; j++)
      {
        var originOfX = 30 * $scope.svgScaleFactor;
        var originOfY = 20 + sequenceYSeparator;
        drawSequence(originOfX, originOfY, svgContainer, responseData.WMS["Sequence" + j], $scope.arrayOfOnlySequences[j - 1]);
      }
		//submitToLocalStorage("allRects", $scope.allRects);
    }

	var sequenceYSeparator = 0;
    function drawSequence(originOfX, originOfY, svgContainer, DNAResultSequence, sequenceAsString)
    {
      var lineheight = 2 * $scope.svgScaleFactor;

		var tooltip = d3.select("body")
			.append("div")
			.style("position", "absolute")
			.style("z-index", "10")
			.style("visibility", "hidden")
			.text(sequenceAsString)
			.attr("width", "600px")
			.attr("height", "28px")
			.attr("font-size", "12px")
			.style("background-color", 'lightsteelblue')
			.attr("font-family", "sans-serif")
			.style("padding", "5px");

      //Draw the Rectangle
      var forRectangle = svgContainer.append("text")
                                 .attr("x", 0)             
								.attr("y", originOfY)
								.attr("dy", ".5em")
								.style("font-weight", "bold")
								.style("font-size", "20")
								.attr("opacity", "1")
								.text(DNAResultSequence.Title)
								.on("mouseover", function(){
									tooltip.transition().duration(200).style("opacity", 0.9);
									return tooltip.style("visibility", "visible");})
								.on("mousemove", function(){
									return tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px");})
								.on("mouseout", function(){
									tooltip.transition().duration(500).style("opacity", 0);
									return tooltip.style("visibility", "hidden");});
      svgContainer.append("rect")
                                 .attr("x", originOfX)
                                 .attr("y", (originOfY + 30))
                                 .attr("rx", 2)
								 .attr("ry", 2)
                                 .attr("width", (DNAResultSequence.Length) * $scope.svgScaleFactor)
                                 .attr("height", lineheight);
      
      for(var baseCount = 500; baseCount < DNAResultSequence.Length; baseCount += 500)
      {
		  svgContainer.append("text")
                                .attr("x", originOfX - 2 + baseCount * $scope.svgScaleFactor)             
								.attr("y", (originOfY + 10))
								.attr("font-size", "15px")
								.attr("dx", "-0.7em")
								.attr("dy", ".4em")
								.attr("opacity", "1")
								.text(baseCount);
		  svgContainer.append("rect")
								.attr("x", originOfX - 2 + baseCount * $scope.svgScaleFactor)
                                .attr("y", (originOfY + 17))
                                .attr("rx", 2)
								.attr("ry", 2)
                                .attr("width", 2)
                                .attr("height", lineheight + 4);
		  
                                 /*.attr("x", baseCount )             
								.attr("y", (originOfY + 15))
								.attr("font-size", "15px")
								.attr("dx", "-0.7em")
								.attr("dy", ".4em")
								.attr("opacity", "1")
								.text(baseCount);*/
	  }
	  
	  svgContainer.append("text")
                                 .attr("x", originOfX)             
								.attr("y", (originOfY + 30))
								.attr("font-size", "15px")
								.attr("dx", "-0.7em")
								.attr("dy", ".4em")
								.attr("opacity", "1")
								.text("1");
	  svgContainer.append("text")
                                 .attr("x", (originOfX + (DNAResultSequence.Length * $scope.svgScaleFactor)))
								.attr("y", (originOfY + 30))
								.attr("font-size", "15px")
								//.attr("dx", DNAResultSequence["Length"])
								.attr("dy", ".4em")
								.attr("opacity", "1")
								.text(DNAResultSequence.Length);
      
	  // align sequences
	  sequenceYSeparator += 60;
	  
	  if(countOfMatrixElements == 0)
	  {
		countOfMatrixElements = Object.keys(DNAResultSequence).length; 
	    
	    if(globalCountOfHits < countOfMatrixElements)
			globalCountOfHits = countOfMatrixElements;
	  }
  
      //countOfMatrixElements = countOfMatrixElements -4;
      for(var i = 1; i <= countOfMatrixElements; i++)
      {
		  if(DNAResultSequence["Matrix" + i] !== undefined)
		  {
			drawMatrix(originOfX, originOfY, svgContainer, DNAResultSequence["Matrix" + i], i);
		  }
		  else
			continue;
      }
    }

    var currentMatrixColor = "";
    function drawMatrix(originOfX, originOfY, svgContainer, matrixResult, matrixIndex)
    {
	  // teporary save
	  //var tempGlobalCountOfHits = globalCountOfHits;
	  
	  // Reset Flag
	  //globalCountOfHits = 0;
	  
      var countOfHitElements = Object.keys(matrixResult).length;
      countOfHitElements = countOfHitElements - 4;
      
      if(globalCountOfHits === 0 || $scope.checkboxForModuleFilter == false && globalCountOfHits < countOfHitElements)
		globalCountOfHits = countOfHitElements;
		
      currentMatrixColor = colorsForMatrices[matrixResult.Title.trim()];
      for(var i = 1; i <= globalCountOfHits; i++)
      {
		if(matrixResult["Hit" + i] !== undefined)
			drawHits(originOfX, originOfY, svgContainer, matrixResult["Hit" + i], matrixResult.Title.trim(), $scope.arrayOfOnlyMatrices[matrixIndex - 1]);
      }
      
      // set flag from temporary backup
      //globalCountOfHits = tempGlobalCountOfHits;
    }

    function drawHits(originOfX, originOfY, svgContainer, hitResult, matrixTitle, matrixAsString)
    {
		var hitSize = hitResult.Stop - hitResult.Start + 1;
		var boxheight = 2;
		var rectangle;
		var rectTooltip = matrixTitle + ": " + hitResult.Start + "-" + hitResult.Oligo + "-" + hitResult.Stop;
		var tooltip = d3.select("body")
			.append("div")
			.style("position", "absolute")
			.style("z-index", "10")
			.style("visibility", "hidden")
			.text(rectTooltip)
			.attr("width", "600px")
			.attr("height", "28px")
			.attr("font-size", "12px")
			.style("background-color", 'lightsteelblue')
			.attr("font-family", "sans-serif")
			.style("padding", "5px");
			
		var heightOffset = 3; // so Hit Rectangles get positioned evenly above and underneath of sequence line
		
		//Draw the Rectangle
		if(hitResult.Sense === "N")
		{
			var x = originOfX - 2 + parseInt(hitResult.Start) * $scope.svgScaleFactor;
			var y = originOfY + 35 - heightOffset;
			var width = hitSize * $scope.svgScaleFactor;
			var height = boxheight;
			var radius = 4
			
			// Mx,y = start
			// v = draw vertical line
			// a = draw eliptic curve
			// h = draw horizontal line
			// z = close (sub)path
			var upperRoundedRect = "M " + x + ", " + y + " v " + (-height) + " a "+ radius + ", " + radius + " 0 0 1 " + radius + ", " + (-radius) + " h " + (width - 2 * radius) + " a " + radius + ", " + radius + " 0 0 1 " + radius + ", " + radius + " v " + height + " z";
			
			rectangle = svgContainer.append("path")
									 .attr("d", upperRoundedRect)
									 .style("fill", currentMatrixColor)
									 .style("stroke", "black")
									 .on("mouseover", function(){
										 tooltip.transition().duration(200).style("opacity", 0.9);
										 return tooltip.style("visibility", "visible");})
									 .on("mousemove", function(){
										 return tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px");})
									 .on("mouseout", function(){
										 tooltip.transition().duration(500).style("opacity", 0);	
										 return tooltip.style("visibility", "hidden");});
        }
        else if (hitResult.Sense === "R")
        {
			var x = originOfX -2 + parseInt(hitResult.Start) * $scope.svgScaleFactor;
			var y = originOfY + 35 - heightOffset;
			var width = hitSize * $scope.svgScaleFactor;
			var height = boxheight;
			var radius = 4;
			var lowerRoundedRect = "M " + x + ", " + y + " v " + height + " a "+ radius + ", " + radius + " 0 0 0 " + radius + ", " + radius + " h " + (width - 2 * radius) + " a " + radius + ", " + radius + " 0 0 0 " + radius + ", " + (-radius) + " v " + (-height) + " z";
			
			rectangle = svgContainer.append("path")
									 .attr("d", lowerRoundedRect)
									 .style("fill", currentMatrixColor)
									 .style("stroke", "black")
									 .on("mouseover", function(){
										 tooltip.transition().duration(200).style("opacity", 0.9);
										 return tooltip.style("visibility", "visible");})
									 .on("mousemove", function(){
										 return tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px");})
									 .on("mouseout", function(){
										 tooltip.transition().duration(500).style("opacity", 0);
										 return tooltip.style("visibility", "hidden");});
		}
		
		addRectToAllRectsArray(rectangle, matrixTitle);
		makeCheckboxes(matrixTitle, currentMatrixColor, matrixAsString);
    }

	function addRectToAllRectsArray(rectangle, matrixTitle)
	{
		for(var i = 0; i < $scope.allRects.length; ++i)
		{
			if(Object.keys($scope.allRects[i]).toString() === matrixTitle)
			{
				$scope.allRects[i][matrixTitle].push(rectangle);
			}
		}
	}

	var checkboxSeparator = 1;
	$scope.generatedCheckboxes = [];
	$scope.matrixCheckboxes = [];
    function makeCheckboxes(matrixTitle, currentMatrixColor, aMatrixAsString)
    {
		if($scope.generatedCheckboxes.indexOf(matrixTitle) === -1)
			{$scope.generatedCheckboxes.push(matrixTitle);}
		else 
			{return;}

		aMatrixAsString = matrixAsFourColumns('', aMatrixAsString, '\n');
		
    	var container = document.getElementById('checkboxForMatrices');

		var checkbox = document.createElement('input');
		checkbox.type = "checkbox";
		checkbox.name = "MatrixTitle";
		checkbox.checked = true;
		checkbox.id = matrixTitle;
		checkbox.color = currentMatrixColor;
		checkbox.onclick = function(){matrixCheckboxOnClickAction(this);};

		var label = document.createElement('label');
		label.htmlFor = "id";
		label.style.color = currentMatrixColor;
		label.appendChild(document.createTextNode(matrixTitle));
		label.title = aMatrixAsString;
		
		var copyButton = document.createElement('button');
		copyButton.innerHTML = "C";
		copyButton.title = "Click to Copy Matrix";
		// Cal ID of hiddenText Textfield, where the value resides, which is copied to clipboard.
		copyButton.onclick = function(){updateClipboard(matrixTitle + "#");}
		
		var hiddenText = document.createElement("input");
		hiddenText.type = "text";
		hiddenText.id = matrixTitle + "#";
		// Format Matrix: >Matrixname aMatrixAsString(without leading A C G T\n)
		hiddenText.value = ">" + matrixTitle + " " + aMatrixAsString.substring(9);
		hiddenText.size = 1;
		// hide textfield, cannot set hidden to true, because then updateClipboard cannot read value of textfield!
		hiddenText.style.opacity = 0;

		var newElement;
		if(checkboxSeparator%2 === 0)
		{
			newElement = document.createElement("div"); 
	  		var newContent = document.createTextNode(""); 
  			newElement.appendChild(newContent);
			++checkboxSeparator;
		}
		else if(checkboxSeparator%2 === 1)
		{
			newElement = document.createElement('label');
			newElement.appendChild(document.createTextNode('    '));
			++checkboxSeparator;
		}

		container.appendChild(checkbox);
		container.appendChild(label);
		container.appendChild(copyButton);
		container.appendChild(hiddenText);
		container.appendChild(newElement);
		$scope.matrixCheckboxes.push(checkbox);
    }

	function matrixCheckboxOnClickAction(e)
	{
		//var allTheRects = getItemFromLocalStorage("allRects");
		var matrixTitle = e.id;
		setHideForAllRects(matrixTitle, e.checked);
	}

	function setHideForAllRects(matrixTitle, isCheckboxChecked)
	{
		for(var i = 0; i < $scope.allRects.length; ++i)
		{
			if(Object.keys($scope.allRects[i]).toString() === matrixTitle)
			{
				var rectsForMatrixTitle = $scope.allRects[i][matrixTitle].length;
				for(var j = 0; j < rectsForMatrixTitle; ++j)
				{
					if(isCheckboxChecked === true)
						{$scope.allRects[i][matrixTitle][j]._groups[0][0].style.visibility = "visible";}
					else if (isCheckboxChecked === false)
						{$scope.allRects[i][matrixTitle][j]._groups[0][0].style.visibility = "hidden";}
				}
			}
		}
	}
	
	function updateClipboard(buttonID) 
	{
	  /* Get the text field */
	  var copyText = document.getElementById(buttonID);

	  /* Select the text field */
	  copyText.select(); 
	  copyText.setSelectionRange(0, 99999); /*For mobile devices*/

	  /* Copy the text inside the text field */
	  document.execCommand("copy");
	}
	
	$scope.showEveryRect = function()
	{
		switchHideOrShowEveryRect(true);
	}
	
	$scope.hideEveryRect = function()
	{
		switchHideOrShowEveryRect(false);
	}
	
	function switchHideOrShowEveryRect(shouldShow)
	{
		$scope.matrixCheckboxes;
		for(var i = 0; i < $scope.matrixCheckboxes.length; ++i)
		{
			$scope.matrixCheckboxes[i].checked = shouldShow;
			setHideForAllRects($scope.matrixCheckboxes[i].id, shouldShow)
		}
	}
	
	$scope.setLowScore = function()
	{
		document.getElementById('stepper1').defaultValue = 6;
		document.getElementById('stepper2').defaultValue = 7;
		setThresholds(6, 7);
	}
	
	$scope.setDefaultScore = function()
	{
		document.getElementById('stepper1').defaultValue = 7;
		document.getElementById('stepper2').defaultValue = 8;
		setThresholds(7, 8);
	}
	
	function setThresholds(min, max)
	{
		$scope.minThreshold = min;
		$scope.maxDeficit = max;
	}
	
	$scope.reloadLocation = function()
	{
		location.reload(true); // true: means reload page from server, false: reload from chache.
	};
	
	$scope.openModalDetails = function()
	{		
		//var myWindow = window.open("", "_self", "width=200,height=100");
		//myWindow.document.write("<p>This is 'MsgWindow'. I am 200px wide and 100px tall!</p>");
		var detailsWindow = window.open("", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width="+screen.availWidth+",height="+screen.availHeight+",rel='noreferrer noopener'");
		detailsWindow.document.write(buildDetailsForScoring($scope.arrayOfOnlySequences, $scope.arrayOfOnlyMatrices, $scope.parsedResultJSON, countOfMatrixElements, globalCountOfHits, $scope.matrixCheckboxes));
	};
	
	$scope.openModalModules = function()
	{		
		var modulesWindow = window.open("", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width="+screen.availWidth+",height="+screen.availHeight+",rel='noreferrer noopener'");
		modulesWindow.document.write(buildDetailsForModules($scope.parsedResultJSON, countOccurencesOfModulesWithInterval));
	};
	
    $scope.clickDownloadSVG = function()
    {
		// First download Picture svg
		var svgData = $("#matrixHits")[0].innerHTML;
		var svgBlob = new Blob([svgData], {type:"image/svg+xml;charset=utf-8"});
		var svgUrl = URL.createObjectURL(svgBlob);
		var downloadLink = document.createElement("a");
		downloadLink.href = svgUrl;
		var milliseconds = new Date().getTime();
		downloadLink.download = "resultPicture_" + milliseconds + ".svg";
		document.body.appendChild(downloadLink);
		downloadLink.click();
		document.body.removeChild(downloadLink);
		
		// Build Legend
		// Second download Legend svg
		var maxlinelength = 0;
        var maxlines = 0;
        for(var i = 0; i < $scope.matrixCheckboxes.length; i++)
        {
			if($scope.matrixCheckboxes[i].checked === true)
			{
			  var linelength = parseInt($scope.matrixCheckboxes[i].id.length);
			  maxlines++;
			  if(linelength > maxlinelength)
			  {maxlinelength = linelength;}
			}
        }

	    // Empty SVG Container
	    //d3.select("#matrixHits").selectAll("svg").remove();
        //Make an SVG Container
        var svgContainer = d3.select("#colorAndTitleOfHits").append("svg:svg")
                                         .attr("width", (maxlinelength * 10))
                                        .attr("height", (maxlines * 15 + 20)); 
           
           
        var rectSize = 10;
		var boxheight = 10;
		var rectangle;
		var originOfX = 10;
		var originOfY = 10;
			

		
		//Draw the Rectangle
		var x = originOfX;
		var yRect = originOfY + 10;
		var yText = originOfY + 3;
		var width = rectSize;
		var height = boxheight;
		var radius = 0;          
		
		for(i = 0; i < $scope.matrixCheckboxes.length; i++)
		{
			if ($scope.matrixCheckboxes[i].checked === false)
				continue;
				           
			// Mx,y = start
			// v = draw vertical line
			// a = draw eliptic curve
			// h = draw horizontal line
			// z = close (sub)path
			var rect = "M " + x + ", " + yRect + " v " + (-height) + " a "+ radius + ", " + radius + " 0 0 1 " + radius + ", " + (-radius) + " h " + (width - 2 * radius) + " a " + radius + ", " + radius + " 0 0 1 " + radius + ", " + radius + " v " + height + " z";
			
			rectangle = svgContainer.append("path")
									 .attr("d", rect)
									 .style("fill", $scope.matrixCheckboxes[i].color)
									 .style("stroke", "black");
			svgContainer.append("text")
									 .attr("x", (x + 15))
									.attr("y", (yText))
									.attr("font-size", "15px")
									//.attr("dx", DNAResultSequence["Length"])
									.attr("dy", ".4em")
									.attr("opacity", "1")
									.text($scope.matrixCheckboxes[i].id);
			yRect += 15;
			yText += 15;		
		}

		var svgData = $("#colorAndTitleOfHits")[0].innerHTML;
		var svgBlob = new Blob([svgData], {type:"image/svg+xml;charset=utf-8"});
		var svgUrl = URL.createObjectURL(svgBlob);
		var downloadLink = document.createElement("a");
		downloadLink.href = svgUrl;
		var milliseconds = new Date().getTime();
		downloadLink.download = "resultLegend_" + milliseconds + ".svg";
		document.body.appendChild(downloadLink);
		downloadLink.click();
		document.body.removeChild(downloadLink);
		var elem = document.getElementById("colorAndTitleOfHits");
		
		// remove svg from html dom
		while (elem.firstChild)
		{elem.removeChild(elem.firstChild);}
	};

	$scope.selectedDropDownItem = "0";
	$scope.animalClasses = getAnimalClasses();
	function getAnimalClasses()
	{
		$http({
              method: 'GET',
              url: $scope.callURL + '/api/matrixclasses',
            }).then(function successCallback(response) {
				    $scope.animalClasses = response.data.AnimalClasses;
            }, function errorCallback(response) {
					$scope.animalClasses = response.data === null ? ["empty"] : ["0"];
            }).finally(function(response) {
		});
    };
    
    $scope.getMatricesFromBackend = function()
    {
		$http({
              method: 'GET',
              url: $scope.callURL + '/api/matrixclasses/' + $scope.selectedDropDownItem,
            }).then(function successCallback(response) {
					$scope.matrixAsOneLiner = response.data.split('\n');
					generateColorAndRectArrayForMatrices($scope.matrixAsOneLiner);
					generateArrayOfOnlyMatrices();
            }, function errorCallback(response) {
            }).finally(function(response) {
		});
	}
	
	$scope.selectedDropDownItemSpecies = "0";
	$scope.species = getSpecies();
	function getSpecies()
	{
		$http({
              method: 'GET',
              url: $scope.callURL + '/api/speciesclasses',
            }).then(function successCallback(response) {
				    $scope.species = response.data.Species;
            }, function errorCallback(response) {
					$scope.species = response.data === null ? ["empty"] : ["0"];
            }).finally(function(response) {
		});
    };
    
    $scope.getSpeciesFromBackend = function()
    {
		$http({
              method: 'GET',
              url: $scope.callURL + '/api/speciesclasses/' + $scope.selectedDropDownItemSpecies,
            }).then(function successCallback(response) {
					//$scope.dnaAsOneLiner = response.data.split('\n');
					/*generateColorAndRectArrayForMatrices($scope.matrixAsOneLiner);
					generateArrayOfOnlyMatrices();*/
            }, function errorCallback(response) {
            }).finally(function(response) {
		});
	}
		
	$scope.minThreshold = 7;
	// if $scope.minThreshold is null
	$scope.defaultMinThreshold = 7;
	$scope.maxDeficit = 8;
	// if $scope.maxDeficit is null
	$scope.defaultMaxDeficit = 8;
	$scope.precisionOfTFs = 0;
	$scope.precisionOfTFsFromStepper = 0;
		
	$scope.countInputSequences = function ()
	{
		$scope.precisionOfTFs = $scope.dnaAsOneLiner.length/2 === 0 ? 0 : $scope.dnaAsOneLiner.length/2;
		$scope.precisionOfTFsFromStepper = $scope.precisionOfTFs;
	}
	
	// Module filtering
	// No module filtering for n<2 sequences
	function hasEnoughSequences(wms)
	{
		if(Object.keys(wms.WMS).length !== 0
	       && Object.keys(wms.WMS).length !== 1)
			return true;
	    else
			return false;
	}
	
	var countOccurencesOfModulesWithInterval;
	function getModuleFilteredResult(responseData)
	{
		var matrixHitsPerSense = countHitsPerSense(responseData);
		var validMatrixHitsPerSense = validateHitsPerSense(matrixHitsPerSense, responseData);
		var responseDataWithValidHitsAndEmptyMatrices = getResponseDataWithValidHits(validMatrixHitsPerSense, responseData);
		// delete matrices without hits. since the method getResponseDataWithValidHits() deletes invalid hits in matrices, but not the matrix itself,
		// when without hits - hence the second round.
		var responseDataWithValidHits = getResponseDataWithValidHits(validMatrixHitsPerSense, responseDataWithValidHitsAndEmptyMatrices);
		
		// Tree with N and R with sequences,
		// "{"N":[{"startpositions":[73,73,73,74,74,74,74,74,74,74,74,74,74,74,74,74,74,74]},{"startpositionlist":[73,74]},
		//  {"NumberOfSequences":["Sequence1","Sequence2","Sequence3"]},
		//  {"Sequence":"Sequence1","Hits":{"MatrixName":"MA0630.1 SHOX","Startposition":74,"Stopposition":81,"MinusIntervallStartPosition":0,"PlusIntervallStopPosition":281}},
		//  {"Sequence":"Sequence1","Hits":{"MatrixName":"MA0662.1 MIXL1","Startposition":73,"Stopposition":82,"MinusIntervallStartPosition":0,"PlusIntervallStopPosition":282}},...
		// intervals are applied for starts and stops
		// @param: validHits
		// @return: a json object, as that is easier to handle
		// interval of base pairs
		var interval = 200;
		var matrixNamePerStartPosition = getEasyJSON(responseDataWithValidHits, interval);
		
		// returns a json object, that lists for each sense its sequences and its hit starts
		// @param: matrixNamePerStartPosition
		// @return: returns a json, that lists for each sense its sequences and its hit starts
		var hitsPerSenseAndSequence = getHitsPerSenseAndSequence(matrixNamePerStartPosition);
			
		// new and empty json is initialized for later
		// this objects consists of the backbone: N->sequence, AllHits->Hitstart,Hits
		// @param hitsPerSenseAndSequence, matrixNamePerStartPosition
		// @return: a json, with sorted hits per sequence and start position without hits, only as a envelope
		var emptyJSONForHitsPerSequence = getEmptyJSONForHitsPerSequenceAndHitStart(hitsPerSenseAndSequence, matrixNamePerStartPosition);
	
		// fill the empty json with respective Hits
		// @param
		// @return: json with hits
		var fillEmptyJSONForHitsPerSequence = fillEmptyJSONForHitsPerSequenceWithHits(emptyJSONForHitsPerSequence, matrixNamePerStartPosition);
		
		// Tree with N and R, sequences within, hits within. the sequence of the hits follows parent-child relationships.
		// If there are many hits per start position, then there will be children accordingly.
		// @param: fillEmptyJSONForHitsPerSequence
		// @return: Tree of hits as PArent-Child relationship
		var treeOfHitOrder = getTreeOfHitOrder(fillEmptyJSONForHitsPerSequence);
		
		// The tree in the parameter is enriched with DistanceToParent.
		// @param: threeOfHitOrder: Parent-Child relationship between the Hits, following the sequence of hits
		// @return: tree with the information abount DistanceToParent is returned.
		var treeOfHitOrderWithDistanceToParent = getTreeOfHitOrderWithDistanceToParent(treeOfHitOrder);
		
		// per sense and sequence all the combinations of Matrices; no douplettes per sequence
		var combinationOfMatrixHits = getCombinationsOfMatrixHits(treeOfHitOrderWithDistanceToParent);
		
		// put all combinations of matrix hits into one array
		var consolidatedCombinationOfMatrixHits = getConsolidatedCombinationsOfMatrixHits(combinationOfMatrixHits);
		
		// counts the duplicates per sense
		var duplicatValues = countDuplicatValues(consolidatedCombinationOfMatrixHits);
		
		// allow only hits per sequence that are common in at least two sequences
		var combinationOfMatrixHitsGreaterThanTwo = getCombinationsOfMatrixHitsGreaterThanTwo(combinationOfMatrixHits, duplicatValues);
		
		// per sense and sequence all the combinations of Matrices, plus Start and Stoppositions, that are allowed
		var combinationsOfMatrixHitsPlusStartStopPositions = getCombinationsOfMatrixHitsPlusStartStopPositions(treeOfHitOrderWithDistanceToParent,
																	combinationOfMatrixHitsGreaterThanTwo)
		
		// only allow modules that are common to at least 2 sequences in the interval {interval}
		countOccurencesOfModulesWithInterval = getCountOccurencesOfModulesWithInterval(combinationsOfMatrixHitsPlusStartStopPositions, interval);
		
		// split allowed modules into hits again, so that filtering endresult is easier
		var validHits = getValidHits(countOccurencesOfModulesWithInterval);
		
		// get responseObject with only hits for valid modules
		var validHitsForModules = getValidHitsForModules(responseDataWithValidHits, validHits);
		
		// delete matrices without hits. Since the method getValidHitsForModules() deletes invalid hits in matrices, but not the matrix itself,
		// if it has no hits - hence the second round.
		var cleanValidHitsForModules = getValidHitsForModules(responseDataWithValidHits, validHits);

		return cleanValidHitsForModules;
	}
	
	// returns an object, that includes the hits according to sense (sense=N or R) and sums the hits
	// {"N":{"matrixName1":2,"matrixName2":1},"R":{"matrixName3":4}}
	var countOfMatrixElements = 0;
	// a flag to know the maximum number of hits per matrix; important for later iterations
	var globalCountOfHits = 0;
	function countHitsPerSense(responseData)
	{
		// initialize the return object
		var hitsPerSense = {};
		hitsPerSense.N = {};
		hitsPerSense.R = {};
		
		var tempResponseData = responseData;
		var countOfSequenceElements = Object.keys(tempResponseData.WMS).length;
		// since all SequenceN have the same amount of matrices, irrespective of present Hits
		if(countOfMatrixElements == 0)
			countOfMatrixElements = Object.keys(tempResponseData.WMS["Sequence1"]).length - 4;
		
		// per sequence only one matrix hi for N or R is allowed. That informaiton is saved in this object.
		var alreadyConsideredMatrixPerSequenceAndSense = {};
		alreadyConsideredMatrixPerSequenceAndSense.N = {};
		alreadyConsideredMatrixPerSequenceAndSense.R = {};
		
		for(var i = 1; i <= countOfSequenceElements; i++)
		{
			//var matricesWithHitsForOneSequence = [];
			for(var j = 1; j <= countOfMatrixElements; j++)
			{
				if(tempResponseData.WMS["Sequence" + i]["Matrix" + j] !== undefined)
				{
					var countOfHits = Object.keys(tempResponseData.WMS["Sequence" + i]["Matrix" + j]).length;
					// -4, as each matrixnode always consists of 4 static children. If Hits are present, then the number of hits is the difference
					// between all children of the matrix node minus four
					countOfHits = countOfHits - 4;
					
					if(globalCountOfHits < countOfHits)
						globalCountOfHits = countOfHits;
					
					if(countOfHits > 0)
					{
						for(var k = 1; k <= countOfHits; k++)
						{
							if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense == "N")
							{
								var matrixTitleForHitN = tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title;
								
								if(alreadyConsideredMatrixPerSequenceAndSense.N["Sequence" + i] === undefined)
										alreadyConsideredMatrixPerSequenceAndSense.N["Sequence" + i] = [];
										
								if(hitsPerSense.N[matrixTitleForHitN] == undefined)
								{
									hitsPerSense.N[matrixTitleForHitN] = 1;	
									alreadyConsideredMatrixPerSequenceAndSense.N["Sequence" + i].push(matrixTitleForHitN);
								}
								else if(!isNaN(hitsPerSense.N[matrixTitleForHitN]) && 
										!hasBeenConsidered(matrixTitleForHitN, alreadyConsideredMatrixPerSequenceAndSense.N["Sequence" + i]))
								{
									alreadyConsideredMatrixPerSequenceAndSense.N["Sequence" + i].push(matrixTitleForHitN);
									hitsPerSense.N[matrixTitleForHitN] = ++hitsPerSense.N[matrixTitleForHitN];
								}
							}
							else if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense == "R")
							{
								var matrixTitleForHitR = tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title;
								
								if(alreadyConsideredMatrixPerSequenceAndSense.R["Sequence" + i] === undefined)
										alreadyConsideredMatrixPerSequenceAndSense.R["Sequence" + i] = [];
										
								if(hitsPerSense.R[matrixTitleForHitR] == undefined)
								{
									hitsPerSense.R[matrixTitleForHitR] = 1;	
									alreadyConsideredMatrixPerSequenceAndSense.R["Sequence" + i].push(matrixTitleForHitR);
								}
								else if(!isNaN(hitsPerSense.R[matrixTitleForHitR]) && 
										!hasBeenConsidered(matrixTitleForHitR, alreadyConsideredMatrixPerSequenceAndSense.R["Sequence" + i]))
								{
									alreadyConsideredMatrixPerSequenceAndSense.R["Sequence" + i].push(matrixTitleForHitR);
									hitsPerSense.R[matrixTitleForHitR] = ++hitsPerSense.R[matrixTitleForHitR];
								}
							}
						}
					}
				}
			}
		}
		return hitsPerSense;
	}
	
	// This method checks if a matrix was already reagarded for a sequence. Each matrix may only be considered once per seqeuence and sense for 
	// the analysis.
	function hasBeenConsidered(matrixTitleForSense, arrayWithConsideredMatricesPerSequence)
	{
		var hasBeenConsidered = false;
		
		if(arrayWithConsideredMatricesPerSequence.indexOf(matrixTitleForSense) >= 0)
			hasBeenConsidered = true;
		
		return hasBeenConsidered;
	}
	
	// The object with the sense N and sense R hits and their amount is validated here.
	// i.e. that only hits are allowed, that are common to the number of sequnces, the user has selected in the stepper with the model
	// $scope.precisionOfTFsFromStepper.
	// Briefly:  matrixHitsPerSense.N[matrixName] = 2; if smaller than $scope.precisionOfTFsFromStepper, then this element is deleted,
	// if == $scope.precisionOfTFsFromStepper, then the value is valid
	function validateHitsPerSense(aMatrixHitsPerSense, responseData)
	{
		var tempResponseData = responseData;
		var korrekturfaktor = $scope.precisionOfTFsFromStepper; // correctionParameter, e.g. when hits are allowed in n-1 sequences.
		
		var matrixHitsPerSense = JSON.parse(JSON.stringify(aMatrixHitsPerSense));
		var matrixHitsPerSenseReturn = JSON.parse(JSON.stringify(aMatrixHitsPerSense));
		
		if(Object.keys(matrixHitsPerSense.N).length > 0)
		{
			for(var key in matrixHitsPerSense.N)
			{
				// hasOwnProperty, to check, if the property belongs to the object and is not inherited
				if(matrixHitsPerSense.N.hasOwnProperty(key) &&
					matrixHitsPerSense.N[key] >= korrekturfaktor)
				{
					// do nothing
				}
				else if(matrixHitsPerSense.N.hasOwnProperty(key) &&
					matrixHitsPerSense.N[key] < korrekturfaktor)
				{
					delete matrixHitsPerSenseReturn.N[key];
				}
			}
		}
		
		if(Object.keys(matrixHitsPerSense.R).length > 0)
		{
			for(var key in matrixHitsPerSense.R)
			{
				// hasOwnProperty, to check, if the property belongs to the object and is not inherited
				if(matrixHitsPerSense.R.hasOwnProperty(key) &&
					matrixHitsPerSense.R[key] >= korrekturfaktor)
				{
					// do nothing
				}
				else if(matrixHitsPerSense.R.hasOwnProperty(key) &&
					matrixHitsPerSense.R[key] < korrekturfaktor)
				{
					delete matrixHitsPerSenseReturn.R[key];
				}
			}
		}
		return matrixHitsPerSenseReturn;
	}
	
	// all matrices without hits are deleted
	// all matrices that are not in the validMatrixHitsPerSense get deleted
	// @return: responseData with only valid hits
	function getResponseDataWithValidHits(aValidMatrixHitsPerSense, responseData)
	{
		var returnObject = JSON.parse(JSON.stringify(responseData));
		var tempResponseData = JSON.parse(JSON.stringify(responseData));
		var countOfSequenceElements = Object.keys(tempResponseData.WMS).length;
		var validMatrixHitsPerSense = JSON.parse(JSON.stringify(aValidMatrixHitsPerSense));
		// since all SequenceN have the same amount of matrices, irrespective of containing hits
		// for the second round of this method call; save as global valiable since because of the current and different lengths of the matrices
		// not all would be processed
		if(countOfMatrixElements == 0)
			countOfMatrixElements = Object.keys(tempResponseData.WMS["Sequence1"]).length - 4;
		
		for(var i = 1; i <= countOfSequenceElements; i++)
		{
			for(var j = 1; j <= countOfMatrixElements; j++)
			{
				if(tempResponseData.WMS["Sequence" + i]["Matrix" + j] !== undefined)
				{
					var countOfHits = Object.keys(tempResponseData.WMS["Sequence" + i]["Matrix" + j]).length;
		
					// -4, since a matrix node always has four static children. if hits are present, then the amount of hits
					// is the difference of all children of the matrix node minus these four.
					countOfHits = countOfHits - 4;
					
					if(countOfHits > 0)
					{						
						for(var k = 1; k <= countOfHits; k++)
						{
							if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense === "N")
							{
								var istValiderHit = false;
								
								for(var key in validMatrixHitsPerSense.N)
								{
									// hasOwnProperty, to check, if the property belongs to the object and is not inherited
									if(validMatrixHitsPerSense.N.hasOwnProperty(key)&&
										istValiderHit == false &&
										tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title == key)
									{
										istValiderHit = true;
										break;
									}
									else
										continue;
								}
								// delete invalid hit
								if(istValiderHit == false)
									delete returnObject.WMS["Sequence" + i]["Matrix" + j]["Hit" + k];						
							}
							else if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense === "R")
							{
								var istValiderHit = false;
								
								for(var key in validMatrixHitsPerSense.R)
								{
									// hasOwnProperty, to check, if the property belongs to the object and is not inherited
									if(validMatrixHitsPerSense.R.hasOwnProperty(key)&&
										istValiderHit == false &&
										tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title == key)
									{
										istValiderHit = true;
										break;
									}
									else
										continue;
								}
								// delete invalid hit
								if(istValiderHit == false)
									delete returnObject.WMS["Sequence" + i]["Matrix" + j]["Hit" + k];
							}
						}
					}
					else
					{
						// matrices without hits get deleted
						delete returnObject.WMS["Sequence" + i]["Matrix" + j];
					}
				}
			}
		}
		return returnObject;
	}
	
	// tree with N and R, therein sequences
	// "{"N":[{"Startpositions":[73,73,73,74,74,74,74,74,74,74,74,74,74,74,74,74,74,74]},{"StartpositionList":[73,74]},
	//  {"NumberOfSequences":["Sequence1","Sequence2","Sequence3"]},
	//  {"Sequence":"Sequence1","Hits":{"MatrixName":"MA0630.1 SHOX","Startposition":74,"Stopposition":81,"MinusIntervallStartPosition":0,"PlusIntervallStopPosition":281}},
	//  {"Sequence":"Sequence1","Hits":{"MatrixName":"MA0662.1 MIXL1","Startposition":73,"Stopposition":82,"MinusIntervallStartPosition":0,"PlusIntervallStopPosition":282}},...
	// Intervals are applied to starts and stops
	// @param: validHits
	// @return: a json tree for simple handling
	function getEasyJSON(responseDataWithValidHits, anInterval)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(responseDataWithValidHits));
		
		// init return value
		var hitsAsParentChild = {};
		hitsAsParentChild.N = [];
		hitsAsParentChild.R = [];
		
		var countOfSequenceElements = Object.keys(copyOfInputParam.WMS).length;

		/*hitsAsParentChild.N.count = countOfSequenceElements;
		hitsAsParentChild.R.count = countOfSequenceElements;*/
		
		// since all SequenceN contain the same amount of matrices, irrespective of hits
		if(countOfMatrixElements == 0)
			countOfMatrixElements = Object.keys(copyOfInputParam.WMS["Sequence1"]).length - 4;
		
		for(var i = 1; i <= countOfSequenceElements; i++)
		{
			/*hitsAsParentChild.N["Sequence" + i] = {};
			hitsAsParentChild.N["Sequence" + i].order = [];
			hitsAsParentChild.R["Sequence" + i] = {};
			hitsAsParentChild.R["Sequence" + i].order = [];*/
			
			for(var j = 1; j <= countOfMatrixElements; j++)
			{
				if(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j] !== undefined)
				{
					//var countOfHits = Object.keys(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]).length;
					// -4, since a matrix node always has four static children. if hits are present, then the amount of hits
					// is the difference of all children of the matrix node minus these four.
					//countOfHits = countOfHits - 4;
					
					if(globalCountOfHits > 0)
					{						
						for(var k = 1; k <= globalCountOfHits; k++)
						{
							if(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense == "N")
							{
								var matrixTitleForHitN = copyOfInputParam.WMS["Sequence" + i]["Matrix" + j].Title;
								var hitStart = parseInt(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Start);
								var hitStop = parseInt(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Stop);
								
								if(hitsAsParentChild.N[0] === undefined)
								{
									hitsAsParentChild.N[0] = {}
									hitsAsParentChild.N[0].Startpositionen = [];
									hitsAsParentChild.N[0].Startpositionen.push(hitStart);
								}
								else
									hitsAsParentChild.N[0].Startpositionen.push(hitStart);
									
								if(hitsAsParentChild.N[1] === undefined)
								{
									hitsAsParentChild.N[1] = {}
									hitsAsParentChild.N[1].StartpositionenListe = [];
									if(hitsAsParentChild.N[1].StartpositionenListe.indexOf(hitStart) === -1)
										hitsAsParentChild.N[1].StartpositionenListe.push(hitStart);
								}
								else
								{
									if(hitsAsParentChild.N[1].StartpositionenListe.indexOf(hitStart) === -1)
										hitsAsParentChild.N[1].StartpositionenListe.push(hitStart);
								}
								
								if(hitsAsParentChild.N[2] === undefined)
								{
									hitsAsParentChild.N[2] = {}
									hitsAsParentChild.N[2].NumberOfSequences = [];
									if(hitsAsParentChild.N[2].NumberOfSequences.indexOf("Sequence" + i) === -1)
										hitsAsParentChild.N[2].NumberOfSequences.push("Sequence" + i);
								}
								else
								{
									if(hitsAsParentChild.N[2].NumberOfSequences.indexOf("Sequence" + i) === -1)
										hitsAsParentChild.N[2].NumberOfSequences.push("Sequence" + i);
								}
								
								var hit = {};
								hit.MatrixName = matrixTitleForHitN;
								hit.Startposition = hitStart;
								hit.Stopposition = hitStop;
								hit.MinusIntervallStartPosition = checkMinimumNull(hitStart - 200);
								hit.PlusIntervallStopPosition = checkMinimumNull(hitStop + 200);
								
								var RElement = {};
								RElement.Sequence = "Sequence" + i;
								RElement.Hits = hit;
								hitsAsParentChild.N.push(RElement);
							}
							else if(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense == "R")
							{
								var matrixTitleForHitR = copyOfInputParam.WMS["Sequence" + i]["Matrix" + j].Title;
								var hitStart = parseInt(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Start);
								var hitStop = parseInt(copyOfInputParam.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Stop);
								
								if(hitsAsParentChild.R[0] === undefined)
								{
									hitsAsParentChild.R[0] = {}
									var statpos = [];
									hitsAsParentChild.R[0].Startpositionen = [];
									hitsAsParentChild.R[0].Startpositionen.push(hitStart);
								}
								else
									hitsAsParentChild.R[0].Startpositionen.push(hitStart);
								
								if(hitsAsParentChild.R[1] === undefined)
								{
									hitsAsParentChild.R[1] = {}
									hitsAsParentChild.R[1].StartpositionenListe = [];
									if(hitsAsParentChild.R[1].StartpositionenListe.indexOf(hitStart) === -1)
										hitsAsParentChild.R[1].StartpositionenListe.push(hitStart);
								}
								else
								{
									if(hitsAsParentChild.R[1].StartpositionenListe.indexOf(hitStart) === -1)
										hitsAsParentChild.R[1].StartpositionenListe.push(hitStart);
								}
								
								if(hitsAsParentChild.R[2] === undefined)
								{
									hitsAsParentChild.R[2] = {}
									hitsAsParentChild.R[2].NumberOfSequences = [];
									if(hitsAsParentChild.R[2].NumberOfSequences.indexOf("Sequence" + i) === -1)
										hitsAsParentChild.R[2].NumberOfSequences.push("Sequence" + i);
								}
								else
								{
									if(hitsAsParentChild.R[2].NumberOfSequences.indexOf("Sequence" + i) === -1)
										hitsAsParentChild.R[2].NumberOfSequences.push("Sequence" + i);
								}
								
								var hit = {};
								hit.MatrixName = matrixTitleForHitR;
								hit.Startposition = hitStart;
								hit.Stopposition = hitStop;
								hit.MinusIntervallStartPosition = checkMinimumNull(hitStart - 200);
								hit.PlusIntervallStopPosition = checkMinimumNull(hitStop + 200);
								
								var RElement = {};
								RElement.Sequence = "Sequence" + i;
								RElement.Hits = hit;
								hitsAsParentChild.R.push(RElement);
							}
						}
					}
					else
					{
						// should not happen
						console.error("Matrices without hits should not happen anymore!");
					}
				}
			}
			if(hitsAsParentChild.N[0] !== undefined &&
				hitsAsParentChild.N[0].Startpositionen !== undefined)
					hitsAsParentChild.N[0].Startpositionen.sort(comparefunction);
			if(hitsAsParentChild.N[1] !== undefined &&
				hitsAsParentChild.N[1].StartpositionenListe !== undefined)
					hitsAsParentChild.N[1].StartpositionenListe.sort(comparefunction);
			if(hitsAsParentChild.N[2] !== undefined &&
				hitsAsParentChild.N[2].NumberOfSequences !== undefined)
					hitsAsParentChild.N[2].NumberOfSequences.sort();
			if(hitsAsParentChild.R[0] !== undefined &&
				hitsAsParentChild.R[0].Startpositionen !== undefined)
					hitsAsParentChild.R[0].Startpositionen.sort(comparefunction);
			if(hitsAsParentChild.R[1] !== undefined &&
				hitsAsParentChild.R[1].StartpositionenListe !== undefined)
					hitsAsParentChild.R[1].StartpositionenListe.sort(comparefunction);
			if(hitsAsParentChild.R[2] !== undefined &&
				hitsAsParentChild.R[2].NumberOfSequences !== undefined)
					hitsAsParentChild.R[2].NumberOfSequences.sort();
			//hitsAsParentChild.R["Sequence" + i].order = hitsAsParentChild.R["Sequence" + i].order.sort(comparefunction);
		}
		return hitsAsParentChild;
	}
	
	// sort() sorts as strings, for integer sort() you need to use a compare function
	function comparefunction(a,b){return a - b;};
	
	// return a json, that list to senses the respective sequences and the respective hit starts
	// "{"R":[{"Sequence":"Sequence1","HitStarts":[47,73,74,134]},{"Sequence":"Sequence2","HitStarts":[47,73,74,134]},{"Sequence":"Sequence3","HitStarts":[47,73,74,134]}],"N":[{"Sequence":"Sequence1","HitStarts":[73,74]},{"Sequence":"Sequence2","HitStarts":[73,74]},{"Sequence":"Sequence3","HitStarts":[73,74]}]}"
	// @param: matrixNamePerStartPosition
	// @return: return a json, that list to senses the respective sequences and the respective hit starts
	function getHitsPerSenseAndSequence(matrixNamePerStartPosition)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(matrixNamePerStartPosition));
		
		// init return val
		var hitsPerSenseAndSequence = {};
		hitsPerSenseAndSequence.R = [];
		hitsPerSenseAndSequence.N = [];
		
		if(copyOfInputParam.N[2] !== undefined)
		{
			var sequenceCount = copyOfInputParam.N[2].NumberOfSequences;
			var startpositionen = copyOfInputParam.N[0].Startpositionen;
			for(var i = 0; i < sequenceCount.length; i++)
			{
				var sequence = {};
				sequence.Sequence = sequenceCount[i];
				sequence.HitStarts = [];
				for(var k = 0; k < startpositionen.length; k++)
				{
					if(copyOfInputParam.N[k + 3].Sequence === sequenceCount[i])
					{
						if(sequence.HitStarts.indexOf(copyOfInputParam.N[k + 3].Hits.Startposition) === -1)
						{					
							sequence.HitStarts.push(copyOfInputParam.N[k + 3].Hits.Startposition);
							sequence.HitStarts.sort(comparefunction);
						}
					}
					else
						continue;
				}
				hitsPerSenseAndSequence.N.push(sequence);
			}
		}
		
		if(copyOfInputParam.R[2] !== undefined)
		{
			var sequenceCount = copyOfInputParam.R[2].NumberOfSequences;
			var startpositionen = copyOfInputParam.R[0].Startpositionen;
			for(var i = 0; i < sequenceCount.length; i++)
			{
				var sequence = {};
				sequence.Sequence = sequenceCount[i];
				sequence.HitStarts = [];
				for(var k = 0; k < startpositionen.length; k++)
				{
					if(copyOfInputParam.R[k + 3].Sequence === sequenceCount[i])
					{
						if(sequence.HitStarts.indexOf(copyOfInputParam.R[k + 3].Hits.Startposition) === -1)
						{
							sequence.HitStarts.push(copyOfInputParam.R[k + 3].Hits.Startposition);
							sequence.HitStarts.sort(comparefunction);
						}
					}
					else
						continue;
				}
				hitsPerSenseAndSequence.R.push(sequence);
			}
		}
		
		return hitsPerSenseAndSequence;
	}
	
	// init new empty json, to work with
	// the scaffold of the object: N->Sequence, AllHits->Hitstart,Hits
	// @param: hitsPerSenseAndSequence, matrixNamePerStartPosition
	// @return: a json, with sorted hits per sequence and start position without hits, only empty envelope; the hits are sorted in ascending order
	function getEmptyJSONForHitsPerSequenceAndHitStart(hitsPerSenseAndSequence, matrixNamePerStartPosition)
	{
		// make copy 
		var hitsPerSenseAndSequenceCopy = JSON.parse(JSON.stringify(hitsPerSenseAndSequence));
		var matrixNamePerStartPositionCopy = JSON.parse(JSON.stringify(matrixNamePerStartPosition));
		
		// init return val
		var hitsSortedByHitStart = {};
		hitsSortedByHitStart.N = [];
		// apply all start positions of all hits per sequence
		hitsSortedByHitStart.N[0] = matrixNamePerStartPositionCopy.N[0];
		// start position list (unique/distinct values) are copied
		hitsSortedByHitStart.N[1] = matrixNamePerStartPositionCopy.N[1];
		// NumberOfSequences are copied
		hitsSortedByHitStart.N[2] = matrixNamePerStartPositionCopy.N[2];
		hitsSortedByHitStart.R = [];
		// All start positions of all hits per sequence are copied
		hitsSortedByHitStart.R[0] = matrixNamePerStartPositionCopy.R[0];
		// Startpositionlist (unique/distinct values) copied
		hitsSortedByHitStart.R[1] = matrixNamePerStartPositionCopy.R[1];
		// NumberOfSequences copied
		hitsSortedByHitStart.R[2] = matrixNamePerStartPositionCopy.R[2];
		
		var NSequences = hitsPerSenseAndSequenceCopy.N;
		for(var i = 0; i < NSequences.length; i++)
		{
			for(var j = 0; j < NSequences[i].HitStarts.length; j++)
			{
				var sequenceObject = {};
				sequenceObject.Sequence = NSequences[i].Sequence;
				sequenceObject.AllHits = [];
				var hitObject = {};
				hitObject.HitStart = NSequences[i].HitStarts[j];
				hitObject.Hits = [];
				
				sequenceObject.AllHits.push(hitObject);
				hitsSortedByHitStart.N.push(sequenceObject);
			}
		}
		
		var RSequences = hitsPerSenseAndSequenceCopy.R;
		for(var i = 0; i < RSequences.length; i++)
		{
			for(var j = 0; j < RSequences[i].HitStarts.length; j++)
			{
				var sequenceObject = {};
				sequenceObject.Sequence = RSequences[i].Sequence;
				sequenceObject.AllHits = [];
				var hitObject = {};
				hitObject.HitStart = RSequences[i].HitStarts[j];
				hitObject.Hits = [];
				
				sequenceObject.AllHits.push(hitObject);
				hitsSortedByHitStart.R.push(sequenceObject);
			}
		}
		
		return hitsSortedByHitStart;
	}
	
	// fill the empty json with respective Hits
	// @param
	// @return: json with hits
	function fillEmptyJSONForHitsPerSequenceWithHits(aEmptyJSONForHitsPerSequence, aMatrixNamePerStartPosition)
	{
		// make copy
		var emptyJSONForHitsPerSequence = JSON.parse(JSON.stringify(aEmptyJSONForHitsPerSequence));
		var matrixNamePerStartPosition = JSON.parse(JSON.stringify(aMatrixNamePerStartPosition));
		
		// N Sequences
		if(emptyJSONForHitsPerSequence.N[0] !== undefined &&
			emptyJSONForHitsPerSequence.N[0] !== null)
		{
			var emptyJSONHitCountN = emptyJSONForHitsPerSequence.N[0].Startpositionen.length;
			var emptyJSONElementCountN = emptyJSONForHitsPerSequence.N.length;   
			
			// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
			for(var i = 3; i < emptyJSONElementCountN; i++)
			{
				var emptyJSONSequenceNameN = emptyJSONForHitsPerSequence.N[i].Sequence;
				var emptyJSONHitStartN = emptyJSONForHitsPerSequence.N[i].AllHits[0].HitStart;
				var emptyJSONHitsN = emptyJSONForHitsPerSequence.N[i].AllHits[0].Hits;
				
				var matrixNameElementCountN = matrixNamePerStartPosition.N.length;
				// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
				for(var k = 3; k < matrixNameElementCountN; k++)
				{
					var matrixNameSequenceNameN = matrixNamePerStartPosition.N[k].Sequence;
					var matrixNameHitStartN = matrixNamePerStartPosition.N[k].Hits.Startposition;
					var matrixNameHitsN = matrixNamePerStartPosition.N[k].Hits;
					if(emptyJSONSequenceNameN === matrixNameSequenceNameN &&
					   emptyJSONHitStartN === matrixNameHitStartN)
						emptyJSONHitsN.push(matrixNameHitsN);
				}
			}
		}
		
		// R Sequences
		if(emptyJSONForHitsPerSequence.R[0] !== undefined &&
			emptyJSONForHitsPerSequence.R[0] !== null)
		{
			var emptyJSONHitCountR = emptyJSONForHitsPerSequence.R[0].Startpositionen.length;
			var emptyJSONElementCountR = emptyJSONForHitsPerSequence.R.length;   
			
			// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
			for(var i = 3; i < emptyJSONElementCountR; i++)
			{
				var emptyJSONSequenceNameR = emptyJSONForHitsPerSequence.R[i].Sequence;
				var emptyJSONHitStartR = emptyJSONForHitsPerSequence.R[i].AllHits[0].HitStart;
				var emptyJSONHitsR = emptyJSONForHitsPerSequence.R[i].AllHits[0].Hits;
				
				var matrixNameElementCountR = matrixNamePerStartPosition.R.length;
				// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
				for(var k = 3; k < matrixNameElementCountR; k++)
				{
					var matrixNameSequenceNameR = matrixNamePerStartPosition.R[k].Sequence;
					var matrixNameHitStartR = matrixNamePerStartPosition.R[k].Hits.Startposition;
					var matrixNameHitsR = matrixNamePerStartPosition.R[k].Hits;
					if(emptyJSONSequenceNameR === matrixNameSequenceNameR &&
					   emptyJSONHitStartR === matrixNameHitStartR)
						emptyJSONHitsR.push(matrixNameHitsR);
				}
			}
		}
		
		return emptyJSONForHitsPerSequence;
	}
	
	// tree with N and R, therein seqeuences, therein the hits. the sequence of hits is represented by parent-child relationships.
	// It there are many hits per start position, then there will be children accordingly
	// @param: fillEmptyJSONForHitsPerSequence (hits sorted in ascending order)
	// @return: Tree of hits as PArent-Child relationship
	//function getTreeOfHitOrder(responseDataWithValidHits, matrixNamePerStartPosition)
	function getTreeOfHitOrder(fillEmptyJSONForHitsPerSequence)
	{
		// make copy
		var copyFillEmptyJSONForHitsPerSequence = JSON.parse(JSON.stringify(fillEmptyJSONForHitsPerSequence));
		
		// init return val
		var hitsAsParentChild = {};
		hitsAsParentChild.N = [];
		// copy all start position of all hits per seqeuence
		hitsAsParentChild.N[0] = copyFillEmptyJSONForHitsPerSequence.N[0];
		// Startpositionlist (unique/distinct values) copied
		hitsAsParentChild.N[1] = copyFillEmptyJSONForHitsPerSequence.N[1];
		// NumberOfSequences copied
		hitsAsParentChild.N[2] = copyFillEmptyJSONForHitsPerSequence.N[2];
		hitsAsParentChild.R = [];
		// copy all start position of all hits per seqeuence
		hitsAsParentChild.R[0] = copyFillEmptyJSONForHitsPerSequence.R[0];
		// Startpositionlist (unique/distinct values) copied
		hitsAsParentChild.R[1] = copyFillEmptyJSONForHitsPerSequence.R[1];
		// NumberOfSequences copied
		hitsAsParentChild.R[2] = copyFillEmptyJSONForHitsPerSequence.R[2];
		
		// N
		if(copyFillEmptyJSONForHitsPerSequence.N[2] !== undefined &&
			copyFillEmptyJSONForHitsPerSequence.N[2] !== null)
		{
			var sequencesN = copyFillEmptyJSONForHitsPerSequence.N[2].NumberOfSequences;
			for(var i = 0; i < sequencesN.length; i++)
			{
				var sequenceElement = {};
				sequenceElement.SequenceName = sequencesN[i];
				sequenceElement.HierarchyDepth = 0;
				sequenceElement.Hits = [];
						
				var arrayLengthN = copyFillEmptyJSONForHitsPerSequence.N.length;
				
				if(arrayLengthN > 3)
				{
					var children = [];
					var tempresult = [];
					// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
					for(var j = arrayLengthN - 1; j > 2; j--)
					{
						var paramHitsN = copyFillEmptyJSONForHitsPerSequence.N[j].AllHits[0].Hits;
						var paramSequenceN = copyFillEmptyJSONForHitsPerSequence.N[j].Sequence;
						
						if(paramSequenceN !== sequenceElement.SequenceName)
								continue;
						
						var copyTempChildren = children;
						for(var k = 0; k < paramHitsN.length; k++)
						{					
							var result = {};
							result.MatrixName = paramHitsN[k].MatrixName;
							result.StartPosition = paramHitsN[k].Startposition;
							result.StopPosition = paramHitsN[k].Stopposition;
							result.MinusIntervallStartPosition = paramHitsN[k].MinusIntervallStartPosition;
							result.PlusIntervallStartPosition = paramHitsN[k].PlusIntervallStopPosition;
							// Default for all
							result.IsModule = false;
							result.DistanceToParent = 0;
							result.Children = copyTempChildren;

							tempresult.push(result);	
						}
						children = [];
						children = tempresult;
						tempresult = [];
						sequenceElement.HierarchyDepth++;
					}
					sequenceElement.Hits.push(children);
				}
				hitsAsParentChild.N.push(sequenceElement);
			}
		}
		
		// R
		if(copyFillEmptyJSONForHitsPerSequence.R[2] !== undefined &&
			copyFillEmptyJSONForHitsPerSequence.R[2] !== null)
		{
			var sequencesR = copyFillEmptyJSONForHitsPerSequence.R[2].NumberOfSequences;
			for(var i = 0; i < sequencesR.length; i++)
			{
				var sequenceElement = {};
				sequenceElement.SequenceName = sequencesR[i];
				sequenceElement.HierarchyDepth = 0;
				sequenceElement.Hits = [];
						
				var arrayLengthR = copyFillEmptyJSONForHitsPerSequence.R.length;
				
				if(arrayLengthR > 3)
				{
					var children = [];
					var tempresult = [];
					// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
					for(var j = arrayLengthR - 1; j > 2; j--)
					{
						var paramHitsR = copyFillEmptyJSONForHitsPerSequence.R[j].AllHits[0].Hits;
						var paramSequenceR = copyFillEmptyJSONForHitsPerSequence.R[j].Sequence;
						
						if(paramSequenceR !== sequenceElement.SequenceName)
								continue;
						
						var copyTempChildren = children;
						for(var k = 0; k < paramHitsR.length; k++)
						{					
							var result = {};
							result.MatrixName = paramHitsR[k].MatrixName;
							result.StartPosition = paramHitsR[k].Startposition;
							result.StopPosition = paramHitsR[k].Stopposition;
							result.MinusIntervallStartPosition = paramHitsR[k].MinusIntervallStartPosition;
							result.PlusIntervallStartPosition = paramHitsR[k].PlusIntervallStopPosition;
							// Default for all
							result.IsModule = false;
							result.DistanceToParent = 0;
							result.Children = copyTempChildren;

							tempresult.push(result);	
						}
						children = [];
						children = tempresult;
						tempresult = [];
						sequenceElement.HierarchyDepth++;
					}
					sequenceElement.Hits.push(children);
				}
				hitsAsParentChild.R.push(sequenceElement);
			}
		}
		
		return hitsAsParentChild;
	}
	
	// tree with DistanceToParent is returned
	// @param: treeOfHitOrder: Parent-Child relationships between hits, following the succession of hits
	// @return: tree with DistanceToParent is returned
	function getTreeOfHitOrderWithDistanceToParent(treeOfHitOrder)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(treeOfHitOrder));
		
		var sequenceOrientation= ["N", "R"];

		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			
			// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
			for(var i = 3; i < sequences.length; i++)
			{
				var distToParent = 0;
				
				var hierarchyDepth = sequences[i].HierarchyDepth;
				var element = sequences[i].Hits[0][0];
				var startOfParent = element.StartPosition;
				var stopOfParent = element.StopPosition;
				
				if(element.ParentStartPosition === undefined)
					element.ParentStartPosition = element.StartPosition;
				
				if(element.ParentStopPosition === undefined)
					element.ParentStopPosition = element.StopPosition;
				
				// First Hit in sequence is start, without a parent
				if(i === 3)
					element.DistanceToParent = distToParent;
					
				// no children
				if(hierarchyDepth === 1)
					continue;
					
				var children = element.Children;
				recursive(children, startOfParent, stopOfParent);
			}	
		}
		
		return copyOfInputParam;
	}
	
	// recursively iterate through parent child tree and set values
	function recursive(children, startOfParent, stopOfParent)
	{
		var childrenLength = children.length;
		
		for(var i = 0; i < childrenLength; i++)
		{
			var child = children[i];
			child.DistanceToParent = child.StartPosition - startOfParent;
			child.ParentStartPosition = startOfParent;
			child.ParentStopPosition = stopOfParent;
			
			if(child.Children !== undefined && child.Children.length > 0)
				recursive(child.Children, child.StartPosition, child.StopPosition);
		}
	}
	
	// per sense and sequence all the combinations of Matrices 	
	function getCombinationsOfMatrixHits(parentChildTree)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(parentChildTree));
		
		var sequenceOrientation= ["N", "R"];

		var combinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			combinationOfHits[sequenceOrientation[orientation]] = [];
			// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
			for(var i = 3; i < sequences.length; i++)
			{			
				var hierarchyDepth = sequences[i].HierarchyDepth;
				var element = sequences[i].Hits[0][0];
				var MatrixNames = [];
				MatrixNames.push(element.MatrixName);
					
				// new array for each sequence
				combinationOfHits[sequenceOrientation[orientation]][i - 3] = [];
				
				// no children
				if(hierarchyDepth === 1)
					continue;
					
				var children = element.Children;
				recursiveAllMatrixCombinations(combinationOfHits[sequenceOrientation[orientation]][i - 3], children, MatrixNames);
			}	
		}
		
		return combinationOfHits;
	}
	
	// recursively iterate through parent child tree and set matrixnames to array
	function recursiveAllMatrixCombinations(arrOfMatrixNames, children, parentMatrixNames)
	{
		var childrenLength = children.length;
		
		for(var i = 0; i < childrenLength; i++)
		{
			var child = children[i];
			var childMatrixName = child.MatrixName;	
			
			for(var j = 0; j < parentMatrixNames.length; j++)
			{
				// no duplettes
				if(arrOfMatrixNames.includes(parentMatrixNames[j] + ";;" + childMatrixName) === false)
					arrOfMatrixNames.push(parentMatrixNames[j] + ";;" + childMatrixName);
			}
			
			if(child.Children !== undefined && child.Children.length > 0)
			{
				var clone = parentMatrixNames.slice();
				clone.push(childMatrixName);
				recursiveAllMatrixCombinations(arrOfMatrixNames, child.Children, clone);
			}
		}
	}
	
	// put all combinations of matrix hits into one array
	function getConsolidatedCombinationsOfMatrixHits(combinationOfMatrixHits)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(combinationOfMatrixHits));
		
		var sequenceOrientation= ["N", "R"];

		var consolidatedCombinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			consolidatedCombinationOfHits[sequenceOrientation[orientation]] = [];
			for(var i = 0; i < sequences.length; i++)
			{
				for(var j = 0; j < sequences[i].length; j++)
				{
					consolidatedCombinationOfHits[sequenceOrientation[orientation]].push(sequences[i][j]);
				}
			}
		}
		
		return consolidatedCombinationOfHits;
	}
	
	// counts the duplicates per sense
	function countDuplicatValues(consolidatedCombinationOfMatrixHits)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(consolidatedCombinationOfMatrixHits));
		
		var sequenceOrientation= ["N", "R"];

		var countedCombinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			countedCombinationOfHits[sequenceOrientation[orientation]] = [];

			sequences.forEach(function(x) {countedCombinationOfHits[sequenceOrientation[orientation]][x] = 
				(countedCombinationOfHits[sequenceOrientation[orientation]][x] || 0) +1; });
		}
		
		return countedCombinationOfHits;
	}
	
	// allow only hits per sequence that are common in at least two sequences
	function getCombinationsOfMatrixHitsGreaterThanTwo(combinationOfMatrixHits, duplicatValues)
	{
		// make copy
		var copyOfInputParamHits = JSON.parse(JSON.stringify(combinationOfMatrixHits));
		
		var sequenceOrientation= ["N", "R"];
		
		var combinationOfHitsGreaterThanTwo = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParamHits[sequenceOrientation[orientation]];
			combinationOfHitsGreaterThanTwo[sequenceOrientation[orientation]] = [];
			
			for(var sequencesCount = 0; sequencesCount < sequences.length; sequencesCount++)
			{		
				combinationOfHitsGreaterThanTwo[sequenceOrientation[orientation]][sequencesCount] = [];
				for(var hitCount = 0; hitCount < sequences[sequencesCount].length; hitCount++)
				{
					var keys = Object.keys(duplicatValues[sequenceOrientation[orientation]]);
					var values = Object.values(duplicatValues[sequenceOrientation[orientation]]);
					
					for(var keyCount = 0; keyCount < keys.length; keyCount++)
					{
						// if Hit in Sequence is in array duplicateValues and has a count > 1 (i.e. that matrix has at least another hit in another sequence)
						// then consider it as a real hit.
						if(copyOfInputParamHits[sequenceOrientation[orientation]][sequencesCount][hitCount] == keys[keyCount] &&
						   values[keyCount] > 1)
							combinationOfHitsGreaterThanTwo[sequenceOrientation[orientation]][sequencesCount]
								.push(copyOfInputParamHits[sequenceOrientation[orientation]][sequencesCount][hitCount]);
					}	
				}
			}	
		}
		
		return combinationOfHitsGreaterThanTwo;	
	}
	
	// per sense and sequence all the combinations of Matrices, plus Start and Stoppositions, that are allowed
	function getCombinationsOfMatrixHitsPlusStartStopPositions(parentChildTree, combinationOfMatrixHitsGreaterThanTwo)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(parentChildTree));
		
		var sequenceOrientation= ["N", "R"];

		var combinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N and R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			combinationOfHits[sequenceOrientation[orientation]] = [];
			// as [0], [1], [2] = 3 and these indices do not contain hits, but control values
			for(var i = 3; i < sequences.length; i++)
			{			
				var hierarchyDepth = sequences[i].HierarchyDepth;
				var element = sequences[i].Hits[0][0];
				var MatrixNames = [];
				MatrixNames.push(element.MatrixName + ";" + element.ParentStartPosition + ";" + element.ParentStopPosition);
				//var matrixStart = element.StartPosition;
				//var matrixStop = element.StopPosition;
					
				// new array for each sequence
				combinationOfHits[sequenceOrientation[orientation]][i - 3] = [];
				
				// no children
				if(hierarchyDepth === 1)
					continue;
					
				//var children = element.Children;
				//recursiveAllMatrixCombinationsPlusStartStopPositions(combinationOfHits[sequenceOrientation[orientation]][i - 3], children, MatrixNames, 
					//													matrixStart, matrixStop, 
						//												combinationOfMatrixHitsGreaterThanTwo[sequenceOrientation[orientation]][i-3]);
				recursiveAllMatrixCombinationsPlusStartStopPositions(combinationOfHits[sequenceOrientation[orientation]][i - 3], element, MatrixNames, 
																		combinationOfMatrixHitsGreaterThanTwo[sequenceOrientation[orientation]][i-3]);
			}	
		}
		
		return combinationOfHits;
	}
	
	// recursively iterate through parent child tree and set matrixnames to array plus Start and Stoppositions
	//function recursiveAllMatrixCombinationsPlusStartStopPositions(arrOfMatrixNames, children, parentMatrixNames, parentHitStartPos, 
		//															ParentHitStopPos, allowedCombinationsPerSequence)
	function recursiveAllMatrixCombinationsPlusStartStopPositions(arrOfMatrixNames, element, parentMatrixNames, allowedCombinationsPerSequence)
	{
		var childrenLength = element.Children.length;
		var child;
		
		for(var i = 0; i < childrenLength; i++)
		{
			child = element.Children[i];
			var childMatrixName = child.MatrixName;	
			var childStartposition = child.StartPosition;
			var childStopposition = child.StopPosition;
			var parentHitStartPos = element.ParentStartPosition;
			var ParentHitStopPos = element.ParentStopPosition;
			
			//var startCstartP	= parseInt(childStartposition) - parseInt(parentHitStartPos)
			//var startCstopP		= parseInt(childStartposition) - parseInt(ParentHitStopPos)
			//var stopCstartP		= parseInt(childStopposition) - parseInt(parentHitStartPos)
			//var stopCstopP		= parseInt(childStopposition) - parseInt(ParentHitStopPos)
			
			for(var j = 0; j < parentMatrixNames.length; j++)
			{
				// Parent matrix hit has start and stop -> startP and stopP
				// Child matrix  hit has start and stop -> startC and stopC
				// startC - startP = -(startP - startC)
				// startC - stopP  = -(stopP  - startC)
				// stopC  - startP = -(startP - stopC)
				// stopC  - stopP  = -(stopP  - stopC)
				// i.e., that the subtraction of (Client - Parent) equals (Parent - Client) * (-1)
				// therefore, I am only using for the result element: (Client - Parent)
				// result element:
				// "ParentMatName;;ChildMatName##ParentHitStartPos;ParentHitStopPos##ChildHitStartPos;ChildHitStopPos##
				// {startC - startP};{startC - stopP};{stopC - startP};{stopC- stopP}"
				//var tempItem = parentMatrixNames[j] + ";;" + childMatrixName + "##" + parentHitStartPos + ";" + ParentHitStopPos + 
					//			"##" + childStartposition + ";" + childStopposition + "##" + 
						//		startCstartP + ";" + startCstopP + ";" + stopCstartP + ";" + stopCstopP;
				var matrixName = parentMatrixNames[j].split(';')[0];
				var parentStart = parentMatrixNames[j].split(';')[1];
				var parentStop = parentMatrixNames[j].split(';')[2];
				var stopCstartP		= parseInt(childStopposition) - parseInt(parentStart);
				
				var tempItem = matrixName + ";;" + childMatrixName + "##" + parentStart + ";" + parentStop + 
								"##" + childStartposition + ";" + childStopposition + "##" + stopCstartP;
								
				// no duplettes
				if(arrOfMatrixNames.includes(tempItem) === false &&
				   allowedCombinationsPerSequence.includes(matrixName + ";;" + childMatrixName) === true)
					arrOfMatrixNames.push(tempItem);
			}
			
			if(child.Children !== undefined && child.Children.length > 0)
			{
				var clone = parentMatrixNames.slice();
				clone.push(childMatrixName + ";" + childStartposition + ";" + childStopposition);
				//recursiveAllMatrixCombinationsPlusStartStopPositions(arrOfMatrixNames, child.Children, clone, parentHitStartPos, 
					//													ParentHitStopPos, allowedCombinationsPerSequence);
				recursiveAllMatrixCombinationsPlusStartStopPositions(arrOfMatrixNames, child, clone, allowedCombinationsPerSequence);
			}
		}
	}
	
	// only allow modules that are common to at least 2 sequences in the interval {interval}
	function getCountOccurencesOfModulesWithInterval(matrixHitsWithStartStop, interval)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(matrixHitsWithStartStop));
		
		var sequenceOrientation= ["N", "R"];

		var combinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N or R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			combinationOfHits[sequenceOrientation[orientation]] = [];
			
			// Sequences in N or R
			for(var sequenceIndex = 0; sequenceIndex < sequences.length; sequenceIndex++)
			{			
				// new array for each sequence
				combinationOfHits[sequenceOrientation[orientation]][sequenceIndex] = [];
				
				// Hits in Sequences
				for(var hitIndex = 0; hitIndex < sequences[sequenceIndex].length; hitIndex++)
				{
					var moduleCount = 0;
					var hitName = sequences[sequenceIndex][hitIndex];
					
					// Iterate through sequences in N or R again
					for(var sequenceIndex2 = 0; sequenceIndex2 < sequences.length; sequenceIndex2++)
					{
						// performace optimization: the sequence from the hitname shall not be considered in the result
						if(sequenceIndex2 === sequenceIndex)
							continue;
						
						// Hits in Sequences again
						for(var hitIndex2 = 0; hitIndex2 < sequences[sequenceIndex2].length; hitIndex2++)
						{	
							// is hitname2 in interval of hitname, i.e. is moduleA (two hits each) from sequenceA in the vicinity of +/-interval of
							// moduleA from sequenceB
							// first compare hit-hit names
							if(hitName.split('##')[0] === sequences[sequenceIndex2][hitIndex2].split('##')[0])
							{
								var hitNameArr = hitName.split('##');
								var differenceArr = hitNameArr[3];
								
								var hitName2 = sequences[sequenceIndex2][hitIndex2];
								var hitNameArr2 = hitName2.split('##');
								var differenceArr2 = hitNameArr2[3];
							
								// check if the distances between client stop position and parent start position of two hits are within the specified interval
								// 1. if the distances are the same -> valid module
								// 2. get the smaller number of the two distances. Add intervall to smaller number and if it gets bigger or is the same as 
								//    the other distance -> valid module
								if(parseInt(differenceArr) === parseInt(differenceArr2))
									moduleCount++;
								else if (Math.min(differenceArr, differenceArr2) === parseInt(differenceArr))
								{
									if(parseInt(differenceArr) + parseInt(interval) >= parseInt(differenceArr2))
										moduleCount++;
								}
								else if (Math.min(differenceArr, differenceArr2) === parseInt(differenceArr2))
								{
									if(parseInt(differenceArr2) + parseInt(interval) >= parseInt(differenceArr))
										moduleCount++;
								}
								/*if(parseInt(differenceArr[0])  + interval >= parseInt(differenceArr2[0]) ||
									parseInt(differenceArr[0]) - interval <= parseInt(differenceArr2[0]) ||
									parseInt(differenceArr[1]) + interval >= parseInt(differenceArr2[1]) ||
									parseInt(differenceArr[1]) - interval <= parseInt(differenceArr2[1]) ||
									parseInt(differenceArr[2]) + interval >= parseInt(differenceArr2[2]) ||
									parseInt(differenceArr[2]) - interval <= parseInt(differenceArr2[2]) ||
									parseInt(differenceArr[3]) + interval >= parseInt(differenceArr2[3]) ||
									parseInt(differenceArr[3]) - interval <= parseInt(differenceArr2[3]))
										moduleCount++;*/
							}
						}
					}
					
					// result element:
					// "ParentMatName;;ChildMatName##ParentHitStartPos;ParentHitStopPos##ChildHitStartPos;ChildHitStopPos##
					// {stopC - startP}##{moduleCount}"
					if(moduleCount > 0)
						combinationOfHits[sequenceOrientation[orientation]][sequenceIndex].push(hitName + "##" + moduleCount);
				}
			}	
		}
		
		return combinationOfHits;
	}
	
	// split allowed modules into hits again, so that filtering endresult is easier
	function getValidHits(countOccurencesOfModulesWithInterval)
	{
		// make copy
		var copyOfInputParam = JSON.parse(JSON.stringify(countOccurencesOfModulesWithInterval));
		
		var sequenceOrientation= ["N", "R"];

		var combinationOfHits = {};
		
		for(var orientation = 0; orientation < sequenceOrientation.length; orientation++)
		{
			// N or R
			var sequences = copyOfInputParam[sequenceOrientation[orientation]];
			combinationOfHits[sequenceOrientation[orientation]] = [];
			
			// Sequences in N or R
			for(var sequenceIndex = 0; sequenceIndex < sequences.length; sequenceIndex++)
			{			
				// new array for each sequence
				combinationOfHits[sequenceOrientation[orientation]][sequenceIndex] = [];
				
				// Hits in Sequences
				for(var hitIndex = 0; hitIndex < sequences[sequenceIndex].length; hitIndex++)
				{
					var hitNameArr     = sequences[sequenceIndex][hitIndex].split('##');
					var hitNameParent  = hitNameArr[0].split(';;')[0];
					var hitNameChild   = hitNameArr[0].split(';;')[1];
					var parentHitStart = hitNameArr[1].split(';')[0];
					var parentHitStop  = hitNameArr[1].split(';')[1];
					var childHitStart  = hitNameArr[2].split(';')[0];
					var childHitStop   = hitNameArr[2].split(';')[1];
					
					// result:
					// {hitname}##{hitStart}##{hitStop}
					combinationOfHits[sequenceOrientation[orientation]][sequenceIndex].push(hitNameParent + "##" + parentHitStart + "##" + parentHitStop);
					combinationOfHits[sequenceOrientation[orientation]][sequenceIndex].push(hitNameChild + "##" + childHitStart + "##" + childHitStop);
				}
			}	
		}
		
		return combinationOfHits;
	}
		
	// get responseObject with only hits for valid modules
	function getValidHitsForModules(responseDataWithValidHits, validHits)
	{
		var returnObject = JSON.parse(JSON.stringify(responseDataWithValidHits));
		var tempResponseData = JSON.parse(JSON.stringify(responseDataWithValidHits));
		var countOfSequenceElements = Object.keys(tempResponseData.WMS).length;
		// since all SequenceN have the same amount of matrices, irrespective of containing hits
		// for the second round of this method call; save as global valiable since because of the current and different lengths of the matrices
		// not all would be processed
		if(countOfMatrixElements == 0)
			countOfMatrixElements = Object.keys(tempResponseData.WMS["Sequence1"]).length - 4;
		
		for(var i = 1; i <= countOfSequenceElements; i++)
		{
			for(var j = 1; j <= countOfMatrixElements; j++)
			{
				if(tempResponseData.WMS["Sequence" + i]["Matrix" + j] !== undefined)
				{
					var countOfHits = Object.keys(tempResponseData.WMS["Sequence" + i]["Matrix" + j]).length;
					// -4, as each matrixnode always consists of 4 static children. If Hits are present, then the number of hits is the difference
					// between all children of the matrix node minus four
					countOfHits = countOfHits - 4;
					
					if(globalCountOfHits > 0)
						countOfHits = globalCountOfHits;
					
					if(countOfHits > 0)
					{						
						for(var k = 1; k <= countOfHits; k++)
						{
							if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense === "N")
							{
								var istValiderHit = false;
								
								for(var validlength = 0 ; validlength < validHits.N.length; validlength++)
								{
									for(var key = 0; key < validHits.N[validlength].length; key++)
									{
										if(validHits.N[validlength] !== undefined &&
											validHits.N[validlength][key] !== undefined)
										{
											var items = validHits.N[validlength][key].split('##');
											var allowedName = items[0];
											var allowedStart = items[1];
											var allowedStop = items[2];
											
											if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Start === allowedStart &&
												tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Stop === allowedStop &&
												istValiderHit == false &&
												tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title == allowedName)
											{
												istValiderHit = true;
												break;
											}
											else
												continue;
										}
									}
								}
								// delete invalid hits
								if(istValiderHit == false)
									delete returnObject.WMS["Sequence" + i]["Matrix" + j]["Hit" + k];						
							}
							else if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k] !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense !== undefined &&
								tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Sense === "R")
							{
								var istValiderHit = false;
								
								for(var validlength = 0 ; validlength < validHits.N.length; validlength++)
								{
									for(var key = 0; key < validHits.R[validlength].length; key++)
									{
										if(validHits.R[validlength] !== undefined &&
											validHits.R[validlength][key] !== undefined)
										{
											var items = validHits.R[validlength][key].split('##');
											var allowedName = items[0];
											var allowedStart = items[1];
											var allowedStop = items[2];
											
											if(tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Start === allowedStart &&
												tempResponseData.WMS["Sequence" + i]["Matrix" + j]["Hit" + k].Stop === allowedStop &&
												istValiderHit == false &&
												tempResponseData.WMS["Sequence" + i]["Matrix" + j].Title == allowedName)
											{
												istValiderHit = true;
												break;
											}
											else
												continue;
										}
									}
								}
								// delete invalid hits
								if(istValiderHit == false)
									delete returnObject.WMS["Sequence" + i]["Matrix" + j]["Hit" + k];
							}
						}
					}
					else
					{
						// delete matrices without hit
						delete returnObject.WMS["Sequence" + i]["Matrix" + j];
					}
				}
			}
		}
		return returnObject;
	}
	
	// @summary: This method returns 0 when parameter is <0. positive parameters are reflected unchanged
	// @param: start or stopposition of hit with interval
	// @return: 0, if smaller 0 or parameter is invalid value; positive numbers will be reflected unchanged
	function checkMinimumNull(positionWithInterval)
	{
		if(positionWithInterval === undefined || isNaN(positionWithInterval) || positionWithInterval < 0)
			return 0;
		else if (positionWithInterval > 0)
			return positionWithInterval;
	}
	
	$scope.setDemoSeq1 = function()
	{
		setDemoGATA4("buttonDemo1");
	}
	
	$scope.setDemoSeq2 = function()
	{
		setDemoGATA4("buttonDemo2");
	}
	
	$scope.setDemoSeq3 = function()
	{
		setDemoGATA4("buttonDemo3");
	}
	
	$scope.setDemoSeq4 = function()
	{
		setDemoGATA4("buttonDemo4");
	}
	
	$scope.setDemoSeq4_2 = function()
	{
		setDemoGATA4("buttonDemo4_2");
	}
	
	$scope.setDemoSeq5 = function()
	{
		setDemoGATA4("buttonDemo5");
	}
	
	$scope.setDemoSeq6 = function()
	{
		setDemoGATA4("buttonDemo6");
	}
	
	$scope.setDemoSeq7 = function()
	{
		setDemoGATA4("buttonDemo7");
	}
	
	$scope.setDemoSeq8 = function()
	{
		setDemoGATA4("buttonDemo8");
	}
	
	$scope.setDemoSeq9 = function()
	{
		setDemoGATA4("buttonDemo9");
	}
	
	$scope.setDemoSeq10 = function()
	{
		setDemoGATA4("buttonDemo10");
	}
	
	function setDemoGATA4(buttonid)
	{
		var textfield = document.getElementById("inputSequences");
		var demoSequences = "";
		
		switch(buttonid)
		{
			case "buttonDemo1":
				demoSequences = ">demo1\n" +
								"CAGACGGAGAGACAGACAGACGGAGAGACACACACACACACAGACACACACACACTCACAGACATGAGGT" +
								"CGGTGTTGCTGCTGCTGTGTATCTGGACATGCAGGAGCTCAGCGCTGATCAGGGTGCCTCTGAGGAAGGT" +
								"GCCCACGATCCGCTCTCAGCTCCGCTCTGAAGGTCTGCTGCAGGACTTCCTGGTGGAGAATCGGCCCGAC" +
								"ATGTTCAGTCGCCGCTACGCTCAGTGTTTCCCCGCCGGGACGCCCTCTCTGAGGCTGGGGCGCTCCAGTG";
				$scope.selectedRadioButton.selectedID = "1";
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				break;
			case "buttonDemo2":
				demoSequences = ">demo2.1\n" +
								"CAGACGGAGAACAGACAGACGGAGAGACACACACACACACAGACACACACACACTCACAGACATGAGGT" +
								"CGGTGTTGCTGCTGCTGTGTATCTGGACATGCAGGAGCTCAGCGCTGATCAGGGTGCCTCTGAGGAAGGT" +
								"GCCCACGATCCGCTCTCAGCTCCGCTCTGAAGGTCTGCTGCAGGACTTCCTGGTGGAGAATCGGCCCGAC" +
								"ATGTTCAGTCGCCGCTACGCTCAGTGTTTCCCCGCCGGGACGCCCTCTCTGAGGCTGGGGCGCTCCAGTG\n" +
								">demo2.2\n" +
								"ATGAACAAAATTTTGTTTTATTTGTTTGTGTACGCCGTTGTAAAGAGCGCGGCCTACGATCCTTTGAAAG" +
								"CGCCTAATTATTTTGAAGAATTTGTTCATCGATTCAACAAAAATTATAGTAGCGAAGTTGAAAAATTGCG" +
								"AAGATTCAAAATTTTCCAACACAATTTAAATGAAATTATCAATAAAAACCAAAACGATTCGGCCAAATAT" +
								"GAAATAAACAAATTCTCGGATTTGTCCAAAGACGAAACTATCGCAAAATACACAGGTCTGTCTTTGCCTA";
				$scope.selectedRadioButton.selectedID = "1";	
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();			
				break;
			case "buttonDemo3":
				demoSequences = ">demo2.1\n" +
								"CAGACGGAGAACAGACAGACGGAGAGACACACACACACACAGACACACACACACTCACAGACATGAGGT" +
								"CGGTGTTGCTGCTGCTGTGTATCTGGACATGCAGGAGCTCAGCGCTGATCAGGGTGCCTCTGAGGAAGGT" +
								"GCCCACGATCCGCTCTCAGCTCCGCTCTGAAGGTCTGCTGCAGGACTTCCTGGTGGAGAATCGGCCCGAC" +
								"ATGTTCAGTCGCCGCTACGCTCAGTGTTTCCCCGCCGGGACGCCCTCTCTGAGGCTGGGGCGCTCCAGTG\n" +
								">demo2.2\n" +
								"ATGAACAAAATTTTGTTTTATTTGTTTGTGTACGCCGTTGTAAAGAGCGCGGCCTACGATCCTTTGAAAG" +
								"CGCCTAATTATTTTGAAGAATTTGTTCATCGATTCAACAAAAATTATAGTAGCGAAGTTGAAAAATTGCG" +
								"AAGATTCAAAATTTTCCAACACAATTTAAATGAAATTATCAATAAAAACCAAAACGATTCGGCCAAATAT" +
								"GAAATAAACAAATTCTCGGATTTGTCCAAAGACGAAACTATCGCAAAATACACAGGTCTGTCTTTGCCTA\n" +
								">demo2.3\n" +
								"ATGAACAAAATTTTGTTTTATTTGTTTGTGTACGCCGTTGTAAAGAGCGCGGCCTACGATCCTTTGAAAG" +
								"CGCCTAATTATTTTGAAGAATTTGTTCATCGATTCAACAAAAATTATAGTAGCGAAGTTGAAAAATTGCG" +
								"AAGATTCAAAATTTTCCAACACAATTTAAATGAAATTATCAATAAAAACCAAAACGATTCGGCCAAATAT" +
								"GAAATAAACAAATTCTCGGATTTGTCCAAAGACGAAACTATCGCAAAATACACAGGTCTGTCTTTGCCTA\n" +
								">demo2.4\n" +
								"CAGACGGAGAACAGACAGACGGAGAGACACACACACACACAGACACACACACACTCACAGACATGAGGT" +
								"CGGTGTTGCTGCTGCTGTGTATCTGGACATGCAGGAGCTCAGCGCTGATCAGGGTGCCTCTGAGGAAGGT" +
								"GCCCACGATCCGCTCTCAGCTCCGCTCTGAAGGTCTGCTGCAGGACTTCCTGGTGGAGAATCGGCCCGAC" +
								"ATGTTCAGTCGCCGCTACGCTCAGTGTTTCCCCGCCGGGACGCCCTCTCTGAGGCTGGGGCGCTCCAGTG\n";
				$scope.selectedRadioButton.selectedID = "1";	
				$scope.selectedDropDownItem = "NEMATODES";
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 2;
				break;	
			case "buttonDemo4":
				demoSequences = ">NM_000600.5 Homo sapiens interleukin 6 (IL6), transcript variant 1, mRNA\n" +
								"ATTCTGCCCTCGAGCCCACCGGGAACGAAAGAGAAGCTCTATCTCCCCTCCAGGAGCCCAGCTATGAACT" +
								"CCTTCTCCACAAGCGCCTTCGGTCCAGTTGCCTTCTCCCTGGGGCTGCTCCTGGTGTTGCCTGCTGCCTT" +
								"CCCTGCCCCAGTACCCCCAGGAGAAGATTCCAAAGATGTAGCCGCCCCACACAGACAGCCACTCACCTCT" +
								"TCAGAACGAATTGACAAACAAATTCGGTACATCCTCGACGGCATCTCAGCCCTGAGAAAGGAGACATGTA" +
								"ACAAGAGTAACATGTGTGAAAGCAGCAAAGAGGCACTGGCAGAAAACAACCTGAACCTTCCAAAGATGGC" +
								"TGAAAAAGATGGATGCTTCCAATCTGGATTCAATGAGGAGACTTGCCTGGTGAAAATCATCACTGGTCTT" +
								"TTGGAGTTTGAGGTATACCTAGAGTACCTCCAGAACAGATTTGAGAGTAGTGAGGAACAAGCCAGAGCTG" +
								"TGCAGATGAGTACAAAAGTCCTGATCCAGTTCCTGCAGAAAAAGGCAAAGAATCTAGATGCAATAACCAC" +
								"CCCTGACCCAACCACAAATGCCAGCCTGCTGACGAAGCTGCAGGCACAGAACCAGTGGCTGCAGGACATG" +
								"ACAACTCATCTCATTCTGCGCAGCTTTAAGGAGTTCCTGCAGTCCAGCCTGAGGGCTCTTCGGCAAATGT" +
								"AGCATGGGCACCTCAGATTGTTGTTGTTAATGGGCATTCCTTCTTCTGGTCAGAAACCTGTCCACTGGGC" +
								"ACAGAACTTATGTTGTTCTCTATGGAGAACTAAAAGTATGAGCGTTAGGACACTATTTTAATTATTTTTA" +
								"ATTTATTAATATTTAAATATGTGAAGCTGAGTTAATTTATGTAAGTCATATTTATATTTTTAAGAAGTAC" +
								"CACTTGAAACATTTTATGTATTAGTTTTGAAATAATAATGGAAAGTGGCTATGCAGTTTGAATATCCTTT" +
								"GTTTCAGAGCCAGATCATTTCTTGGAAAGTGTAGGCTTACCTCAAATAAATGGCTAACTTATACATATTT" +
								"TTAAAGAAATATTTATATTGTATTTATATAATGTATAAATGGTTTTTATACCAATAAATGGCATTTTAAA" +
								"AAATTCA\n" +
								">NM_000594.4 Homo sapiens tumor necrosis factor (TNF), mRNA\n" +
								"AGCAGACGCTCCCTCAGCAAGGACAGCAGAGGACCAGCTAAGAGGGAGAGAAGCAACTACAGACCCCCCC" +
								"TGAAAACAACCCTCAGACGCCACATCCCCTGACAAGCTGCCAGGCAGGTTCTCTTCCTCTCACATACTGA" +
								"CCCACGGCTCCACCCTCTCTCCCCTGGAAAGGACACCATGAGCACTGAAAGCATGATCCGGGACGTGGAG" +
								"CTGGCCGAGGAGGCGCTCCCCAAGAAGACAGGGGGGCCCCAGGGCTCCAGGCGGTGCTTGTTCCTCAGCC" +
								"TCTTCTCCTTCCTGATCGTGGCAGGCGCCACCACGCTCTTCTGCCTGCTGCACTTTGGAGTGATCGGCCC" +
								"CCAGAGGGAAGAGTTCCCCAGGGACCTCTCTCTAATCAGCCCTCTGGCCCAGGCAGTCAGATCATCTTCT" +
								"CGAACCCCGAGTGACAAGCCTGTAGCCCATGTTGTAGCAAACCCTCAAGCTGAGGGGCAGCTCCAGTGGC" +
								"TGAACCGCCGGGCCAATGCCCTCCTGGCCAATGGCGTGGAGCTGAGAGATAACCAGCTGGTGGTGCCATC" +
								"AGAGGGCCTGTACCTCATCTACTCCCAGGTCCTCTTCAAGGGCCAAGGCTGCCCCTCCACCCATGTGCTC" +
								"CTCACCCACACCATCAGCCGCATCGCCGTCTCCTACCAGACCAAGGTCAACCTCCTCTCTGCCATCAAGA" +
								"GCCCCTGCCAGAGGGAGACCCCAGAGGGGGCTGAGGCCAAGCCCTGGTATGAGCCCATCTATCTGGGAGG" +
								"GGTCTTCCAGCTGGAGAAGGGTGACCGACTCAGCGCTGAGATCAATCGGCCCGACTATCTCGACTTTGCC" +
								"GAGTCTGGGCAGGTCTACTTTGGGATCATTGCCCTGTGAGGAGGACGAACATCCAACCTTCCCAAACGCC" +
								"TCCCCTGCCCCAATCCCTTTATTACCCCCTCCTTCAGACACCCTCAACCTCTTCTGGCTCAAAAAGAGAA" +
								"TTGGGGGCTTAGGGTCGGAACCCAAGCTTAGAACTTTAAGCAACAAGACCACCACTTCGAAACCTGGGAT" +
								"TCAGGAATGTGTGGCCTGCACAGTGAAGTGCTGGCAACCACTAAGAATTCAAACTGGGGCCTCCAGAACT" +
								"CACTGGGGCCTACAGCTTTGATCCCTGACATCTGGAATCTGGAGACCAGGGAGCCTTTGGTTCTGGCCAG" +
								"AATGCTGCAGGACTTGAGAAGACCTCACCTAGAAATTGACACAAGTGGACCTTAGGCCTTCCTCTCTCCA" +
								"GATGTTTCCAGACTTCCTTGAGACACGGAGCCCAGCCCTCCCCATGGAGCCAGCTCCCTCTATTTATGTT" +
								"TGCACTTGTGATTATTTATTATTTATTTATTATTTATTTATTTACAGATGAATGTATTTATTTGGGAGAC" +
								"CGGGGTATCCTGGGGGACCCAATGTAGGAGCTGCCTTGGCTCAGACATGTTTTCCGTGAAAACGGAGCTG" +
								"AACAATAGGCTGTTCCCATGTAGCCCCCTGGCCTCTGTGCCTTCTTTTGATTATGTTTTTTAAAATATTT" +
								"ATCTGATTAAGTTGTCTAAACAATGCTGATTTGGTGACCAACTGTCACTCATTGCTGAGCCTCTGCTCCC" +
								"CAGGGGAGTTGTGTCTGTAATCGCCCTACTATTCAGTGGCGAGAAATAAAGTTTGCTTAGAAAAGAAA\n" +
								">NM_020525.5 Homo sapiens interleukin 22 (IL22), mRNA\n" +
								"ACAAGCAGAATCTTCAGAACAGGTTCTCCTTCCCCAGTCACCAGTTGCTCGAGTTAGAATTGTCTGCAAT" +
								"GGCCGCCCTGCAGAAATCTGTGAGCTCTTTCCTTATGGGGACCCTGGCCACCAGCTGCCTCCTTCTCTTG" +
								"GCCCTCTTGGTACAGGGAGGAGCAGCTGCGCCCATCAGCTCCCACTGCAGGCTTGACAAGTCCAACTTCC" +
								"AGCAGCCCTATATCACCAACCGCACCTTCATGCTGGCTAAGGAGGCTAGCTTGGCTGATAACAACACAGA" +
								"CGTTCGTCTCATTGGGGAGAAACTGTTCCACGGAGTCAGTATGAGTGAGCGCTGCTATCTGATGAAGCAG" +
								"GTGCTGAACTTCACCCTTGAAGAAGTGCTGTTCCCTCAATCTGATAGGTTCCAGCCTTATATGCAGGAGG" +
								"TGGTGCCCTTCCTGGCCAGGCTCAGCAACAGGCTAAGCACATGTCATATTGAAGGTGATGACCTGCATAT" +
								"CCAGAGGAATGTGCAAAAGCTGAAGGACACAGTGAAAAAGCTTGGAGAGAGTGGAGAGATCAAAGCAATT" +
								"GGAGAACTGGATTTGCTGTTTATGTCTCTGAGAAATGCCTGCATTTGACCAGAGCAAAGCTGAAAAATGA" +
								"ATAACTAACCCCCTTTCCCTGCTAGAAATAACAATTAGATGCCCCAAAGCGATTTTTTTTAACCAAAAGG" +
								"AAGATGGGAAGCCAAACTCCATCATGATGGGTGGATTCCAAATGAACCCCTGCGTTAGTTACAAAGGAAA" +
								"CCAATGCCACTTTTGTTTATAAGACCAGAAGGTAGACTTTCTAAGCATAGATATTTATTGATAACATTTC" +
								"ATTGTAACTGGTGTTCTATACACAGAAAACAATTTATTTTTTAAATAATTGTCTTTTTCCATAAAAAAGA" +
								"TTACTTTCCATTCCTTTAGGGGAAAAAACCCCTAAATAGCTTCATGTTTCCATAATCAGTACTTTATATT" +
								"TATAAATGTATTTATTATTATTATAAGACTGCATTTTATTTATATCATTTTATTAATATGGATTTATTTA" +
								"TAGAAACATCATTCGATATTGCTACTTGAGTGTAAGGCTAATATTGATATTTATGACAATAATTATAGAG" +
								"CTATAACATGTTTATTTGACCTCAATAAACACTTGGATATCCTAA\n";
				$scope.selectedRadioButton.selectedID = "2";	
				document.getElementById('stepper1').defaultValue = 9;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(9, 8);
				$scope.setRNADemo1();
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo4_2":
				demoSequences = ">NM_000600.5 Homo sapiens interleukin 6 (IL6), transcript variant 1, mRNA\n" +
								"ATTCTGCCCTCGAGCCCACCGGGAACGAAAGAGAAGCTCTATCTCCCCTCCAGGAGCCCAGCTATGAACT" +
								"CCTTCTCCACAAGCGCCTTCGGTCCAGTTGCCTTCTCCCTGGGGCTGCTCCTGGTGTTGCCTGCTGCCTT" +
								"CCCTGCCCCAGTACCCCCAGGAGAAGATTCCAAAGATGTAGCCGCCCCACACAGACAGCCACTCACCTCT" +
								"TCAGAACGAATTGACAAACAAATTCGGTACATCCTCGACGGCATCTCAGCCCTGAGAAAGGAGACATGTA" +
								"ACAAGAGTAACATGTGTGAAAGCAGCAAAGAGGCACTGGCAGAAAACAACCTGAACCTTCCAAAGATGGC" +
								"TGAAAAAGATGGATGCTTCCAATCTGGATTCAATGAGGAGACTTGCCTGGTGAAAATCATCACTGGTCTT" +
								"TTGGAGTTTGAGGTATACCTAGAGTACCTCCAGAACAGATTTGAGAGTAGTGAGGAACAAGCCAGAGCTG" +
								"TGCAGATGAGTACAAAAGTCCTGATCCAGTTCCTGCAGAAAAAGGCAAAGAATCTAGATGCAATAACCAC" +
								"CCCTGACCCAACCACAAATGCCAGCCTGCTGACGAAGCTGCAGGCACAGAACCAGTGGCTGCAGGACATG" +
								"ACAACTCATCTCATTCTGCGCAGCTTTAAGGAGTTCCTGCAGTCCAGCCTGAGGGCTCTTCGGCAAATGT" +
								"AGCATGGGCACCTCAGATTGTTGTTGTTAATGGGCATTCCTTCTTCTGGTCAGAAACCTGTCCACTGGGC" +
								"ACAGAACTTATGTTGTTCTCTATGGAGAACTAAAAGTATGAGCGTTAGGACACTATTTTAATTATTTTTA" +
								"ATTTATTAATATTTAAATATGTGAAGCTGAGTTAATTTATGTAAGTCATATTTATATTTTTAAGAAGTAC" +
								"CACTTGAAACATTTTATGTATTAGTTTTGAAATAATAATGGAAAGTGGCTATGCAGTTTGAATATCCTTT" +
								"GTTTCAGAGCCAGATCATTTCTTGGAAAGTGTAGGCTTACCTCAAATAAATGGCTAACTTATACATATTT" +
								"TTAAAGAAATATTTATATTGTATTTATATAATGTATAAATGGTTTTTATACCAATAAATGGCATTTTAAA" +
								"AAATTCA\n" +
								">NM_000594.4 Homo sapiens tumor necrosis factor (TNF), mRNA\n" +
								"AGCAGACGCTCCCTCAGCAAGGACAGCAGAGGACCAGCTAAGAGGGAGAGAAGCAACTACAGACCCCCCC" +
								"TGAAAACAACCCTCAGACGCCACATCCCCTGACAAGCTGCCAGGCAGGTTCTCTTCCTCTCACATACTGA" +
								"CCCACGGCTCCACCCTCTCTCCCCTGGAAAGGACACCATGAGCACTGAAAGCATGATCCGGGACGTGGAG" +
								"CTGGCCGAGGAGGCGCTCCCCAAGAAGACAGGGGGGCCCCAGGGCTCCAGGCGGTGCTTGTTCCTCAGCC" +
								"TCTTCTCCTTCCTGATCGTGGCAGGCGCCACCACGCTCTTCTGCCTGCTGCACTTTGGAGTGATCGGCCC" +
								"CCAGAGGGAAGAGTTCCCCAGGGACCTCTCTCTAATCAGCCCTCTGGCCCAGGCAGTCAGATCATCTTCT" +
								"CGAACCCCGAGTGACAAGCCTGTAGCCCATGTTGTAGCAAACCCTCAAGCTGAGGGGCAGCTCCAGTGGC" +
								"TGAACCGCCGGGCCAATGCCCTCCTGGCCAATGGCGTGGAGCTGAGAGATAACCAGCTGGTGGTGCCATC" +
								"AGAGGGCCTGTACCTCATCTACTCCCAGGTCCTCTTCAAGGGCCAAGGCTGCCCCTCCACCCATGTGCTC" +
								"CTCACCCACACCATCAGCCGCATCGCCGTCTCCTACCAGACCAAGGTCAACCTCCTCTCTGCCATCAAGA" +
								"GCCCCTGCCAGAGGGAGACCCCAGAGGGGGCTGAGGCCAAGCCCTGGTATGAGCCCATCTATCTGGGAGG" +
								"GGTCTTCCAGCTGGAGAAGGGTGACCGACTCAGCGCTGAGATCAATCGGCCCGACTATCTCGACTTTGCC" +
								"GAGTCTGGGCAGGTCTACTTTGGGATCATTGCCCTGTGAGGAGGACGAACATCCAACCTTCCCAAACGCC" +
								"TCCCCTGCCCCAATCCCTTTATTACCCCCTCCTTCAGACACCCTCAACCTCTTCTGGCTCAAAAAGAGAA" +
								"TTGGGGGCTTAGGGTCGGAACCCAAGCTTAGAACTTTAAGCAACAAGACCACCACTTCGAAACCTGGGAT" +
								"TCAGGAATGTGTGGCCTGCACAGTGAAGTGCTGGCAACCACTAAGAATTCAAACTGGGGCCTCCAGAACT" +
								"CACTGGGGCCTACAGCTTTGATCCCTGACATCTGGAATCTGGAGACCAGGGAGCCTTTGGTTCTGGCCAG" +
								"AATGCTGCAGGACTTGAGAAGACCTCACCTAGAAATTGACACAAGTGGACCTTAGGCCTTCCTCTCTCCA" +
								"GATGTTTCCAGACTTCCTTGAGACACGGAGCCCAGCCCTCCCCATGGAGCCAGCTCCCTCTATTTATGTT" +
								"TGCACTTGTGATTATTTATTATTTATTTATTATTTATTTATTTACAGATGAATGTATTTATTTGGGAGAC" +
								"CGGGGTATCCTGGGGGACCCAATGTAGGAGCTGCCTTGGCTCAGACATGTTTTCCGTGAAAACGGAGCTG" +
								"AACAATAGGCTGTTCCCATGTAGCCCCCTGGCCTCTGTGCCTTCTTTTGATTATGTTTTTTAAAATATTT" +
								"ATCTGATTAAGTTGTCTAAACAATGCTGATTTGGTGACCAACTGTCACTCATTGCTGAGCCTCTGCTCCC" +
								"CAGGGGAGTTGTGTCTGTAATCGCCCTACTATTCAGTGGCGAGAAATAAAGTTTGCTTAGAAAAGAAA\n" +
								">NM_020525.5 Homo sapiens interleukin 22 (IL22), mRNA\n" +
								"ACAAGCAGAATCTTCAGAACAGGTTCTCCTTCCCCAGTCACCAGTTGCTCGAGTTAGAATTGTCTGCAAT" +
								"GGCCGCCCTGCAGAAATCTGTGAGCTCTTTCCTTATGGGGACCCTGGCCACCAGCTGCCTCCTTCTCTTG" +
								"GCCCTCTTGGTACAGGGAGGAGCAGCTGCGCCCATCAGCTCCCACTGCAGGCTTGACAAGTCCAACTTCC" +
								"AGCAGCCCTATATCACCAACCGCACCTTCATGCTGGCTAAGGAGGCTAGCTTGGCTGATAACAACACAGA" +
								"CGTTCGTCTCATTGGGGAGAAACTGTTCCACGGAGTCAGTATGAGTGAGCGCTGCTATCTGATGAAGCAG" +
								"GTGCTGAACTTCACCCTTGAAGAAGTGCTGTTCCCTCAATCTGATAGGTTCCAGCCTTATATGCAGGAGG" +
								"TGGTGCCCTTCCTGGCCAGGCTCAGCAACAGGCTAAGCACATGTCATATTGAAGGTGATGACCTGCATAT" +
								"CCAGAGGAATGTGCAAAAGCTGAAGGACACAGTGAAAAAGCTTGGAGAGAGTGGAGAGATCAAAGCAATT" +
								"GGAGAACTGGATTTGCTGTTTATGTCTCTGAGAAATGCCTGCATTTGACCAGAGCAAAGCTGAAAAATGA" +
								"ATAACTAACCCCCTTTCCCTGCTAGAAATAACAATTAGATGCCCCAAAGCGATTTTTTTTAACCAAAAGG" +
								"AAGATGGGAAGCCAAACTCCATCATGATGGGTGGATTCCAAATGAACCCCTGCGTTAGTTACAAAGGAAA" +
								"CCAATGCCACTTTTGTTTATAAGACCAGAAGGTAGACTTTCTAAGCATAGATATTTATTGATAACATTTC" +
								"ATTGTAACTGGTGTTCTATACACAGAAAACAATTTATTTTTTAAATAATTGTCTTTTTCCATAAAAAAGA" +
								"TTACTTTCCATTCCTTTAGGGGAAAAAACCCCTAAATAGCTTCATGTTTCCATAATCAGTACTTTATATT" +
								"TATAAATGTATTTATTATTATTATAAGACTGCATTTTATTTATATCATTTTATTAATATGGATTTATTTA" +
								"TAGAAACATCATTCGATATTGCTACTTGAGTGTAAGGCTAATATTGATATTTATGACAATAATTATAGAG" +
								"CTATAACATGTTTATTTGACCTCAATAAACACTTGGATATCCTAA\n";
				$scope.selectedRadioButton.selectedID = "2";	
				document.getElementById('stepper1').defaultValue = 9;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(9, 8);
				$scope.setRNADemo1();
				//$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				//$scope.countInputSequences();			
				//$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo5":
				demoSequences = ">NC_000067.6:131019345-131019844 Mus musculus strain C57BL/6J chromosome 1, GRCm38.p6 C57BL/6J, Mus musculus interleukin 10 (Il10) promoter\n" +
								"AAATCAGCCCTCTCGGGGTTTCCTTTGGGTAACTGAGTGCTAAGGTGACTTCCGAGTCAGCAAGAAATAT" +
								"CGGACGTTCAACCCAGGTTGAGTGGAGGAAACAATTATTTCTCAATCCTAATATGTTCTGGAATAGCCCA" +
								"TTTATCCACGTCATTATGACCTGGGAGTGCGTGAATGGAATCCACAGATGAGGGCCTCTGTACATAGAAC" +
								"AGCTGTCTGCCTCAGGAAATACAACTTTTAGTATTGAGAAGCTAAAAAGAAAAAAAAATTAAAAGAGAGG" +
								"TAGCCCATACTAAAAATAGCTGTAATGCAGAAGTTCATTCCGACCAGTTCTTTAGCGCTTACAATGCAAA" +
								"AAAAAGGGAAAGGAAAAAAAAAAAGAAAGAAATTAAACTCAAAAATTGCATGGTTTAGAAGAGGGAGGAG" +
								"GAGCCTGAATAACAAAAACCTTTGCCAGGAAGGCCCCACTGAGCCTTCAGTATAAAAGGGGGACCAAGAA" +
								"CAGGAGGTCT\n" +
								">NC_000074.6:c82403252-82402576 Mus musculus strain C57BL/6J chromosome 8, GRCm38.p6 C57BL/6J, Mus musculus interleukin 15 (Il15), transcript variant 2 promoter\n" +
								"ACCCAAGGTCCTTTTCCGTTTCCTCCCGGTACAGTCTCTGTCCAGATCTCCTCCGGGCTTCTATGGGGAA" +
								"GCCAAACTGCCTCCCTGCAAGGCCAGTTGCTGTAGATGCAAGCAACCTGTGAACTCAGGCCAACTCCTTG" +
								"AAACTTCACAGAGGCAAAGGCATTCCAGGACACACAGAGGCTGTGGCCAACTGCCCAGGGGGAGGAGACT" +
								"GCTCTCTGCTCTCAGTTGCCCTTCAGGTTCTGCGCCCTGGGGACCTGGCAGTGGCAGAATCATGTGGGCA" +
								"CCTGGTAAGGTGGCCGGGACCATGTGTTCCTCCCGCAACCTCCCCAGGGTGTTGATCTCCGCCTCAGCTT" +
								"GGGCTCTTTCTCTTTCACTTTTCTGTTAGCTGGGGTTGGGACTCCCCGGCTGGAAAGCACTGGGGGAAAC" +
								"CGGGGAAACCCCAGCTGATTCGCTCCTTGTGCCTTGATTGCTCCCGCTGGCTGCTGCCCTGCATCCTGCA" +
								"CCCTTCAACCAGAACCCGATGGAGGTACAGAATGGGAGGTGGTAGTGCTGGTGGTGGTGGATCAACAATG" +
								"GAATTTTTTTTTTTTCCGAAAGCCTACGCCCCGGGCCCCTCCCAGCTCTGGCTCTGCTCAGGCACCCTTT" +
								"TCCCCTCCAGCTGCCGGCCAGGCCGCCCCGCCCTCT\n" +
								">NC_000077.6:c53635202-53634702 Mus musculus strain C57BL/6J chromosome 11, GRCm38.p6 C57BL/6J, Mus musculus interleukin 13 (Il13) promoter\n" +
								"CATGCATTGCTTTGGTGATTTATCAGATACGTTTGTTGAAATTAAGAAGAAAAAAAGAAAAGAAAGAAAG" +
								"AAGAAAGGAAGGAAGGGAGGAAGGAAGAAAGAAAGAAAGGAGAAAACTTCCCCAATTCTCACAGCTAATA" +
								"GACTGATACTCACCTGCCCAAAGGGTGACAAGTACTTAGTGATCAAGGGGTCAGCATTGGGCTGGCTGCT" +
								"CAGGAGCTTGGGGCGGTCAGCGGGTGGAATTACTGGGGCGGAAGTTAGCTTTGCTGATGCCCACCGTGGA" +
								"AATAAACCACCCAGAACCTGGAAACCCTGTCCCAGACCCTTCTCAATAAATCCACTAAATCAGACTCTTT" +
								"CCTTTAGCGGCCACTGGATTTTCCAAAAAAGAAAAAAAAAAATTCAAGATGAGTAAAGATGTGGTTTTCA" +
								"GATAATGCCCAACAAAGCAGAGACCAGGGGTGAGGCGTCATCACTTTGGTTTATAAAAGCTGCTTCAACA" +
								"GGCTAAGGCC\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 8;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(8, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 3;
				break;	
				case "buttonDemo6":
				demoSequences = ">Homo_sapiens_cathepsin_V_transcript_variant-1_promoter\n" +
								"cttctaaagccctgatgcacccacccttaagtggaaggtaatgcttctgctgggggctgt" +
								"gcgttcttccactccgtcccacctttgccgtggactaaacaggagccactgaacgagagt" +
								"accctggctcccggccctgcagattttcaccaaaaactctaggactaagttaaagtaggg" +
								"actgaaataccacacagagctcgctgtaaaccacccgctcagcgcagtaagtcgggatag" +
								"tcagtagatctgagcccttgagggaggcgcctccccctcctccgcgcagcccccgggcgc" +
								"ccggcccagcttcccgcagccagggtgtattgaggtaggcgcgcccagacctgagacggg" +
								"ttgggactgggctgcgtcacgcgcgggctctaagcgcccggggccccgcccagtggccgg" +
								"cacagccaatcgcagcgcgggaaggcggtgggggcggggaaggccgcctggaaacttaaa" +
								"tcccgaggcgggcgaacctg\n" +
								">Bos_taurus_cathepsin-Z_promoter\n" +
								"ctagggtgctcaggtgctcggtcatatctgactcttttgcaacccctgggactgtagcct" +
								"gccaagctcctttgtcaatgggattctccagggaagaatactggagtgggttgccatgcc" +
								"ctcctccatcaggaagctagaatagggtgcagttctgcagagagacccctgcccatcatc" +
								"cctggaggctggacccaggcgggatgcggggatccggggcatctctccggaccaaagggt" +
								"cccaagacgccaaggctgggggtggggggccctaagaatgaatgaggtctgatagatcag" +
								"aggcaagaggcaagtggcggggtcggggcggggtccgccgaggcctggcgcgtgacccga" +
								"gtccggacgggccgggcagccgggcggggcggggccgggtcaccgggggcagcagcgcgc" +
								"cccgccccgggggagtgtcccgccgggcgcagacaccttaagggcctgcgggccggggag" +
								"gaagcctgcggaggggtgac\n" +
								"> Mus_musculus_cathepsin-F-transcript-variant-X1_promoter_576-1076\n" +
								"gagccaccttgcaatgatcccctggtgtgcccactgcctgagacgaagaaaacagtggtg" +
								"agtgaagaggtcagctattgttggccctagctggcaaacaattggaatggtgggtcctgt" +
								"cgaggcattggttactcctgagataccaagttagagaccaagatgctctgaaagggtggg" +
								"tgttggggtgctgggtgtctgctgctggcctccctctttcaccaagttatgactgccttc" +
								"catgtggctctcctttgaggaacttctagctgctcttgccaggaccttgtttcaaactgt" +
								"cccaagaccgtcttctttctatgcctccagctctgcagttttgaagtcctggaagagcta" +
								"aaagaacacttgctgctgaggagggactgtagcccagtgaatgccaaggtcacaggtgct" +
								"gggattgctcaaggagactgggagagcccagaccatacttgagtcagaatccagccttaa" +
								"ttacttctctgttccgaccct\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 6;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(6, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				//$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				//$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo7":
				demoSequences = ">Homo_sapiens_cathepsin_V_transcript_variant-1_promoter\n" +
								"cttctaaagccctgatgcacccacccttaagtggaaggtaatgcttctgctgggggctgt" +
								"gcgttcttccactccgtcccacctttgccgtggactaaacaggagccactgaacgagagt" +
								"accctggctcccggccctgcagattttcaccaaaaactctaggactaagttaaagtaggg" +
								"actgaaataccacacagagctcgctgtaaaccacccgctcagcgcagtaagtcgggatag" +
								"tcagtagatctgagcccttgagggaggcgcctccccctcctccgcgcagcccccgggcgc" +
								"ccggcccagcttcccgcagccagggtgtattgaggtaggcgcgcccagacctgagacggg" +
								"ttgggactgggctgcgtcacgcgcgggctctaagcgcccggggccccgcccagtggccgg" +
								"cacagccaatcgcagcgcgggaaggcggtgggggcggggaaggccgcctggaaacttaaa" +
								"tcccgaggcgggcgaacctg\n" +
								">Bos_taurus_cathepsin-Z_promoter\n" +
								"ctagggtgctcaggtgctcggtcatatctgactcttttgcaacccctgggactgtagcct" +
								"gccaagctcctttgtcaatgggattctccagggaagaatactggagtgggttgccatgcc" +
								"ctcctccatcaggaagctagaatagggtgcagttctgcagagagacccctgcccatcatc" +
								"cctggaggctggacccaggcgggatgcggggatccggggcatctctccggaccaaagggt" +
								"cccaagacgccaaggctgggggtggggggccctaagaatgaatgaggtctgatagatcag" +
								"aggcaagaggcaagtggcggggtcggggcggggtccgccgaggcctggcgcgtgacccga" +
								"gtccggacgggccgggcagccgggcggggcggggccgggtcaccgggggcagcagcgcgc" +
								"cccgccccgggggagtgtcccgccgggcgcagacaccttaagggcctgcgggccggggag" +
								"gaagcctgcggaggggtgac\n" +
								"> Mus_musculus_cathepsin-F-transcript-variant-X1_promoter_576-1076\n" +
								"gagccaccttgcaatgatcccctggtgtgcccactgcctgagacgaagaaaacagtggtg" +
								"agtgaagaggtcagctattgttggccctagctggcaaacaattggaatggtgggtcctgt" +
								"cgaggcattggttactcctgagataccaagttagagaccaagatgctctgaaagggtggg" +
								"tgttggggtgctgggtgtctgctgctggcctccctctttcaccaagttatgactgccttc" +
								"catgtggctctcctttgaggaacttctagctgctcttgccaggaccttgtttcaaactgt" +
								"cccaagaccgtcttctttctatgcctccagctctgcagttttgaagtcctggaagagcta" +
								"aaagaacacttgctgctgaggagggactgtagcccagtgaatgccaaggtcacaggtgct" +
								"gggattgctcaaggagactgggagagcccagaccatacttgagtcagaatccagccttaa" +
								"ttacttctctgttccgaccct\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 6;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(6, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo8":
				demoSequences = ">X73536.1_H.sapiens_promoter_region_of_human_IL-10_gene\n" +
								"AGCTTTCAGCAAGTGCAGACTACTCTTACCCACTTCCCCCAAGCACAGTTGGGGTGGGGGACAGCTGAAG" +
								"AGGTGGAAACATGTGCCTGAGAATCCTAATGAAATCGGGGTAAAGGAGCCTGGAACACATCCTGTGACCC" +
								"CGCCTGTCCTGTAGGAAGCCAGTCTCTGGAAAGTAAAATGGAAGGGCTGCTTGGGAACTTTGAGGATATT" +
								"TAGCCCACCCCCTCATTTTTACTTGGGGAAACTAAGGCCCAGAGACCTAAGGTGACTGCCTAAGTTAGCA" +
								"AGGAGAAGTCTTGGGTATTCATCCCAGGTTGGGGGGACCCAATTATTTCTCAATCCCATTGTATTCTGGA" +
								"ATGGGCAATTTGTCCACGTCACTGTGACCTAGGAACACGCGAATGAGAACCCACAGCTGAGGGCCTCTGC" +
								"GCACAGAACAGCTGTTCTCCCCAGGAAATCAACTTTTTTTAATTGAGAAGCTAAAAAATTATTCTAAGAG" +
								"AGGTAGCCCATCCTAAAAATAGCTGTAATGCAGAAGTTCATGTTCAACCAATCATTTTTGCTTACGATGC" +
								"AAAAATTGAAAACTAAGTTTATTAGAGAGGTTAGAGAAGGAGGAGCTCTAAGCAGAAAAAATCCTGTGCC" +
								"GGGAAACCTTGATTGTGGCTTTTTAATGAATGAAGAGGCCTCCCTGAGCTTACAATATAAAAGGGGGACA" +
								"GAGAGGTGAAGGTCTACACATCAGGGGCTTGCTCTTGCAAAACCAAACCACAAGACAGACTTGCAAAAGA" +
								"AGGCATGCACAGCTCAGCACTGC\n" +
								">AY486432.1_Macaca-mulatta_interleukin-10-(IL-10)_gene_promoter_region\n" +
								"TTTGGGAAGGGGAAGTAGGGATAGGTAAGAGGAAAGTAAGGGACCTCCTATCCAGCCTCCATGGAATCCT" +
								"GACTTCTTTTCCCTGTTATTACAACTTCTTCCTCCCCATCTTTTAAACTTTAGACTCCCGCCACAGAAGC" +
								"TTACAACTAAAAGAAACTCTAAGGCCAATTTAATCCAAGGTTTCATTCTATGTGTTGGAGATGGCATAGA" +
								"GTAGGGTGAGGGAACCAAATTCTCAGTTGGCACTGGTGTACCCTTGTACAGGTGATGTAATCGCTCTGTG" +
								"CCTCAGTTTGCTCACTATAAAATAGAGATGGTAGGGGTCATGGTGAGCACTACCTGACTAGCATATAACA" +
								"AGCTTTCGGCAAGTGCAGACTACTCTTACCCACTTCCCCCAAGCACAGTTGGGGTGGGGGACACCTGGGA" +
								"CAGCTGAAGAGGAGGAAATGTGTGCCTGAGAATCCAAATGAAATCAGGGTAAAGGAGCCTGGAGCACATC" +
								"CTGTGACCCTGCCTGTCCTGTAGGAAGCCGGTCTCTGGAAGGTAAAATGGAAGAGCTGCTTGGGAGCTTT" +
								"GAGGATATTTAGCCCACCCCCTCATTTTTACTTGGGGAAACTAAGGCCCACAGACCTAAGGTGACTGTCT" +
								"AAGTTAGCAAGAAGAAGTCTTGGGTATTCACCCTGGGTTGGGGGGACCCAATTATTTCTCAATCCCATTG" +
								"TATTCTGGAATGGGCAATTTGTCCACGTCACTGTGACCTAGGAACACGCGAATGGGAACCCACAACTGCG" +
								"GGCCTCTGCGCACAGAACAGCTGTTCTCCCCAGGAAATCAACTTTTTTTAATTGAGAAGCTAAAAAATTA" +
								"TTCTAAGAGAGGTAGCCCATCCTAAAAATAGCTGTGCAGAAGTTCATGTTCAACCAATCCTTTTTGCTTA" +
								"CGATGCAAAATTTGAAAACTAAGTTTATTAGAGAGGTTAGAGAAGGAGGAGCTCTAAGCAGAAAAAATCC" +
								"TGTGCCGGGAAACCTGTGATTGTGGCTTTTTATGAATGAAGAGGCCTCCCTGAGCTTACAATATAAAAGG" +
								"GGGACAGAGAGGTGAAGGTCTACACATCAGGGGCTTGCTCTTGCAAAACCAAACCACAAGACAGACTTGC" +
								"AAAAGAAGGCATGCACAGCTCAGCACTGCTCTGTTGCCTGGTCCTCC\n" +
								">AF121965.1_Mus-musculus_interleukin-10-(IL10)_gene_promoter_partial_sequence\n" +
								"TTCCTGTTCTACCAGCCCTGGTGTGGTAACCCTCTCCAATGGGGCAGGCTTGGAACCCTGTGCCAACGAA" +
								"GATCCTCCCCCGTACTGATGCAGGAAGGACAGCCCGGGAGTGTACCCTCTACATGGGTCTACTTTTATTT" +
								"AAGCAAACATTCCCTGGTCAACAGGACGTGTAGCATTGCCCCCCCCCCTTGGGTCACACAGAAAACAGGT" +
								"ACCAGGAGGACAAGTAGTTGCTTGCCCAGGGTACAGAATGAAAGGCAATAGGGGACTCTAGGCGAATGTT" +
								"CTTCCCACCCAAACTGAGGTAGTAGGAGAAGTCCCTACTGAAGGGAAGGTCCAGACATAATCAAAGGACT" +
								"ACCAGAGATCTCCCAAT\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 6;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(6, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				//$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				//$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo9":
				demoSequences = ">X73536.1_H.sapiens_promoter_region_of_human_IL-10_gene\n" +
									"AGCTTTCAGCAAGTGCAGACTACTCTTACCCACTTCCCCCAAGCACAGTTGGGGTGGGGGACAGCTGAAG" +
									"AGGTGGAAACATGTGCCTGAGAATCCTAATGAAATCGGGGTAAAGGAGCCTGGAACACATCCTGTGACCC" +
									"CGCCTGTCCTGTAGGAAGCCAGTCTCTGGAAAGTAAAATGGAAGGGCTGCTTGGGAACTTTGAGGATATT" +
									"TAGCCCACCCCCTCATTTTTACTTGGGGAAACTAAGGCCCAGAGACCTAAGGTGACTGCCTAAGTTAGCA" +
									"AGGAGAAGTCTTGGGTATTCATCCCAGGTTGGGGGGACCCAATTATTTCTCAATCCCATTGTATTCTGGA" +
									"ATGGGCAATTTGTCCACGTCACTGTGACCTAGGAACACGCGAATGAGAACCCACAGCTGAGGGCCTCTGC" +
									"GCACAGAACAGCTGTTCTCCCCAGGAAATCAACTTTTTTTAATTGAGAAGCTAAAAAATTATTCTAAGAG" +
									"AGGTAGCCCATCCTAAAAATAGCTGTAATGCAGAAGTTCATGTTCAACCAATCATTTTTGCTTACGATGC" +
									"AAAAATTGAAAACTAAGTTTATTAGAGAGGTTAGAGAAGGAGGAGCTCTAAGCAGAAAAAATCCTGTGCC" +
									"GGGAAACCTTGATTGTGGCTTTTTAATGAATGAAGAGGCCTCCCTGAGCTTACAATATAAAAGGGGGACA" +
									"GAGAGGTGAAGGTCTACACATCAGGGGCTTGCTCTTGCAAAACCAAACCACAAGACAGACTTGCAAAAGA" +
									"AGGCATGCACAGCTCAGCACTGC\n" +
									">AY486432.1_Macaca-mulatta_interleukin-10-(IL-10)_gene_promoter_region\n" +
									"TTTGGGAAGGGGAAGTAGGGATAGGTAAGAGGAAAGTAAGGGACCTCCTATCCAGCCTCCATGGAATCCT" +
									"GACTTCTTTTCCCTGTTATTACAACTTCTTCCTCCCCATCTTTTAAACTTTAGACTCCCGCCACAGAAGC" +
									"TTACAACTAAAAGAAACTCTAAGGCCAATTTAATCCAAGGTTTCATTCTATGTGTTGGAGATGGCATAGA" +
									"GTAGGGTGAGGGAACCAAATTCTCAGTTGGCACTGGTGTACCCTTGTACAGGTGATGTAATCGCTCTGTG" +
									"CCTCAGTTTGCTCACTATAAAATAGAGATGGTAGGGGTCATGGTGAGCACTACCTGACTAGCATATAACA" +
									"AGCTTTCGGCAAGTGCAGACTACTCTTACCCACTTCCCCCAAGCACAGTTGGGGTGGGGGACACCTGGGA" +
									"CAGCTGAAGAGGAGGAAATGTGTGCCTGAGAATCCAAATGAAATCAGGGTAAAGGAGCCTGGAGCACATC" +
									"CTGTGACCCTGCCTGTCCTGTAGGAAGCCGGTCTCTGGAAGGTAAAATGGAAGAGCTGCTTGGGAGCTTT" +
									"GAGGATATTTAGCCCACCCCCTCATTTTTACTTGGGGAAACTAAGGCCCACAGACCTAAGGTGACTGTCT" +
									"AAGTTAGCAAGAAGAAGTCTTGGGTATTCACCCTGGGTTGGGGGGACCCAATTATTTCTCAATCCCATTG" +
									"TATTCTGGAATGGGCAATTTGTCCACGTCACTGTGACCTAGGAACACGCGAATGGGAACCCACAACTGCG" +
									"GGCCTCTGCGCACAGAACAGCTGTTCTCCCCAGGAAATCAACTTTTTTTAATTGAGAAGCTAAAAAATTA" +
									"TTCTAAGAGAGGTAGCCCATCCTAAAAATAGCTGTGCAGAAGTTCATGTTCAACCAATCCTTTTTGCTTA" +
									"CGATGCAAAATTTGAAAACTAAGTTTATTAGAGAGGTTAGAGAAGGAGGAGCTCTAAGCAGAAAAAATCC" +
									"TGTGCCGGGAAACCTGTGATTGTGGCTTTTTATGAATGAAGAGGCCTCCCTGAGCTTACAATATAAAAGG" +
									"GGGACAGAGAGGTGAAGGTCTACACATCAGGGGCTTGCTCTTGCAAAACCAAACCACAAGACAGACTTGC" +
									"AAAAGAAGGCATGCACAGCTCAGCACTGCTCTGTTGCCTGGTCCTCC\n" +
									">AF121965.1_Mus-musculus_interleukin-10-(IL10)_gene_promoter_partial_sequence\n" +
									"TTCCTGTTCTACCAGCCCTGGTGTGGTAACCCTCTCCAATGGGGCAGGCTTGGAACCCTGTGCCAACGAA" +
									"GATCCTCCCCCGTACTGATGCAGGAAGGACAGCCCGGGAGTGTACCCTCTACATGGGTCTACTTTTATTT" +
									"AAGCAAACATTCCCTGGTCAACAGGACGTGTAGCATTGCCCCCCCCCCTTGGGTCACACAGAAAACAGGT" +
									"ACCAGGAGGACAAGTAGTTGCTTGCCCAGGGTACAGAATGAAAGGCAATAGGGGACTCTAGGCGAATGTT" +
									"CTTCCCACCCAAACTGAGGTAGTAGGAGAAGTCCCTACTGAAGGGAAGGTCCAGACATAATCAAAGGACT" +
									"ACCAGAGATCTCCCAAT\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 7;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(7, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 3;
				break;
				case "buttonDemo10":
				demoSequences = ">Homo sapiens chromosome 14, GRCh38.p13 Primary Assembly IGH 105588394-105588894\n" +
									"tggggtgggg ctcatggagt ggtgggtgtt ggactgagac tctgaccagg gacaggggga" +
									"tggggtcaca gccaagccac tccaccccta ccccatgcac acagcactca gagcccaggc" +
									"cccctcctca gagcccccac caaaatcctc tctaggggca ggggaaagag caagacatgt" +
									"cccccaccca gagcaggaac tggggtcagg gagctcaggg gactcagcca ctccatggca" +
									"gagccctgtt taatataact tgtgtctggg atggcctggg tcagaggccc tatctaagga" +
									"gcatgttcag aaactgtgtc gctgggatga gacagctggg tccaaccgca ggcccatggt" +
									"gcaggagctg tgtaaccttg gggctgtcac caggcctctc tgtgctgggt tcctccagtg" +
									"tagaggagag gcaggtacag cctgtcctcc tggggacatg gcatgagggc cgcgtcctca" +
									"cagcgcattc tgtgttccag c\n" +
									">Homo sapiens chromosome 2, GRCh38.p13 Primary Assembly IGKC 88857683-88858183\n" +
									"gggctcaggg cctgctctgc agggaggttt tagcccagcc cagccaaagt aacccccggg" +
									"agcctgttat cccagcacag tcctggaaga ggcacagggg aaataaaagc ggacggaggc" +
									"tttccttgac tcagccgctg cctggtcttc ttcagacctg ttctgaattc taaactctga" +
									"gggggtcgga tgacgtggcc attctttgcc taaagcattg agtttactgc aaggtcagaa" +
									"aagcatgcaa agccctcaga atggctgcaa agagctccaa caaaacaatt tagaacttta" +
									"ttaaggaata gggggaagct aggaagaaac tcaaaacatc aagattttaa atacgcttct" +
									"tggtctcctt gctataatta tctgggataa gcatgctgtt ttctgtctgt ccctaacatg" +
									"ccctgtgatt atccgcaaac aacacaccca agggcagaac tttgttactt aaacaccatc" +
									"ctgtttgctt ctttcctcag g\n" +
									">Homo sapiens chromosome 1, GRCh38.p13 Primary Assembly PIGR 206946466-206946966\n" +
									"tataaggggc atttttgtcc aggctaagta acctagggag tcggagggga ttccagagca" +
									"actggggata tgagaccaag gactacgaca gccactcctg ccacctgtgc cccatcagat" +
									"gatgtcaact tcaaatcaag cattgggcca ggtattttag agctaatacc gggctatatc" +
									"ctctacctgt agatttggta ttaccatccc tcttttccag atgaaaagaa ataggaaggt" +
									"gacttgccaa aggtcttgca gctagaaagc gacagaacag catcttcacg cttgacattc" +
									"tgtccctcat cctgaagctg caacgatgga ggattcccaa gtaacagagt ctccccaagg" +
									"tcaaaggaaa ccaaatggag ccagccagga aggccaaaat gaaaggaaag caagggatct" +
									"gtgagagtca catgaccctg gctggccacg gtgcctgtgg gagagtggcc ctttaagagc" +
									"ccaggtgtgg gtcaaacact g\n";
				$scope.selectedRadioButton.selectedID = "1";
				document.getElementById('stepper1').defaultValue = 7;
				document.getElementById('stepper2').defaultValue = 8;
				setThresholds(7, 8);	
				$scope.selectedDropDownItem = "VERTEBRATES";
				$scope.checkboxForModuleFilter = true;
				$scope.inputSequenceDNA = demoSequences;
				$scope.validateDNA();
				$scope.getMatricesFromBackend();
				$scope.countInputSequences();			
				$scope.precisionOfTFsFromStepper = 3;
				break;
		}

		$scope.getScoring();
		//scrollToEndOfPage();
	}
	
	$scope.setRNADemo1 = function()
	{
		var textfield = document.getElementById("inputMatrices");
		/*hergestellt aus
		 * AATAAA
			ATTAAA
			AAGAAA
			AAAAAG
			AATACA
			TATAAA
			ACTAAA
			AGTAAA
			GATAAA
			AATATA
			CATAAA
			AATAGA*/
		var demoPolyA = ">human-Poly-A\n" +
						"9 1 1 1\n" +
						"9 1 1 1\n" +
						"1 0 1 10\n" +
						"12 0 0 0\n" +
						"9 1 1 1\n" +
						"11 0 1 0";
		$scope.inputMatrices = demoPolyA;
		$scope.validateMatrix();
	}
	
	function scrollToEndOfPage()
	{
		//var element = document.getElementById("footer");
		//document.querySelector(element).scrollIntoView({behavior: 'smooth'});
		//element.scrollIntoView({block: "end", behavior: "smooth"});
		window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);
	}

  }
);
