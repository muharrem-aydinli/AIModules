'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the workspaceAngularWithYeomanApp
 */
angular.module('workspaceAngularWithYeomanApp')
  .controller('MainCtrl', function ($scope, sharedProperties, languageImages) {
	$scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
	
	$scope.languages = languageImages.getLanguageImages();
	
	$scope.translatePage = function(translateTo) {
      if (translateTo === "German")
      {
		sharedProperties.setCurrentLanguage(germanTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
      else if (translateTo === "English")
      {
		sharedProperties.setCurrentLanguage(englishTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
    };
  }) 
  ;
