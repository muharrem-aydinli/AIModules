'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the workspaceAngularWithYeomanApp
 */
angular.module('workspaceAngularWithYeomanApp')
  .controller('ContactCtrl', function ($scope, sharedProperties, languageImages) {
	$scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
	
	$scope.languages = languageImages.getLanguageImages();
	
	$scope.translatePage = function(translateTo) {
      if (translateTo === "German")
      {
		sharedProperties.setCurrentLanguage(germanTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
      else if (translateTo === "English")
      {
		sharedProperties.setCurrentLanguage(englishTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
    };
    
    $scope.showLicenses = false;
    $scope.toggleLicenses = function() {
        $scope.showLicenses = !$scope.showLicenses;
    };
    
    $scope.showApache = false;
    $scope.toggleApache = function() {
        $scope.showApache = !$scope.showApache;
    };
    
    $scope.showArtistic = false;
    $scope.toggleArtistic = function() {
        $scope.showArtistic = !$scope.showArtistic;
    };
    
    $scope.showCBIL = false;
    $scope.toggleCBIL = function() {
        $scope.showCBIL = !$scope.showCBIL;
    };
    
    $scope.showCDDL = false;
    $scope.toggleCDDL = function() {
        $scope.showCDDL = !$scope.showCDDL;
    };
    
    $scope.showEclipse = false;
    $scope.toggleEclipse = function() {
        $scope.showEclipse = !$scope.showEclipse;
    };
    
    $scope.showGNU = false;
    $scope.toggleGNU = function() {
        $scope.showGNU = !$scope.showGNU;
    };
    
    $scope.showGNUv2 = false;
    $scope.toggleGNUv2 = function() {
        $scope.showGNUv2 = !$scope.showGNUv2;
    };
    
    $scope.showJSR = false;
    $scope.toggleJSR = function() {
        $scope.showJSR = !$scope.showJSR;
    };
    
    $scope.showMIT = false;
    $scope.toggleMIT = function() {
        $scope.showMIT = !$scope.showMIT;
    };
    
    $scope.showPostgreSQL = false;
    $scope.togglePostgreSQL = function() {
        $scope.showPostgreSQL = !$scope.showPostgreSQL;
    };
    
    $scope.showBSD = false;
    $scope.toggleBSD = function() {
        $scope.showBSD = !$scope.showBSD;
    };
  });
