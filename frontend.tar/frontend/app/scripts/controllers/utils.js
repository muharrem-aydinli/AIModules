'use strict';

/**
 * @ngdoc function
 * @name workspaceAngularWithYeomanApp.controller:UtilsCtrl
 * @description
 * # UtilsCtrl
 * Controller of the workspaceAngularWithYeomanApp
 */
angular.module('workspaceAngularWithYeomanApp')
  .controller('UtilsCtrl', function ($scope, sharedProperties, languageImages) {
	$scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
	
	$scope.languages = languageImages.getLanguageImages();
	
	$scope.translatePage = function(translateTo) {
      if (translateTo === "German")
      {
		sharedProperties.setCurrentLanguage(germanTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
      else if (translateTo === "English")
      {
		sharedProperties.setCurrentLanguage(englishTexts);
        $scope.activeTranslatedText = sharedProperties.getCurrentLanguage();
      }
    };
    
    $scope.inputSequencesDNAConverter = "";
    $scope.myRegExConverter = /^>/;
    var showFrequencyButton = false;
    $scope.validateDNAConverter = function()
    {
	  showFrequencyButton = false;
      var dnaResult = [];
      var dnatemp = $scope.inputSequencesDNAConverter;
      dnatemp = dnatemp.trim();
      var dnatempArr = dnatemp.split('\n');

      for (var i = 0; i < dnatempArr.length; ++i)
      {
        if(dnatempArr[i] !== "")
        {
          dnaResult.push(dnatempArr[i].trim());
        }
      }

      if(dnaResult.length === 1)
      {
        //$scope.errorDNA = "Please type Sequence";
        germanTexts.dnaSequenceInputError = "Bitte DNA-Sequenz eingeben.";
        englishTexts.dnaSequenceInputError = "Please type DNA sequence.";
        return;
      }

      // first index fasta header, then dna sequences ...
      $scope.dnaAsOneLiner = arrayOfOneLineFastaHeaderAndDNASequences(dnaResult);
      // only valid dna Chars
      var isDNABasesValid = validateDNABases($scope.dnaAsOneLiner);
      var isFastaHeaderFilled = false;
      if(!isDNABasesValid)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: Basensequenz enthält invalide Basen (valide: acgt).";
        englishTexts.dnaSequenceInputError = "Incorrect: DNA sequence has invalid Bases (valid: acgt).";
        return;
      }
      else
        {isFastaHeaderFilled = validateFastaHeaderFilled(dnaResult);}

      var isFastaHeaderMoreThanOne = false;
      if(!isFastaHeaderFilled)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: FASTA Header darf nicht leer sein.";
        englishTexts.dnaSequenceInputError = "Incorrect: FASTA Header cannot be null.";
        return;
      }
      else
        {isFastaHeaderMoreThanOne = validateFastaHeaderMoreThanOne(dnaResult);}

      var isHeaderFollowedByDNA = false;
      if(isFastaHeaderMoreThanOne)
      {
        germanTexts.dnaSequenceInputError = "Inkorrect: Nur ein FASTA Header erlaubt.";
        englishTexts.dnaSequenceInputError = "Incorrect: Only One FASTA Header allowed.";
        return;
      }
      else
        {isHeaderFollowedByDNA = validateHeaderFollowedByDNA($scope.dnaAsOneLiner);}

	  var isSequencesSameLength = false;
      if(!isHeaderFollowedByDNA)
      {
        germanTexts.dnaSequenceInputError = "Inkorrekt: FASTA Header ohne DNA-Sequenz nicht erlaubt.";
        englishTexts.dnaSequenceInputError = "Incorrect: FASTA Headers without a DNA sequence not allowed.";
        return;
      }
      else
      {
		isSequencesSameLength = validateSequencesSameLength($scope.dnaAsOneLiner);
      }
      
      if(!isSequencesSameLength)
      {
		germanTexts.dnaSequenceInputError = "Inkorrekt: DNA Sequenzen nicht gleich lang.";
        englishTexts.dnaSequenceInputError = "Incorrect: DNA Sequences not same length.";
        return;
	  }
	  else
	  {
		showFrequencyButton = true;
		//makeJSONFromDNAArray($scope.dnaAsOneLiner);
        germanTexts.dnaSequenceInputError = "Fasta DNA Sequenz ist OK.";
        englishTexts.dnaSequenceInputError = "Fasta DNA Sequences OK.";
	  }
    };
    
    // return array: matrixname, dann sequenzen
    function arrayOfOneLineFastaHeaderAndDNASequences(aDnaResult)
    {
      var oneLinerFasta = [];
      for(var i in aDnaResult)
      {
        // < will be handled in validateDNABases()
        if(aDnaResult[i].charAt(0) === '>'
            || aDnaResult[i].charAt(0) === '<')
        {
          oneLinerFasta.push(aDnaResult[i]);
        }
        else
        {
		  var tempString = aDnaResult[i].replace(/ /g, "").toUpperCase();
		  oneLinerFasta.push(tempString);
        }
      }
	  $scope.arrayForFrequencies = oneLinerFasta;
      return oneLinerFasta;
    }

    function validateDNABases(aDnaResult)
    {
      var isDNABasesValid = true;
      for(var i in aDnaResult)
      {
        if (!isDNABasesValid)
          {break;}

        if (aDnaResult[i].charAt(0) === '<'
            || aDnaResult[i].charAt(0) !== '>'
            && aDnaResult[i].search(/[^gatc]/i) !== -1)
        {
			germanTexts.rnaToDNAConverted = "";
			englishTexts.rnaToDNAConverted = "";
			if(convertRNAToDNA(aDnaResult[i]) === true)
			{
				aDnaResult[i] = aDnaResult[i].replace(/u/gi, "t");
				germanTexts.rnaToDNAConverted = "Bitte Uracil (U) durch Thymin (T) ersetzen.";
				englishTexts.rnaToDNAConverted = "Please replace Uracil (U) with Thymine (T).";
			}
		    isDNABasesValid = false;
	    }
	    else
	      {
		    //The seq string contains only GATC
		    isDNABasesValid = true;
	    }
      }
      //$scope.inputSequencesDNAConverter = aDnaResult;
      return isDNABasesValid;
    }
    
    function convertRNAToDNA(aDnaResult)
    {
      var hasRNABeenConvertedToDNA = false;
      if (aDnaResult.charAt(0) !== '>'
          && aDnaResult.search(/[u]/i) !== -1)
      {
		    hasRNABeenConvertedToDNA = true;
	  }

      return hasRNABeenConvertedToDNA;
    }

    function validateFastaHeaderFilled(aDnaResult)
    {
      for(var i in aDnaResult)
      {
        if(aDnaResult[i].charAt(0) === '>'
            && aDnaResult[i].length === 1)
          {return false;}
      }
      return true;
    }
    
    function validateFastaHeaderMoreThanOne(aDnaResult)
    {
      var fastaHeader = [];
      for(var i in aDnaResult)
      {
        if(aDnaResult[i].charAt(0) === '>')
          {fastaHeader[i] = aDnaResult[i];}
      }

	  if(fastaHeader.length > 2)
	  {
		  return true;
	  }
	  else
	  {
		  return false;
	  }
    }

    function validateHeaderFollowedByDNA(aDnaAsOneLiner)
    {
      var isHeaderFollowedByDNA = false;
      for(var i in aDnaAsOneLiner)
      {
        if(aDnaAsOneLiner[i].charAt(0) === '>')
          {isHeaderFollowedByDNA = false;}
        else
          {isHeaderFollowedByDNA = true;}
      }
      
      return isHeaderFollowedByDNA;
    }
    
    function validateSequencesSameLength(aDnaAsOneLiner)
    {
		var sequencesLengths = [];
		
		// add dna lengths to array
		for(var i = 0; i < aDnaAsOneLiner.length; ++i)
		{
			if(aDnaAsOneLiner[i].charAt(0) !== '>')
			{
				sequencesLengths.push(aDnaAsOneLiner[i].length);
			}
		}
		
		if(sequencesLengths.length === 1)
		{
			return true;
		}
		
		var isSameLength = true;
		// check if all lengths are the same
		for(var i = 0; i < sequencesLengths.length; ++i)
		{
			for(var j = 0; j < sequencesLengths.length; ++j)
			{
				if(!isSameLength)
				{
					return false;
				}
				if(sequencesLengths[i] === sequencesLengths[j])
				{
					isSameLength = true;
				}
				else
				{
					isSameLength = false;
				}
			}
		}
		return isSameLength;
	}
	
	$scope.isFrequencyButtonActivate = function()
	{
		return showFrequencyButton;
	};
	
	$scope.showFrequency = function()
	{
		$scope.showFrequencySpinner = true;
		var showResult = "";
		showResult += "[A, C, G, T]<br/>";
		showResult += $scope.arrayForFrequencies[0] + "<br/>";
		
		var resultArr = getFrequenciesFromSequences();
		
		// replace every 4th whitespace with "<br/>"
		var resultStr = resultArr.toString().replace(/,/g, " ").replace(/(\S*\s\S*\s\S*\s\S*)\s/g, "$1<br/>");
		showResult += resultStr;
		var frequencyWindow = window.open("", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400,rel='noreferrer noopener'");
		frequencyWindow.document.write(buildDetails(showResult));
		$scope.showFrequencySpinner = false;
	}
	
	function getFrequenciesFromSequences()
	{
		// Array is build like this: [SequenceLengthxSubarrays]
		// Subarray are build like this: [frequencyAtPosistionN(A), 
		//								  frequencyAtPosistionN(C),
		//								  frequencyAtPosistionN(G),
		//								  frequencyAtPosistionN(T)]
		var resultFreqArray = [];
		
		// all Sequences have same length; index 0 is fasta header, then follow sequences
		var sequenceLength = $scope.arrayForFrequencies[1].length
		var sequenceCount = $scope.arrayForFrequencies.length;
		
		for(var i = 0; i < sequenceLength; ++i)
		{
			var subArray = [0, 0, 0, 0];
			for(var j = 1; j < sequenceCount; ++j)
			{	
				if($scope.arrayForFrequencies[j].charAt(i) === 'A')
				{
					subArray[0] += 1;
				}
				else if($scope.arrayForFrequencies[j].charAt(i) === 'C')
				{
					subArray[1] += 1;
				}
				else if($scope.arrayForFrequencies[j].charAt(i) === 'G')
				{
					subArray[2] += 1;
				}
				else if($scope.arrayForFrequencies[j].charAt(i) === 'T')
				{
					subArray[3] += 1;
				}
			}
			resultFreqArray.push(subArray);
		}
		
		return resultFreqArray;
	}
	
	$scope.setDemoGATA4 = function()
	{
		var textfield = document.getElementById("inputSequencesConverter");
		var gata4DemoSequences = ">MA0482.1 Gata4\n" +
									"TCTTATCTGCC\n" +
									"CCTTATCTCCC\n" +
									"TCTTATCTGCC\n" +
									"TCTTATCACCC\n" +
									"TCTTATCTGCC\n" +
									"TCTTATCTGCC\n" +
									"CCTTATCTCCC\n" +
									"TCTTATCTGCC\n" +
									"TCTTATCACCC\n" +
									"TCTTATCTGCC";
		
		$scope.inputSequencesDNAConverter = gata4DemoSequences;
		$scope.validateDNAConverter();
	}
    
  }) 
  ;
