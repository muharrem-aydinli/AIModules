Here lie the files that can be imported to postgres.
With pgadmin: Either restore the postgres.sql or execute createTables.sql then fillTables.sql scripts, and then import the *.dat files into the matrices table.
The .dat files are from Jaspar2020
